import QtQuick
import QtQuick.Controls
import QtQuick.Window
import "theme"
import "controls"
import "pages"
import "nucleus"
import "atlas"
import "home"

// V2 Home in the owner's concept (2026-09-26): menu bar, brand block, left
// navigation, the core (a dark planet in green smoke), glass cards with real
// state, action tiles, and the Ask bar. Every number is measured or sourced.
Window {
    id: root
    visible: true
    visibility: previewWindowed ? Window.Windowed : Window.Maximized
    // Home is the desktop surface, not a decorated app window.
    flags: previewWindowed && previewSize.width === 0 ? Qt.Window : (Qt.Window | Qt.FramelessWindowHint)
    minimumWidth: 900
    minimumHeight: 620
    width: previewSize.width > 0 ? previewSize.width : 1440
    height: previewSize.height > 0 ? previewSize.height : 900
    color: "#000000"
    title: "APVIS OS V2 — Home"

    readonly property color pale: Theme.text
    readonly property color muted: Theme.muted
    Binding { target: Theme; property: "accentName"; value: (shell.render || {}).accent || "apvis" }
    Binding { target: Theme; property: "style"; value: (shell.render || {}).style || "glass" }
    Component.onCompleted: {
        shell.setSharedDisplay(sharedDisplay)
        shell.setFrameMeasuring(measuring)
        shell.setHomeIntel(!pageOpen)
        if (controlOpen) shell.refreshControl()
        if (previewPage === "lock" || (previewPage === "" && (shell.render || {}).lockOnStart)) lockScreen.engage()
    }
    readonly property bool locked: lockScreen.locked
    function lockNow() { lockScreen.engage(); root.raise(); root.requestActivate() }
    Shortcut { sequences: ["Meta+L", "Ctrl+Alt+L"]; enabled: !root.locked; onActivated: root.lockNow() }
    readonly property var state: shell.state || ({})
    readonly property var focus: state.focus || null
    readonly property var counts: state.task_counts || ({})
    readonly property var sys: shell.system || ({})
    readonly property var route: shell.route || ({})
    property bool settingsOpen: previewPage === "settings"
    property bool missionsOpen: previewPage === "missions"
    property bool devOpen: previewPage === "dev"
    property bool systemOpen: previewPage === "system"
    property bool devicesOpen: previewPage === "devices"
    // Booted with "Install APVIS OS" from the USB menu: open the installer.
    property bool installOpen: previewPage === "install" || !!(shell.installer || {}).requested
    property bool atlasOpen: previewPage === "atlas" || previewPage === "atlas-home"
    property bool notesOpen: previewPage === "notes"
    // Smoke-test hook: visit Atlas, then return Home (renders the live card).
    Timer { running: previewPage === "atlas-home"; interval: 12000; onTriggered: root.openPage("") }
    // Smoke-test hooks: the goodbye screen (never runs the power action) and an open menu.
    Timer { running: previewPage === "goodbye"; interval: 300; onTriggered: { goodbye.action = "poweroff"; goodbye.t = 0.6 } }
    Timer { running: previewPage === "menu"; interval: 300; onTriggered: topBar.openMenu = "System" }
    // Smoke-test hook: "search:<text>" opens search with that text.
    Timer { running: previewPage.startsWith("search:"); interval: 600; onTriggered: { root.openSearch(); searchField.text = previewPage.slice(7) } }
    readonly property bool pageOpen: settingsOpen || missionsOpen || atlasOpen || notesOpen || devOpen || installOpen || systemOpen || devicesOpen
    onPageOpenChanged: shell.setHomeIntel(!pageOpen)
    readonly property string currentPage: settingsOpen ? "settings" : missionsOpen ? "missions" : atlasOpen ? "atlas" : notesOpen ? "notes" :
                                          devOpen ? "dev" : installOpen ? "install" : systemOpen ? "system" : devicesOpen ? "devices" : ""
    // Lite look (no GPU / minimal tier): decorative motion stops; the core and real data still live.
    readonly property bool lite: !!(shell.render || {}).lite
    readonly property bool calm: !!(shell.render || {}).reducedMotion || lite
    // Frame times only count while Home animates continuously (see setFrameMeasuring).
    readonly property bool measuring: !pageOpen && !calm && nucleus.animating
    onMeasuringChanged: shell.setFrameMeasuring(measuring)
    property date nowTick: new Date()
    Timer { interval: 1000; running: true; repeat: true; onTriggered: root.nowTick = new Date() }
    Connections {
        target: shell
        function onPageRequested(name) { root.openPage(name) }
        function onDevChanged() { if (!shell.developerMode && root.devOpen) root.devOpen = false }
        function onPowerRequested(action) { root.powerMenuOpen = false; root.controlOpen = false; goodbye.start(action) }
    }
    // Opening a page puts the keyboard in its first field (Esc returns to Ask).
    onNotesOpenChanged: if (notesOpen) Qt.callLater(() => memoryPage.focusFirst())
    onSettingsOpenChanged: if (settingsOpen) Qt.callLater(() => settingsPage.focusFirst())
    function openPage(name) {
        settingsOpen = name === "settings"; missionsOpen = name === "missions"; atlasOpen = name === "atlas"
        notesOpen = name === "notes"; devOpen = name === "dev" && shell.developerMode
        systemOpen = name === "system"; devicesOpen = name === "devices"
        installOpen = name === "install" && !!(shell.installer || {}).live
        if (name === "") Qt.callLater(() => focusInput.forceActiveFocus())
    }
    // Example chips on the pages put their text in the Ask bar (the owner still presses Enter).
    function suggestAsk(text) { openPage(""); focusInput.text = text; focusInput.forceActiveFocus(); focusInput.cursorPosition = text.length }
    // Menu bar, navigation, tiles and cards all speak in one set of action keys.
    function act(key) {
        if (key.startsWith("page:")) openPage(key.slice(5))
        else if (key.startsWith("launch:")) shell.launch(key.slice(7))
        else if (key === "lock") lockNow()
        else if (key === "control") toggleControl()
        else if (key === "search") openSearch()
        else if (key === "keys") keysOpen = true
        else if (key === "power") powerMenuOpen = !powerMenuOpen
        else if (key === "ask") { openPage(""); focusInput.forceActiveFocus() }
        else if (key === "continuity") { openPage(""); shell.askQuestion("what was I doing?") }
        else if (key === "updates") { openPage("settings"); Qt.callLater(() => settingsPage.jump("updates")); shell.checkUpdates() }
        else if (key === "settings:ai") { openPage("settings"); Qt.callLater(() => settingsPage.jump("ai")) }
        else if (key === "files" || key === "apps") shell.launch(key)
        else openPage(key)
    }
    Shortcut {
        sequences: [StandardKey.Cancel]
        enabled: (root.answering || root.pageOpen) && !root.searchOpen && !root.controlOpen && !root.keysOpen && !root.powerMenuOpen && topBar.openMenu === ""
        onActivated: { shell.closeAnswer(); root.openPage(""); focusInput.forceActiveFocus() }
    }
    readonly property var missions: shell.missions || []
    // Presentation privacy (V2-13): with a second screen attached, private context
    // (Focus, mission and note text, Memory/Missions pages) stays hidden until the
    // owner confirms the screens are theirs. Resets when the extra screen goes.
    property bool trustedScreens: false
    readonly property int screenCount: Qt.application.screens.length
    readonly property bool sharedDisplay: (screenCount > 1 || previewPage === "shared") && !trustedScreens
    onScreenCountChanged: if (screenCount < 2) trustedScreens = false
    onSharedDisplayChanged: shell.setSharedDisplay(sharedDisplay)
    function priv(text) { return sharedDisplay ? "Hidden · second screen" : text }
    readonly property var activeMissions: missions.filter(m => m.status === "approval_required" || m.status === "running")
    // Tell the owner when something waits for approval while another app is in front.
    property var notifiedApprovals: ({})
    onMissionsChanged: {
        for (const m of missions) {
            if (m.status !== "approval_required" || notifiedApprovals[m.id]) continue
            notifiedApprovals[m.id] = true
            if (Qt.application.state !== Qt.ApplicationActive)
                shell.notify("APVIS needs your approval", m.preview || m.title)
        }
    }
    readonly property var answer: shell.ask || ({ state: "closed" })
    readonly property bool answering: (answer.state || "closed") !== "closed"
    readonly property string modeWord: answering ? "ANSWERING" : state.nucleus_mode === "attention" ? "ATTENTION" :
                                       state.nucleus_mode === "continuity_unknown" ? "CHECK" : "STANDBY"

    // ------------------------------------------------------------ layout (1920×1080 first; scales down)
    readonly property real barH: 40
    readonly property bool tall: height >= 1000
    readonly property real navW: width >= 1600 ? 190 : 168
    readonly property real leftX: navW + 36
    readonly property real leftW: Math.max(290, Math.min(380, width * 0.2))
    readonly property real rightW: Math.max(330, Math.min(460, width * 0.24))
    readonly property real rightX: width - rightW - 22
    readonly property real orbCX: (leftX + leftW + rightX) / 2
    readonly property real orbCY: barH + (height - barH) * 0.41
    readonly property real sphereD: Math.min(height * 0.36, (rightX - leftX - leftW) * 0.62)
    readonly property real tilesTop: height * 0.785
    readonly property real gapW: rightX - leftX - leftW          // room between the card columns
    // While an answer is on screen the core grows to the middle and the cards
    // glide out of the way; it eases back when the answer closes.
    property real expand: answering ? 1 : 0
    Behavior on expand { NumberAnimation { duration: 750; easing.type: Easing.InOutCubic } }
    function mix(a, b) { return a + (b - a) * expand }
    readonly property real coreCX: mix(orbCX, width / 2)          // the middle of the screen while answering
    readonly property real coreCY: mix(orbCY, barH + (height - barH) * 0.44)
    // The core item is always its expanded size; only the orb's scale and the
    // centre move, so nothing is repainted while it grows (smooth on the OptiPlex).
    readonly property real bigBox: Math.min((height - barH) * 0.95, (width - leftX) * 0.72)
    readonly property real answerScale: 1.55
    readonly property real orbScale: mix(sphereD * 2 / Math.max(1, bigBox), answerScale)
    readonly property real tileW: Math.min(118, (gapW - 40 - 5 * 14) / 6)

    // ------------------------------------------------------------ background
    Item {
        id: room
        anchors.fill: parent
        layer.enabled: root.lite
        Wallpaper { anchors.fill: parent; centre: Qt.point(root.orbCX / Math.max(1, root.width), root.orbCY / Math.max(1, root.height)) }
    }

    // ------------------------------------------------------------ the core
    Nucleus {
        id: nucleus
        width: root.bigBox; height: width
        orbScale: root.orbScale
        expanded: root.expand
        vsync: !(shell.render || {}).software
        answerScale: root.answerScale
        x: root.coreCX - width / 2; y: root.coreCY - height / 2
        opacity: root.pageOpen ? 0 : 1
        visible: opacity > 0.01
        Behavior on opacity { NumberAnimation { duration: 280; easing.type: Easing.OutCubic } }
        scale: root.pageOpen ? 0.92 : 1
        Behavior on scale { NumberAnimation { duration: 340; easing.type: Easing.OutCubic } }
        renderer: (shell.render || {}).renderer || "canvas"
        particles: (shell.render || {}).particles || 900
        reducedMotion: !!(shell.render || {}).reducedMotion
        canvasPoints: shell.canvasPoints
        clock: shell.clock
        motion: (shell.nucleus || {}).motion || ({})
        shape: root.answering ? "aperture" : ((shell.nucleus || {}).shape || "sphere")
        answer: root.answer
        onCloseAnswer: { shell.closeAnswer(); focusInput.forceActiveFocus() }
        onAcceptMemory: (proposalId) => { shell.acceptMemory(proposalId); focusInput.forceActiveFocus() }
        onRejectMemory: (proposalId) => { shell.rejectMemory(proposalId); focusInput.forceActiveFocus() }
        onApproveMission: (missionId, token) => { shell.approveMission(missionId, token); focusInput.forceActiveFocus() }
        onCancelMission: (missionId) => { shell.cancelMission(missionId); focusInput.forceActiveFocus() }
        pin: (shell.nucleus || {}).pin || null
        preview: !!(shell.nucleus || {}).preview
        hasFocus: !!root.focus
        approvals: root.counts.approval_required || 0
        running: root.counts.running || 0
        attention: (root.counts.interrupted || 0) + (root.state.unreadable_task_count || 0)
        rich: !root.lite
        orbMode: root.answer.state === "thinking" ? "thinking" : root.answering ? "answering" :
                 root.state.nucleus_mode === "attention" || root.activeMissions.length ? "attention" : "idle"
        orbWord: root.answer.state === "thinking" ? "THINKING…" : root.answering ? "ANSWERING" :
                 root.activeMissions.length ? "WAITING FOR YOU" : root.state.nucleus_mode === "attention" ? "ATTENTION" : "READY"
        orbWordColour: root.activeMissions.length || root.state.nucleus_mode === "attention" ? Theme.attention : Theme.accent
        modeText: root.answering ? "ANSWERING" : root.state.nucleus_mode === "attention" ? "ATTENTION" : "IDLE"
        modeColor: root.state.nucleus_mode === "attention" ? Theme.attention : Theme.muted
    }

    // ------------------------------------------------------------ Home content (hidden on pages)
    Item {
        id: homeLayer
        anchors.fill: parent
        readonly property bool shown: !root.pageOpen && !intro.active
        opacity: root.pageOpen ? 0 : 1
        visible: opacity > 0.01
        Behavior on opacity { NumberAnimation { duration: 260; easing.type: Easing.OutCubic } }

        BrandBlock {
            x: 34; y: root.barH + 18 - 30 * root.expand
            markSize: root.tall ? 104 : 78
            version: ((shell.updates || {}).installed || "").replace(/^0$/, "") || ""
            opacity: (homeLayer.shown ? 1 : 0) * (1 - root.expand)
            Behavior on opacity { enabled: !root.answering && root.expand === 0; NumberAnimation { duration: 700 } }
        }

        // Left column.
        Column {
            x: root.leftX - (root.leftW + 80) * root.expand; y: root.barH + (root.tall ? 205 : 150); width: root.leftW; spacing: 16
            opacity: 1 - root.expand; visible: opacity > 0.01
            StatusCard { width: parent.width; order: 1; shown: homeLayer.shown; onGo: key => root.act(key) }
            DevicesCard { width: parent.width; order: 2; shown: homeLayer.shown; onGo: key => root.act(key) }
        }
        // Right column.
        Column {
            x: root.rightX + (root.rightW + 60) * root.expand; y: root.barH + (root.tall ? 156 : 110); width: root.rightW; spacing: 16
            opacity: 1 - root.expand; visible: opacity > 0.01
            TaskCard { width: parent.width; order: 2; shown: homeLayer.shown; onGo: key => root.act(key) }
            RouteCard { width: parent.width; order: 3; shown: homeLayer.shown; onGo: key => root.act(key) }
            ActivityCard { width: parent.width; order: 4; shown: homeLayer.shown; visible: root.tall; rows: 4; onGo: key => root.act(key) }
            IntelCard { width: parent.width; order: 5; shown: homeLayer.shown; onGo: key => root.act(key) }
        }

        // "How can I help?" beside the core; clicking it starts typing.
        Text {
            x: root.orbCX + root.sphereD / 2 + 22; y: root.orbCY - height / 2 - root.sphereD * 0.02
            visible: x + width < root.rightX - 8
            text: "“How can I help?”"; color: Theme.text; font.pixelSize: 22; font.weight: Font.Light
            opacity: homeLayer.shown && !root.answering ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: 600 } }
            MouseArea { anchors.fill: parent; cursorShape: Qt.IBeamCursor; onClicked: focusInput.forceActiveFocus() }
        }

        // Ask bar under the core.
        Item {
            id: askBar
            width: Math.min(560, root.gapW - 60); height: 50
            x: root.coreCX - width / 2
            y: root.mix(Math.min(root.orbCY + root.sphereD * 0.66, root.tilesTop - height - 24), root.height - height - 26)
            Chamfer { anchors.fill: parent; cut: 25; fill: Theme.panel; fillOpacity: 0.85; fill2: Theme.bgBottom; fill2Opacity: 0.9
                      stroke: focusInput.activeFocus ? Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.7) : Theme.line
                      edgeGlow: focusInput.activeFocus }
            Glyph { x: 20; anchors.verticalCenter: parent.verticalCenter; width: 18; height: 18; kind: "ask"
                    stroke: focusInput.activeFocus ? Theme.accent : Theme.muted }
            TextField {
                id: focusInput
                x: 50; width: parent.width - x - 58; height: 44
                anchors.verticalCenter: parent.verticalCenter
                placeholderText: "Ask APVIS anything…"
                color: root.pale; placeholderTextColor: root.muted
                selectByMouse: true; font.pixelSize: 15
                verticalAlignment: TextInput.AlignVCenter
                focus: true  // typing on Home goes straight to Ask
                Accessible.name: "Ask APVIS"
                background: Item {}
                onAccepted: { shell.askQuestion(text); text = "" }
                Keys.onEscapePressed: shell.closeAnswer()
            }
            Button {
                id: send
                anchors.right: parent.right; anchors.rightMargin: 7; anchors.verticalCenter: parent.verticalCenter
                width: 38; height: 38
                Accessible.name: "Ask"
                onClicked: { shell.askQuestion(focusInput.text); focusInput.text = "" }
                contentItem: Text { text: "›"; color: "#000000"; font.pixelSize: 24; font.bold: true
                                    horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter }
                background: Rectangle { radius: 19; color: send.hovered || send.activeFocus ? Theme.text : Theme.accent }
            }
        }
        Text {
            visible: shell.actionError.length > 0
            anchors.horizontalCenter: askBar.horizontalCenter; y: askBar.y - 20
            text: shell.actionError; color: Theme.attention; font.pixelSize: 12
        }

        ActionTiles {
            x: root.orbCX - width / 2; y: root.tilesTop + 220 * root.expand
            opacity: 1 - root.expand; visible: opacity > 0.01
            tileWidth: root.tileW; tileHeight: root.tall ? 88 : 78
            order: 4; shown: homeLayer.shown
            onChosen: key => {
                if (key === "ask") focusInput.forceActiveFocus()
                else if (key === "search") root.openSearch()
                else if (key === "create") shell.newNote()
                else if (key === "automate") root.openPage("missions")
                else if (key === "analyse") shell.askQuestion("analyse my computer")
                else if (key === "more") shell.launch("apps")
            }
        }
        TerminalCard {
            id: termCard
            x: 20; width: Math.min(500, root.leftX + root.leftW - 20)
            height: root.tall ? 212 : 190
            y: root.height - height - 22 + (height + 40) * root.expand
            visible: width >= 380 && root.tall && root.expand < 0.99      // below the Devices card only when there is room
            opacity: homeLayer.shown ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: 800 } }
            onAction: key => key.startsWith("ask:") ? shell.askQuestion(key.slice(4)) : root.act(key)
            onReleased: focusInput.forceActiveFocus()
        }
    }

    // ------------------------------------------------------------ pages
    Item {
        id: pages
        x: root.leftX; y: root.barH + 16
        width: root.width - x - 22; height: root.height - y - 20
        Column {
            visible: root.sharedDisplay && (root.notesOpen || root.missionsOpen)
            anchors.centerIn: parent; spacing: 12
            Glyph { anchors.horizontalCenter: parent.horizontalCenter; width: 34; height: 34; kind: "brain"; stroke: Theme.attention }
            Text { anchors.horizontalCenter: parent.horizontalCenter; text: "Private — a second screen is connected"; color: root.pale; font.pixelSize: 18 }
            Text { anchors.horizontalCenter: parent.horizontalCenter; text: "Your memory and missions stay hidden until you confirm the screens are yours."
                   color: root.muted; font.pixelSize: 12 }
        }
        component PageSlot: Item {
            property bool open: false
            anchors.fill: parent
            opacity: open ? 1 : 0
            visible: open || opacity > 0.01
            Behavior on opacity { NumberAnimation { duration: 240; easing.type: Easing.OutCubic } }
            transform: Translate { y: open ? 0 : 16; Behavior on y { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } } }
        }
        PageSlot { open: root.settingsOpen; SettingsPage { id: settingsPage; anchors.fill: parent } }
        PageSlot {
            open: root.atlasOpen
            Atlas {
                id: atlasPage
                anchors.fill: parent
                info: shell.atlas || ({ status: "off" })
                aircraftJson: shell.atlasAircraft
                mapJson: shell.atlasMap
                worldJson: shell.atlasWorld
                landJson: shell.worldLand
                dotsJson: shell.earthDots
                onAreaChanged: (lat, lon) => shell.setAtlasArea(lat, lon)
                onVisibleChanged: shell.setAtlasVisible(visible)
                Component.onCompleted: shell.setAtlasVisible(visible)
                onFocusFlight: (callsign, hexId) => shell.focusFlight(callsign, hexId)
            }
        }
        PageSlot { open: root.installOpen; InstallPage { id: installPage; anchors.fill: parent } }
        PageSlot { open: root.devOpen; DeveloperPage { id: devPage; anchors.fill: parent } }
        PageSlot { open: root.systemOpen; SystemPage { anchors.fill: parent } }
        PageSlot { open: root.devicesOpen; DevicesPage { anchors.fill: parent } }
        PageSlot { open: root.notesOpen && !root.sharedDisplay
                   MemoryPage { id: memoryPage; anchors.fill: parent; onSuggest: text => root.suggestAsk(text) } }
        PageSlot { open: root.missionsOpen && !root.sharedDisplay
                   MissionsPage { anchors.fill: parent; onSuggest: text => root.suggestAsk(text) } }
    }

    // ------------------------------------------------------------ navigation (always there)
    NavRail {
        id: nav
        x: 16; width: root.navW
        y: root.pageOpen ? root.barH + 20 : root.barH + (root.tall ? 205 : 150)
        Behavior on y { NumberAnimation { duration: 420; easing.type: Easing.OutCubic } }
        current: root.currentPage
        badges: ({ missions: root.activeMissions.length > 0, notes: (shell.inbox || []).length > 0,
                   settings: (shell.updates || {}).state === "available" })
        onNavigate: key => root.act(key)
        opacity: intro.active ? 0 : 1
        Behavior on opacity { NumberAnimation { duration: 600 } }
    }

    // Trying from the USB: say so, and offer the installer.
    Item {
        visible: !!(shell.installer || {}).live && !root.pageOpen && !root.sharedDisplay
        width: tryRow.width + 28; height: 40
        x: root.orbCX - width / 2; y: root.barH + 8
        Chamfer { anchors.fill: parent; cut: 20; fill: Theme.panel; fillOpacity: 0.92; stroke: Theme.line }
        Row {
            id: tryRow
            anchors.centerIn: parent; spacing: 12
            Glyph { width: 16; height: 16; kind: "device"; stroke: Theme.accent; anchors.verticalCenter: parent.verticalCenter }
            Text { text: "You're trying APVIS OS from the USB — nothing is saved to this computer"; color: Theme.text; font.pixelSize: 12
                   anchors.verticalCenter: parent.verticalCenter }
            HudButton { width: 110; implicitHeight: 30; caption: "Install…"; tone: "primary"; anchors.verticalCenter: parent.verticalCenter
                        onClicked: root.openPage("install") }
        }
    }

    // Second-screen privacy banner.
    Item {
        visible: root.sharedDisplay
        width: bannerRow.width + 28; height: 40
        x: (root.width - width) / 2; y: root.barH + 8
        Chamfer { anchors.fill: parent; cut: 20; fill: Theme.panel; fillOpacity: 0.95; stroke: Theme.attention }
        Row {
            id: bannerRow
            anchors.centerIn: parent; spacing: 12
            Glyph { width: 16; height: 16; kind: "device"; stroke: Theme.attention; anchors.verticalCenter: parent.verticalCenter }
            Text { text: "Second screen connected — private details hidden"; color: root.pale; font.pixelSize: 12; anchors.verticalCenter: parent.verticalCenter }
            HudButton { width: 150; caption: "They're my screens"; onClicked: root.trustedScreens = true; anchors.verticalCenter: parent.verticalCenter }
        }
    }

    // Terminal from Home with keys compact keyboards can press (Win+Enter is
    // awkward on Rii mini keyboards): Ctrl+Alt+T or Ctrl+Alt+Del.
    Shortcut { sequences: ["Ctrl+Alt+T", "Ctrl+Alt+Del", "Ctrl+Alt+Backspace"]; enabled: !root.locked; onActivated: shell.launch("terminal") }

    // ------------------------------------------------------------ menu bar
    MouseArea { anchors.fill: parent; visible: topBar.openMenu !== ""; onClicked: topBar.openMenu = "" }
    Shortcut { sequences: [StandardKey.Cancel]; enabled: topBar.openMenu !== ""; onActivated: topBar.openMenu = "" }
    TopBar {
        id: topBar
        width: root.width
        now: root.nowTick
        powerOpen: root.powerMenuOpen
        onAction: key => root.act(key)
        opacity: intro.active ? 0 : 1
        Behavior on opacity { NumberAnimation { duration: 600 } }
    }

    // ------------------------------------------------------------ power menu (top right)
    property bool powerMenuOpen: previewPage === "power"
    Shortcut { sequences: [StandardKey.Cancel]; enabled: root.powerMenuOpen; onActivated: root.powerMenuOpen = false }
    MouseArea { anchors.fill: parent; visible: root.powerMenuOpen; onClicked: root.powerMenuOpen = false }
    Item {
        id: powerMenu
        visible: root.powerMenuOpen || opacity > 0.01
        opacity: root.powerMenuOpen ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }
        transform: Translate { y: root.powerMenuOpen ? 0 : -8; Behavior on y { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } } }
        width: powerMenuRow.width + 150; height: powerMenuCol.height + 32
        x: root.width - width - 14; y: root.barH + 6
        MouseArea { anchors.fill: parent }
        Chamfer { anchors.fill: parent; cut: 14; fill: Theme.panel; fillOpacity: 0.97; fill2: Theme.bgBottom; fill2Opacity: 0.97
                  stroke: Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.4); edgeGlow: true }
        Column {
            id: powerMenuCol
            x: 16; y: 16; spacing: 12
            Text { text: "Power"; color: Theme.text; font.pixelSize: 15 }
            Row {
                spacing: 6
                HudButton { width: 112; glyph: "key"; caption: "Lock"; onClicked: { root.powerMenuOpen = false; root.lockNow() } }
                PowerButtons { id: powerMenuRow; buttonWidth: 112 }
            }
            Text { text: (shell.control || {}).message || "Press a button twice to confirm."; color: Theme.muted; font.pixelSize: 11 }
        }
    }

    // ------------------------------------------------------------ Control Centre (owner concept, screen 07)
    // Real state only; every change is read back.
    property bool controlOpen: previewPage === "control"
    function toggleControl() {
        if (locked) return
        controlOpen = !controlOpen
        if (controlOpen) { shell.refreshControl(); controlFirst.forceActiveFocus() } else focusInput.forceActiveFocus()
    }
    Shortcut { sequences: [StandardKey.Cancel]; enabled: root.controlOpen && !root.keysOpen; onActivated: root.toggleControl() }
    readonly property var ctl: shell.control || ({})
    readonly property var ctlSound: (ctl.state || {}).sound || ({})
    // The sound state arrives after the panel opens: move focus to the slider then.
    onCtlSoundChanged: if (controlOpen && ctlSound.available && dndButton.activeFocus) volSlider.forceActiveFocus()
    readonly property var ctlWifi: (ctl.state || {}).wifi || ({})
    Timer { interval: 5000; repeat: true; running: root.controlOpen; onTriggered: shell.refreshControl() }
    MouseArea { anchors.fill: parent; visible: root.controlOpen; onClicked: root.controlOpen = false }
    Item {
        id: controlPanel
        opacity: root.controlOpen ? 1 : 0
        visible: root.controlOpen || opacity > 0.01
        Behavior on opacity { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
        transform: Translate { y: root.controlOpen ? 0 : -10; Behavior on y { NumberAnimation { duration: 240; easing.type: Easing.OutCubic } } }
        scale: root.controlOpen ? 1 : 0.97
        Behavior on scale { NumberAnimation { duration: 240; easing.type: Easing.OutCubic } }
        width: 440; height: controlCol.height + 36
        x: root.width - width - 14; y: root.barH + 6
        MouseArea { anchors.fill: parent }
        Chamfer { anchors.fill: parent; cut: 16; fill: Theme.panel; fillOpacity: 0.97; fill2: Theme.bgBottom; fill2Opacity: 0.97
                  stroke: Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.4); edgeGlow: true }
        // Keyboard entry point (the slider when sound exists, else the first switch).
        Item { id: controlFirst; focus: false
               onActiveFocusChanged: if (activeFocus) (volSlider.visible ? volSlider : wifiButton.visible ? wifiButton : dndButton).forceActiveFocus() }
        component StatTileSmall: Item {
            property string glyph: ""
            property string label: ""
            property string value: ""
            property real fraction: -1
            width: (controlCol.width - 30) / 4; height: 76
            Chamfer { anchors.fill: parent; cut: 10; fill: Theme.raised; fillOpacity: 0.7; stroke: Theme.line }
            Text { x: 10; y: 9; text: parent.label; color: Theme.muted; font.pixelSize: 11 }
            Glyph { x: 10; y: 34; width: 16; height: 16; kind: parent.glyph; stroke: Theme.accent }
            Text { x: 32; y: 32; text: parent.value; color: Theme.text; font.pixelSize: 15 }
            Rectangle { visible: parent.fraction >= 0; x: 10; y: parent.height - 12; width: parent.width - 20; height: 3; radius: 1.5; color: Qt.rgba(1, 1, 1, 0.08)
                        Rectangle { height: parent.height; radius: 1.5; width: parent.width * Math.max(0, Math.min(1, parent.parent.fraction)); color: Theme.accent } }
        }
        Column {
            id: controlCol
            x: 18; y: 18; width: parent.width - 36; spacing: 12
            Row {
                width: parent.width
                Text { text: "Control Centre"; color: Theme.text; font.pixelSize: 16; width: parent.width - 40 }
                Text { text: Qt.formatDateTime(root.nowTick, "HH:mm"); color: Theme.muted; font.pixelSize: 13 }
            }
            Row {
                spacing: 10
                StatTileSmall { glyph: "cpu"; label: "CPU"; value: root.sys.available ? root.sys.cpu + "%" : "—"; fraction: root.sys.available ? root.sys.cpu / 100 : -1 }
                StatTileSmall { glyph: "memory"; label: "Memory"; value: root.sys.available ? root.sys.memory + "%" : "—"; fraction: root.sys.available ? root.sys.memory / 100 : -1 }
                StatTileSmall { glyph: "storage"; label: "Storage"; value: root.sys.disk !== null && root.sys.disk !== undefined ? root.sys.disk + "%" : "—"
                                fraction: root.sys.disk !== null && root.sys.disk !== undefined ? root.sys.disk / 100 : -1 }
                StatTileSmall { glyph: "clock"; label: "Uptime"; value: root.sys.boot_epoch_ms ? (function () {
                                    const s = Math.floor((root.nowTick.getTime() - root.sys.boot_epoch_ms) / 1000)
                                    return Math.floor(s / 3600) + "h " + Math.floor(s % 3600 / 60) + "m" })() : "—" }
            }
            // Sound.
            Item {
                width: parent.width; height: 26
                Glyph { width: 16; height: 16; kind: "volume"; stroke: Theme.accent; anchors.verticalCenter: parent.verticalCenter }
                Text { x: 26; text: "Sound"; color: Theme.text; font.pixelSize: 13; anchors.verticalCenter: parent.verticalCenter }
                Text { anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter; color: Theme.muted; font.pixelSize: 12
                       text: !root.ctlSound.available ? (root.ctlSound.detail || "Checking…") : root.ctlSound.muted ? "Muted" : root.ctlSound.volume + "%"
                       width: parent.width - 120; horizontalAlignment: Text.AlignRight; elide: Text.ElideRight }
            }
            Item {
                visible: !!root.ctlSound.available
                width: parent.width; height: 40
                Slider {
                    id: volSlider
                    anchors.verticalCenter: parent.verticalCenter
                    width: parent.width - 100; from: 0; to: 100; stepSize: 1
                    value: root.ctlSound.volume || 0
                    Accessible.name: "Volume"
                    onMoved: volDebounce.restart()
                    background: Item {
                        x: volSlider.leftPadding; y: volSlider.topPadding + volSlider.availableHeight / 2 - 2
                        width: volSlider.availableWidth; height: 4
                        Rectangle { anchors.fill: parent; radius: 2; color: Theme.raised; border.color: Theme.line }
                        Rectangle { width: volSlider.visualPosition * parent.width; height: parent.height; radius: 2; color: Theme.accent }
                    }
                    handle: Rectangle {
                        x: volSlider.leftPadding + volSlider.visualPosition * (volSlider.availableWidth - width)
                        y: volSlider.topPadding + volSlider.availableHeight / 2 - height / 2
                        width: 16; height: 16; radius: 8; color: Theme.text
                        border.width: volSlider.activeFocus ? 3 : 1; border.color: Theme.accent
                    }
                    Timer { id: volDebounce; interval: 180; onTriggered: shell.setVolume(Math.round(volSlider.value)) }
                }
                HudButton { anchors.right: parent.right; width: 90; caption: root.ctlSound.muted ? "Unmute" : "Mute"; onClicked: shell.setMuted(!root.ctlSound.muted) }
            }
            Item {
                visible: !(root.ctlWifi.available && root.ctlWifi.hasWifi)
                width: parent.width; height: 26
                Glyph { width: 16; height: 16; kind: "wifi"; stroke: Theme.accent; anchors.verticalCenter: parent.verticalCenter }
                Text { x: 26; text: "Network"; color: Theme.text; font.pixelSize: 13; anchors.verticalCenter: parent.verticalCenter }
                Text { anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter; color: Theme.muted; font.pixelSize: 12
                       text: !root.ctlWifi.available ? (root.ctlWifi.detail || "Checking…") : (root.ctlWifi.wired ? "Wired · " + root.ctlWifi.wired : "No Wi-Fi adapter")
                       width: parent.width - 120; horizontalAlignment: Text.AlignRight; elide: Text.ElideRight }
            }
            HudToggle {
                id: wifiButton
                visible: !!root.ctlWifi.available && !!root.ctlWifi.hasWifi
                width: parent.width; on: !!root.ctlWifi.on; caption: "Wi-Fi"
                detail: !root.ctlWifi.on ? "Off" : (root.ctlWifi.network || "On · not connected")
                onClicked: shell.setWifi(!root.ctlWifi.on)
            }
            HudToggle { id: dndButton; width: parent.width; on: !!(shell.settings || {}).dnd; caption: "Do not disturb"
                        detail: "Hides notifications. Approvals always get through."
                        onClicked: shell.setDoNotDisturb(!(shell.settings || {}).dnd) }
            HudToggle { width: parent.width; on: !!(shell.render || {}).reducedMotion; caption: "Reduce motion"
                        detail: "Stills the core's smoke and the effects."
                        onClicked: shell.setReducedMotion(!(shell.render || {}).reducedMotion) }
            Text {
                width: parent.width; wrapMode: Text.WordWrap; font.pixelSize: 11
                visible: text.length > 0
                text: root.ctl.message || ""
                color: root.ctl.ok === false ? Theme.attention : Theme.accent
            }
            Row {
                spacing: 8
                HudButton { width: (controlCol.width - 16) / 3; glyph: "screen"; caption: "Displays"; onClicked: shell.launch("displays") }
                HudButton { width: (controlCol.width - 16) / 3; glyph: "volume"; caption: "Audio"; onClicked: shell.launch("sound") }
                HudButton { width: (controlCol.width - 16) / 3; glyph: "wifi"; caption: "Network"; onClicked: shell.launch("network") }
            }
            Text { text: "POWER"; color: Theme.muted; font.pixelSize: 10; font.letterSpacing: 2; topPadding: 2 }
            PowerButtons { buttonWidth: (controlCol.width - 18) / 4 }
        }
    }

    // ------------------------------------------------------------ shortcuts (F1)
    // Mirrors /etc/apvis-os/labwc/rc.xml and the Home shortcuts; keep them in step.
    property bool keysOpen: previewPage === "keys"
    Shortcut { sequences: ["F1"]; enabled: !root.locked; onActivated: root.keysOpen = !root.keysOpen }
    Shortcut { sequences: [StandardKey.Cancel]; enabled: root.keysOpen; onActivated: root.keysOpen = false }
    Rectangle {
        anchors.fill: parent; color: Qt.rgba(0, 0, 0, 0.55)
        opacity: root.keysOpen ? 1 : 0; visible: root.keysOpen || opacity > 0.01
        Behavior on opacity { NumberAnimation { duration: 180 } }
        MouseArea { anchors.fill: parent; onClicked: root.keysOpen = false }
    }
    Item {
        opacity: root.keysOpen ? 1 : 0
        visible: root.keysOpen || opacity > 0.01
        Behavior on opacity { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
        scale: root.keysOpen ? 1 : 0.97
        Behavior on scale { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }
        width: Math.min(640, root.width - 80); height: keysCol.height + 44
        x: (root.width - width) / 2; y: (root.height - height) / 2
        Chamfer { anchors.fill: parent; cut: 16; fill: Theme.panel; fillOpacity: 0.97; fill2: Theme.bgBottom; fill2Opacity: 0.97
                  stroke: Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.4); edgeGlow: true }
        Column {
            id: keysCol
            x: 26; y: 22; width: parent.width - 52; spacing: 7
            Text { text: "Keyboard shortcuts"; color: Theme.text; font.pixelSize: 17; bottomPadding: 8 }
            Repeater {
                model: [
                    ["Ctrl + K", "Search this computer"], ["F1", "This list"], ["Esc", "Close a panel, page or answer"],
                    ["Type on Home", "Ask APVIS"], ["Win + P", "Bring APVIS Home back"],
                    ["Win + Space", "All apps"], ["Win + E", "Files"], ["Win + Enter  or  Ctrl + Alt + T / Del", "Terminal"],
                    ["Alt + Tab", "Next window"], ["Alt + F4", "Close window"],
                    ["Win + ← / →", "Previous / next workspace"], ["Win + Shift + ← / →", "Move window to that workspace"]
                ]
                delegate: Item {
                    required property var modelData
                    width: keysCol.width; height: 26
                    Rectangle { width: keyText.width + 18; height: 24; radius: 6; color: Theme.raised; border.color: Theme.line
                        Text { id: keyText; anchors.centerIn: parent; text: modelData[0]; color: Theme.accent; font.family: "monospace"; font.pixelSize: 11 } }
                    Text { x: 250; anchors.verticalCenter: parent.verticalCenter; text: modelData[1]; color: root.pale; font.pixelSize: 13 }
                }
            }
        }
    }

    // ------------------------------------------------------------ search (Ctrl+K)
    // One local search: apps, pages, settings, notes, missions and home files.
    // Nothing leaves this computer; only listed results can be opened.
    property bool searchOpen: false
    function openSearch() { if (locked) return; searchOpen = true; searchField.text = ""; shell.search(""); searchField.forceActiveFocus() }
    function closeSearch() { searchOpen = false; focusInput.forceActiveFocus() }
    function openHit(i) {
        const r = (shell.searchResults || [])[i]
        if (!r) return
        closeSearch()
        shell.openResult(r.kind, r.key)
    }
    function hitGlyph(r) {
        if (r.kind === "page") return r.key === "home" ? "home" : r.key === "missions" ? "mission" : r.key
        return { app: "apps", setting: "settings", note: "notes", mission: "mission", file: "files", folder: "files" }[r.kind] || "search"
    }
    Shortcut { sequences: ["Ctrl+K", "Ctrl+F"]; onActivated: root.searchOpen ? root.closeSearch() : root.openSearch() }
    Rectangle {
        anchors.fill: parent; color: Qt.rgba(0, 0, 0, 0.55)
        opacity: root.searchOpen ? 1 : 0; visible: root.searchOpen || opacity > 0.01
        Behavior on opacity { NumberAnimation { duration: 180 } }
        MouseArea { anchors.fill: parent; onClicked: root.closeSearch() }
    }
    Item {
        id: searchPanel
        opacity: root.searchOpen ? 1 : 0
        visible: root.searchOpen || opacity > 0.01
        Behavior on opacity { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
        scale: root.searchOpen ? 1 : 0.97
        Behavior on scale { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }
        width: Math.min(680, root.width - 80)
        height: 62 + (hitList.count ? hitList.height + 10 : searchField.text.length ? 40 : 0) + 26
        x: (root.width - width) / 2; y: Math.max(70, root.height * 0.14)
        MouseArea { anchors.fill: parent }  // clicks inside do not close it
        Chamfer { anchors.fill: parent; cut: 16; fill: Theme.panel; fillOpacity: 0.97; fill2: Theme.bgBottom; fill2Opacity: 0.97
                  stroke: Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.45); edgeGlow: true }
        Glyph { x: 20; y: 21; width: 20; height: 20; kind: "search"; stroke: Theme.accent }
        TextField {
            id: searchField
            x: 50; y: 9; width: parent.width - 66; height: 44
            placeholderText: "Search apps, files, notes, settings…"
            color: root.pale; placeholderTextColor: root.muted
            font.pixelSize: 16; selectByMouse: true
            background: Item {}
            Accessible.name: "Search this computer"
            onTextChanged: { hitList.currentIndex = 0; searchDebounce.restart() }
            Keys.onDownPressed: hitList.incrementCurrentIndex()
            Keys.onUpPressed: hitList.decrementCurrentIndex()
            Keys.onEscapePressed: root.closeSearch()
            onAccepted: root.openHit(hitList.currentIndex)
        }
        Timer { id: searchDebounce; interval: 120; onTriggered: shell.search(searchField.text) }
        Rectangle { x: 14; y: 58; width: parent.width - 28; height: 1; color: Theme.line }
        ListView {
            id: hitList
            x: 10; y: 66; width: parent.width - 20
            height: Math.min(count, 8) * 46
            clip: true; currentIndex: 0
            model: shell.searchResults || []
            delegate: Item {
                id: hit
                required property var modelData
                required property int index
                readonly property bool current: ListView.isCurrentItem
                width: ListView.view.width; height: 46
                Rectangle { anchors.fill: parent; anchors.margins: 2; radius: 8
                            color: hit.current ? Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.14) : hitMouse.containsMouse ? Theme.hover : "transparent"
                            border.width: hit.current ? 1 : 0; border.color: Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.5) }
                Glyph { x: 14; anchors.verticalCenter: parent.verticalCenter; width: 18; height: 18; kind: root.hitGlyph(hit.modelData); stroke: hit.current ? Theme.accent : Theme.muted }
                Column {
                    x: 46; anchors.verticalCenter: parent.verticalCenter; width: parent.width - 46 - 90; spacing: 2
                    Text { width: parent.width; text: hit.modelData.title; color: Theme.text; font.pixelSize: 14; elide: Text.ElideRight }
                    Text { width: parent.width; text: hit.modelData.detail; color: Theme.muted; font.pixelSize: 11; elide: Text.ElideMiddle }
                }
                Text { anchors.right: parent.right; anchors.rightMargin: 14; anchors.verticalCenter: parent.verticalCenter
                       text: hit.modelData.kind.toUpperCase(); color: hit.current ? Theme.accent : Theme.muted
                       font.family: "monospace"; font.pixelSize: 9; font.letterSpacing: 1.2 }
                MouseArea { id: hitMouse; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: root.openHit(hit.index) }
                Accessible.role: Accessible.ListItem
                Accessible.name: hit.modelData.title + ", " + hit.modelData.kind
            }
        }
        Text {
            visible: searchField.text.length > 0 && hitList.count === 0
            x: 50; y: 70; text: "Nothing on this computer matches."
            color: Theme.muted; font.pixelSize: 13
        }
        Text {
            anchors.bottom: parent.bottom; anchors.bottomMargin: 8; x: 20
            text: "↑ ↓ choose   ·   Enter open   ·   Esc close   ·   F1 shortcuts   ·   this computer only"
            color: Theme.muted; font.family: "monospace"; font.pixelSize: 9; font.letterSpacing: 0.8
        }
    }

    // ------------------------------------------------------------ awakening and goodbye
    IntroOverlay {
        id: intro
        anchors.fill: parent
        active: previewPage === "" && !previewNoIntro
        still: root.calm
        onFinished: root.locked ? lockScreen.engage() : focusInput.forceActiveFocus()
    }
    LockOverlay {
        id: lockScreen
        anchors.fill: parent
        now: root.nowTick
        onUnlocked: focusInput.forceActiveFocus()
    }
    GoodbyeOverlay {
        id: goodbye
        anchors.fill: parent
        onProceed: action => shell.power(action)
    }
}
