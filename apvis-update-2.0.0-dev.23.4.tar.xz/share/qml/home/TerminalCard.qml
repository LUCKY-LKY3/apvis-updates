import QtQuick
import "../theme"

// The terminal card (owner concept): a fastfetch-style look at this computer,
// with the APVIS mark in block characters. Real details only; opens a terminal.
Item {
    id: card
    signal openTerminal()
    readonly property var host: shell.host || ({})
    readonly property var sys: shell.system || ({})
    readonly property var route: shell.route || ({})
    property real now: Date.now()
    Timer { interval: 30000; running: card.visible; repeat: true; onTriggered: card.now = Date.now() }
    readonly property var logo: [
        "     ▄██▄     ", "    ██████    ", "   ███▀▀███   ", "  ███ ▄▄ ███  ",
        " ███ ████ ███ ", "███ ▀▀  ▀▀ ███"]
    function uptime() {
        if (!sys.boot_epoch_ms) return "—"
        const s = Math.max(0, (now - sys.boot_epoch_ms) / 1000), h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60)
        return (h ? h + (h === 1 ? " hour, " : " hours, ") : "") + m + (m === 1 ? " min" : " mins")
    }
    readonly property var facts: [
        ["OS", host.os || "APVIS OS"], ["Host", host.model || host.hostname || "—"], ["Kernel", host.kernel || "—"],
        ["Uptime", uptime()], ["APVIS", route.reachable ? "Online · local AI ready" : "Online"]]
    implicitHeight: 212

    Chamfer {
        anchors.fill: parent; cut: 12
        fill: "#010302"; fillOpacity: 0.86; stroke: Qt.rgba(Theme.line.r, Theme.line.g, Theme.line.b, 0.95); edgeGlow: true
    }
    Column {
        x: 16; y: 14; width: parent.width - 32; spacing: 10
        Text {
            textFormat: Text.StyledText
            text: "<font color='" + Theme.accent + "'>" + (card.host.user || "apvis") + "@" + (card.host.hostname || "apvis") + "</font>" +
                  "<font color='" + Theme.muted + "'>:~$</font> fastfetch"
            color: Theme.text; font.family: "monospace"; font.pixelSize: 13
        }
        Row {
            spacing: 18
            Column {
                spacing: 0
                Repeater {
                    model: card.logo
                    delegate: Text { required property string modelData; text: modelData; color: Theme.accent
                                     font.family: "monospace"; font.pixelSize: 12; lineHeight: 1.0 }
                }
            }
            Column {
                spacing: 3
                anchors.verticalCenter: parent.verticalCenter
                Repeater {
                    model: card.facts
                    delegate: Text {
                        required property var modelData
                        width: card.width - 32 - 18 - 130; elide: Text.ElideRight
                        textFormat: Text.StyledText
                        text: "<font color='" + Theme.accent + "'>" + modelData[0] + ":</font> " + modelData[1]
                        color: Theme.text; font.family: "monospace"; font.pixelSize: 12
                    }
                }
            }
        }
        Row {
            spacing: 4
            Text { text: "Intelligence. Control. Freedom."; color: Theme.accent; font.family: "monospace"; font.pixelSize: 13 }
            Rectangle { width: 8; height: 14; color: Theme.accent; anchors.verticalCenter: parent.verticalCenter
                        SequentialAnimation on opacity { running: card.visible; loops: Animation.Infinite
                            NumberAnimation { to: 0; duration: 1 } PauseAnimation { duration: 530 }
                            NumberAnimation { to: 1; duration: 1 } PauseAnimation { duration: 530 } } }
        }
    }
    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: card.openTerminal() }
    Accessible.role: Accessible.Button
    Accessible.name: "Open a terminal"
}
