import QtQuick
import "../theme"

// The Atlas globe: a holographic dot-matrix Earth, lit by the sun's real
// position now (night side dimmed), with the live events from the public
// feeds. Drag to turn it, scroll to zoom, click an event to select it,
// double-click to open the detailed map there. It turns slowly on its own
// unless motion is reduced or the owner is using it.
Item {
    id: globe
    property var dots: []                 // [lat, lon, lat, lon, ...] (earth-land-points)
    property var feeds: ({})              // { quakes: [...], alerts: [...], events: [...], iss: [...] } (already filtered by layer)
    property var issTrail: []
    property var selected: null           // { kind, id }
    property bool night: true
    property bool still: false
    property real lon0: -5                // centre of the view (Europe first)
    property real lat0: 24
    property real zoom: 1
    signal picked(string kind, var item)
    signal openMap(real lat, real lon)
    signal pointed(string where)

    readonly property real radius: Math.min(width, height) * 0.42 * zoom
    readonly property real cx: width / 2
    readonly property real cy: height / 2
    property real phase: 0
    property real idleUntil: 0
    property var hits: []

    Behavior on zoom { NumberAnimation { duration: 400; easing.type: Easing.OutCubic } }
    Behavior on lon0 { enabled: turnTo.running; NumberAnimation { duration: 900; easing.type: Easing.InOutCubic } }
    Behavior on lat0 { enabled: turnTo.running; NumberAnimation { duration: 900; easing.type: Easing.InOutCubic } }
    Timer { id: turnTo; interval: 950 }
    function focusOn(lat, lon) {
        let target = lon
        while (target - lon0 > 180) target -= 360
        while (target - lon0 < -180) target += 360
        idleUntil = Date.now() + 15000
        turnTo.restart()
        lon0 = target; lat0 = Math.max(-60, Math.min(60, lat))
    }

    // Unit vectors for the land dots, computed once.
    property var unit: []
    onDotsChanged: {
        const u = []
        for (let i = 0; i + 1 < dots.length; i += 2) {
            const la = dots[i] * Math.PI / 180, lo = dots[i + 1] * Math.PI / 180
            u.push(Math.cos(la) * Math.sin(lo), Math.sin(la), Math.cos(la) * Math.cos(lo))
        }
        unit = u
        art.requestPaint()
    }
    onFeedsChanged: art.requestPaint()
    onSelectedChanged: art.requestPaint()
    onZoomChanged: { frame.requestPaint(); art.requestPaint() }
    onWidthChanged: { frame.requestPaint(); art.requestPaint() }
    onHeightChanged: { frame.requestPaint(); art.requestPaint() }
    onLon0Changed: art.requestPaint()
    onLat0Changed: art.requestPaint()

    // ~25 fps turning and pulsing while visible (paused while dragging, after a pick, or with Reduce motion).
    Timer {
        interval: 40; repeat: true
        running: globe.visible && !globe.still
        onTriggered: {
            globe.phase = (globe.phase + 0.018) % 1
            if (!drag.pressed && Date.now() > globe.idleUntil && !turnTo.running) globe.lon0 = (globe.lon0 + 0.12) % 360
            art.requestPaint()
        }
    }

    function rgba(c, a) { return "rgba(" + Math.round(c.r * 255) + "," + Math.round(c.g * 255) + "," + Math.round(c.b * 255) + "," + a + ")" }
    function sun() {
        const d = new Date()
        const day = (Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()) - Date.UTC(d.getUTCFullYear(), 0, 0)) / 864e5
        const decl = -23.44 * Math.cos(2 * Math.PI / 365 * (day + 10)) * Math.PI / 180
        const sunLon = -(d.getUTCHours() + d.getUTCMinutes() / 60 - 12) * 15 * Math.PI / 180
        return [Math.cos(decl) * Math.sin(sunLon), Math.sin(decl), Math.cos(decl) * Math.cos(sunLon)]
    }
    // World → screen: [x, y, depth] (depth > 0 faces the viewer).
    function project(lat, lon) {
        const la = lat * Math.PI / 180, lo = lon * Math.PI / 180
        return projectUnit(Math.cos(la) * Math.sin(lo), Math.sin(la), Math.cos(la) * Math.cos(lo))
    }
    function projectUnit(x, y, z) {
        const a = lon0 * Math.PI / 180, p = lat0 * Math.PI / 180
        const ca = Math.cos(a), sa = Math.sin(a), cp = Math.cos(p), sp = Math.sin(p)
        const x1 = x * ca - z * sa, z1 = z * ca + x * sa
        const y2 = y * cp - z1 * sp, z2 = y * sp + z1 * cp
        return [cx + radius * x1, cy - radius * y2, z2]
    }
    function unproject(sx, sy) {
        const x1 = (sx - cx) / radius, y2 = (cy - sy) / radius, rr = x1 * x1 + y2 * y2
        if (rr > 1) return null
        const z2 = Math.sqrt(1 - rr)
        const a = lon0 * Math.PI / 180, p = lat0 * Math.PI / 180
        const y = y2 * Math.cos(p) + z2 * Math.sin(p), z1 = -y2 * Math.sin(p) + z2 * Math.cos(p)
        const x = x1 * Math.cos(a) + z1 * Math.sin(a), z = -x1 * Math.sin(a) + z1 * Math.cos(a)
        let lon = Math.atan2(x, z) * 180 / Math.PI
        return [Math.asin(Math.max(-1, Math.min(1, y))) * 180 / Math.PI, lon]
    }

    // Static: atmosphere halo and the ocean disk (repainted only on resize/zoom).
    Canvas {
        id: frame
        anchors.fill: parent
        Component.onCompleted: requestPaint()
        onPaint: {
            const c = getContext("2d"), R = globe.radius, x = globe.cx, y = globe.cy
            c.reset(); c.clearRect(0, 0, width, height)
            const halo = c.createRadialGradient(x, y, R * 0.92, x, y, R * 1.35)
            halo.addColorStop(0, globe.rgba(Theme.accent, 0.32)); halo.addColorStop(0.25, globe.rgba(Theme.accent, 0.12))
            halo.addColorStop(1, globe.rgba(Theme.accent, 0))
            c.fillStyle = halo; c.fillRect(x - R * 1.4, y - R * 1.4, R * 2.8, R * 2.8)
            const sea = c.createRadialGradient(x - R * 0.3, y - R * 0.35, R * 0.1, x, y, R)
            sea.addColorStop(0, "rgba(10,34,24,0.95)"); sea.addColorStop(0.7, "rgba(3,14,9,0.97)"); sea.addColorStop(1, "rgba(1,6,4,0.98)")
            c.fillStyle = sea; c.beginPath(); c.arc(x, y, R, 0, Math.PI * 2); c.fill()
            c.strokeStyle = globe.rgba(Theme.accent, 0.75); c.lineWidth = 1.4
            c.beginPath(); c.arc(x, y, R, 0, Math.PI * 2); c.stroke()
            c.strokeStyle = globe.rgba(Theme.accent, 0.15); c.lineWidth = 6
            c.beginPath(); c.arc(x, y, R + 3, 0, Math.PI * 2); c.stroke()
            // Outer HUD ring with ticks.
            c.strokeStyle = globe.rgba(Theme.accent, 0.25); c.lineWidth = 1
            c.beginPath(); c.arc(x, y, R * 1.12, 0, Math.PI * 2); c.stroke()
            for (let i = 0; i < 120; ++i) {
                const a = i / 120 * Math.PI * 2, major = i % 10 === 0
                c.strokeStyle = globe.rgba(Theme.accent, major ? 0.55 : 0.2)
                c.beginPath(); c.moveTo(x + Math.cos(a) * R * 1.12, y + Math.sin(a) * R * 1.12)
                c.lineTo(x + Math.cos(a) * (R * 1.12 + (major ? 9 : 4)), y + Math.sin(a) * (R * 1.12 + (major ? 9 : 4))); c.stroke()
            }
        }
    }

    // Dynamic: graticule, land, events.
    Canvas {
        id: art
        anchors.fill: parent
        renderStrategy: Canvas.Cooperative
        onPaint: {
            const c = getContext("2d"), R = globe.radius
            c.reset(); c.clearRect(0, 0, width, height)
            if (R < 10) return
            // Graticule (front half only).
            c.strokeStyle = globe.rgba(Theme.accent, 0.13); c.lineWidth = 0.8
            c.beginPath()
            for (let lo = -180; lo < 180; lo += 30) {
                let pen = false
                for (let la = -90; la <= 90; la += 5) {
                    const p = globe.project(la, lo)
                    if (p[2] > 0) { pen ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]); pen = true } else pen = false
                }
            }
            for (let la = -60; la <= 60; la += 30) {
                let pen = false
                for (let lo = -180; lo <= 180; lo += 5) {
                    const p = globe.project(la, lo)
                    if (p[2] > 0) { pen ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]); pen = true } else pen = false
                }
            }
            c.stroke()
            // Land dots: day bright, twilight mid, night dim; the limb fades.
            const u = globe.unit, S = globe.night ? globe.sun() : null
            const s = Math.max(1.6, R / 125)
            const day = [], dusk = [], dark = []
            const a = globe.lon0 * Math.PI / 180, p = globe.lat0 * Math.PI / 180
            const ca = Math.cos(a), sa = Math.sin(a), cp = Math.cos(p), sp = Math.sin(p)
            for (let i = 0; i + 2 < u.length; i += 3) {
                const x = u[i], y = u[i + 1], z = u[i + 2]
                const x1 = x * ca - z * sa, z1 = z * ca + x * sa
                const y2 = y * cp - z1 * sp, z2 = y * sp + z1 * cp
                if (z2 <= 0.02) continue
                const sx = globe.cx + R * x1, sy = globe.cy - R * y2
                const lit = S ? x * S[0] + y * S[1] + z * S[2] : 1
                ;(lit > 0.1 ? day : lit > -0.1 ? dusk : dark).push(sx, sy, z2)
            }
            function pass(list, colour, alpha) {
                c.fillStyle = globe.rgba(colour, alpha)
                c.beginPath()
                for (let i = 0; i < list.length; i += 3) {
                    const k = s * (0.55 + 0.45 * list[i + 2])
                    c.rect(list[i] - k / 2, list[i + 1] - k / 2, k, k)
                }
                c.fill()
            }
            pass(dark, Theme.accent, 0.42)
            pass(dusk, Theme.warm, 0.7)
            pass(day, Theme.accent, 1.0)
            // Events.
            const hits = []
            const sel = globe.selected
            const glow = (x, y, r, col, al) => { const g = c.createRadialGradient(x, y, 0, x, y, r)
                g.addColorStop(0, globe.rgba(col, al)); g.addColorStop(1, globe.rgba(col, 0)); c.fillStyle = g; c.fillRect(x - r, y - r, 2 * r, 2 * r) }
            const ring = (x, y, r) => { c.strokeStyle = globe.rgba(Theme.text, 1); c.lineWidth = 1.4; c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.stroke() }
            const f = globe.feeds || {}
            for (const i of (f.events || [])) {
                const q = globe.project(i.lat, i.lon); if (q[2] <= 0) continue
                const col = Qt.color(i.kind === "fire" ? "#ff8a4c" : i.kind === "storm" ? "#5ad1e6" : i.kind === "volcano" ? "#e46a5f" : Theme.muted)
                c.fillStyle = globe.rgba(col, 0.9); c.beginPath(); c.arc(q[0], q[1], 2.2 * s / 1.4, 0, Math.PI * 2); c.fill()
                hits.push([q[0], q[1], "events", i])
                if (sel && sel.kind === "events" && sel.id === i.id) ring(q[0], q[1], 10)
            }
            for (const i of (f.alerts || [])) {
                if (i.alert === "Green") continue
                const q = globe.project(i.lat, i.lon); if (q[2] <= 0) continue
                const col = Qt.color(i.alert === "Red" ? Theme.critical : Theme.warm)
                glow(q[0], q[1], 16, col, 0.35)
                c.strokeStyle = globe.rgba(col, 0.95); c.lineWidth = 1.5; c.beginPath(); c.arc(q[0], q[1], 6, 0, Math.PI * 2); c.stroke()
                hits.push([q[0], q[1], "alerts", i])
                if (sel && sel.kind === "alerts" && sel.id === i.id) ring(q[0], q[1], 13)
            }
            for (const i of (f.quakes || [])) {
                const q = globe.project(i.lat, i.lon); if (q[2] <= 0) continue
                const r = 1.8 + Math.pow(Math.max(0, i.mag - 2), 1.35) * 1.5, col = Qt.color(i.mag >= 6 ? Theme.critical : Theme.warm)
                glow(q[0], q[1], r * 3.2, col, 0.4)
                c.fillStyle = globe.rgba(col, 0.9); c.beginPath(); c.arc(q[0], q[1], r, 0, Math.PI * 2); c.fill()
                if (Date.now() - i.time_ms < 3 * 3600e3 && !globe.still)
                    for (const off of [0, 0.5]) { const t = (globe.phase + off) % 1
                        c.strokeStyle = globe.rgba(col, 0.7 * (1 - t)); c.lineWidth = 1.3; c.beginPath(); c.arc(q[0], q[1], r + t * 20, 0, Math.PI * 2); c.stroke() }
                hits.push([q[0], q[1], "quakes", i])
                if (sel && sel.kind === "quakes" && sel.id === i.id) ring(q[0], q[1], r + 8)
            }
            // ISS: its recent track and the station.
            const t = globe.issTrail
            c.lineWidth = 1.4
            for (let k = 1; k < t.length; ++k) {
                const p0 = globe.project(t[k - 1][0], t[k - 1][1]), p1 = globe.project(t[k][0], t[k][1])
                if (p0[2] <= 0 || p1[2] <= 0) continue
                c.strokeStyle = globe.rgba(Theme.text, 0.6 * k / t.length); c.beginPath(); c.moveTo(p0[0], p0[1]); c.lineTo(p1[0], p1[1]); c.stroke()
            }
            const iss = (f.iss || [])[0]
            if (iss) {
                const q = globe.project(iss.lat, iss.lon)
                if (q[2] > 0) {
                    glow(q[0], q[1], 20, Qt.color(Theme.text), 0.35)
                    c.fillStyle = globe.rgba(Theme.text, 1); c.fillRect(q[0] - 2.5, q[1] - 2.5, 5, 5)
                    c.fillRect(q[0] - 11, q[1] - 2.5, 5, 5); c.fillRect(q[0] + 6, q[1] - 2.5, 5, 5)
                    c.font = "bold 10px monospace"; c.fillText("ISS", q[0] + 14, q[1] + 4)
                    hits.push([q[0], q[1], "iss", iss])
                    if (sel && sel.kind === "iss") ring(q[0], q[1], 16)
                }
            }
            // A light sweeping round the limb.
            if (!globe.still) {
                const ang = globe.phase * Math.PI * 2
                c.strokeStyle = globe.rgba(Theme.accent, 0.9); c.lineWidth = 2
                c.beginPath(); c.arc(globe.cx, globe.cy, R * 1.12, ang, ang + 0.5); c.stroke()
                c.strokeStyle = globe.rgba(Theme.accent, 0.25); c.lineWidth = 6
                c.beginPath(); c.arc(globe.cx, globe.cy, R * 1.12, ang, ang + 0.5); c.stroke()
            }
            globe.hits = hits
        }
    }

    MouseArea {
        id: drag
        anchors.fill: parent
        hoverEnabled: true
        property real lastX: 0
        property real lastY: 0
        property bool moved: false
        cursorShape: pressed && moved ? Qt.ClosedHandCursor : Qt.OpenHandCursor
        onPressed: mouse => { lastX = mouse.x; lastY = mouse.y; moved = false; globe.idleUntil = Date.now() + 8000 }
        onPositionChanged: mouse => {
            const w = globe.unproject(mouse.x, mouse.y)
            globe.pointed(w ? Math.abs(w[0]).toFixed(2) + "°" + (w[0] >= 0 ? "N" : "S") + "  " + Math.abs(w[1]).toFixed(2) + "°" + (w[1] >= 0 ? "E" : "W") : "")
            if (!pressed) return
            const dx = mouse.x - lastX, dy = mouse.y - lastY
            if (Math.abs(dx) + Math.abs(dy) > 2) moved = true
            if (!moved) return
            const k = 180 / Math.PI / globe.radius
            globe.lon0 = globe.lon0 - dx * k
            globe.lat0 = Math.max(-70, Math.min(70, globe.lat0 + dy * k))
            lastX = mouse.x; lastY = mouse.y
            globe.idleUntil = Date.now() + 8000
        }
        onExited: globe.pointed("")
        onReleased: mouse => {
            if (moved) return
            let best = null, bestD = 16 * 16
            for (const h of globe.hits) {
                const d = (h[0] - mouse.x) * (h[0] - mouse.x) + (h[1] - mouse.y) * (h[1] - mouse.y)
                if (d < bestD) { bestD = d; best = h }
            }
            if (best) { globe.picked(best[2], best[3]); globe.focusOn(best[3].lat, best[3].lon) }
        }
        onDoubleClicked: mouse => { const w = globe.unproject(mouse.x, mouse.y); if (w) globe.openMap(w[0], w[1]) }
        onWheel: wheel => { globe.zoom = Math.max(0.6, Math.min(2.4, globe.zoom * (wheel.angleDelta.y > 0 ? 1.15 : 1 / 1.15))); globe.idleUntil = Date.now() + 8000 }
    }
}
