import QtQuick
import QtQuick.Controls
import "../theme"

// OSIRIS Atlas: UK airspace from public ADS-B sources (adsb.fi, falling back to ADSB.lol).
// Honesty rules (DESIGN-LANGUAGE / V2-06): every view says where the data comes
// from and how old it is; nothing old is drawn as current; trails are real past
// positions from earlier updates, never predictions. Aircraft glide from their
// last reported position to the new one when an update arrives; between updates
// they stay where they were last reported.
Item {
    id: atlas
    property var info: ({ status: "off" })
    property string aircraftJson: "[]"
    property string mapJson: "{}"
    signal focusFlight(string callsign, string hexId)

    readonly property var map: JSON.parse(mapJson)
    readonly property var stats: info.stats || ({})
    readonly property bool live: info.status === "live"

    // Row: [hex, callsign, reg, type, lat, lon, alt, ground, kt, track, age, emergency, vrate, typeName, trail]
    property var planes: []
    property var fromPos: ({})          // hex -> [lat, lon] before the latest update (for the glide)
    property real glide: 1
    onAircraftJsonChanged: {
        const previous = {}
        for (const p of planes) previous[p[0]] = [p[4], p[5]]
        fromPos = previous
        planes = JSON.parse(aircraftJson)
        receivedAt = Date.now()
        glideAnim.restart()
        trails.requestPaint()
    }
    NumberAnimation { id: glideAnim; target: atlas; property: "glide"; from: 0; to: 1; duration: 1100; easing.type: Easing.InOutCubic }
    onGlideChanged: aircraftLayer.requestPaint()

    property string selectedHex: ""
    readonly property var selected: {
        for (let i = 0; i < planes.length; ++i) if (planes[i][0] === selectedHex) return planes[i]
        return null
    }
    onSelectedHexChanged: { aircraftLayer.requestPaint(); trails.requestPaint() }

    // ---- filters
    property string filterText: ""
    property string filterKind: "all"          // all | air | ground | emergency
    function passes(p) {
        if (filterKind === "air" && p[7]) return false
        if (filterKind === "ground" && !p[7]) return false
        if (filterKind === "emergency" && !p[11]) return false
        if (!filterText) return true
        const q = filterText.toLowerCase()
        return (p[1] + " " + p[2] + " " + p[3] + " " + (p[13] || "") + " " + p[0]).toLowerCase().indexOf(q) >= 0
    }
    readonly property var shown: planes.filter(p => passes(p))
    onShownChanged: { aircraftLayer.requestPaint(); trails.requestPaint() }

    // ---- age that keeps counting between bridge updates
    property double receivedAt: Date.now()
    property int ageNow: 0
    Timer { interval: 1000; repeat: true; running: atlas.visible; triggeredOnStart: true
            onTriggered: atlas.ageNow = (atlas.info.age_s || 0) + Math.max(0, Math.round((Date.now() - atlas.receivedAt) / 1000)) }
    onInfoChanged: receivedAt = Date.now()

    // ---- helpers
    function nameOf(p) { return p[1] || p[2] || p[0].toUpperCase() }
    function heightOf(p) { return p[7] ? "On the ground" : (p[6] === null ? "Altitude unknown" : p[6].toLocaleString(Qt.locale("en_GB"), "f", 0) + " ft") }
    function band(p) { return p[7] ? 0 : p[6] === null ? 2 : p[6] < 10000 ? 1 : p[6] < 25000 ? 2 : p[6] < 35000 ? 3 : 4 }
    readonly property var bandColours: [Theme.muted, "#5ad1e6", Theme.accent, "#b8f0d8", Theme.text]
    function colourOf(p) { return p[11] ? Theme.attention : bandColours[band(p)] }
    function trend(p) { return p[12] === null || p[12] === undefined ? "" : p[12] > 300 ? "▲" : p[12] < -300 ? "▼" : "▶" }
    function distNm(lat1, lon1, lat2, lon2) {
        const r = Math.PI / 180, a = Math.pow(Math.sin((lat2 - lat1) * r / 2), 2) +
              Math.cos(lat1 * r) * Math.cos(lat2 * r) * Math.pow(Math.sin((lon2 - lon1) * r / 2), 2)
        return 2 * 3440.065 * Math.asin(Math.sqrt(a))
    }
    function nearestAirport(p) {
        let best = null, bestD = 1e9
        for (const ap of (map.airports || [])) {
            const d = distNm(p[4], p[5], ap[2], ap[3])
            if (d < bestD) { bestD = d; best = ap }
        }
        return best ? [best[0], best[1], Math.round(bestD)] : null
    }
    function statusLine() {
        if (info.status === "live") return "LIVE  ·  " + info.count + " aircraft  ·  updated " + ageNow + " s ago"
        if (info.status === "stale") return "STALE  ·  last update " + ageNow + " s ago  ·  not current"
        if (info.status === "unavailable") return "NO LIVE DATA  ·  " + (info.error || "source unreachable") +
                                                  (info.fetched_at ? "  ·  last good update " + info.fetched_at.replace("T", " ").replace("Z", " UTC") : "")
        if (info.status === "loading") return "Connecting to " + (info.source || "the flight data source") + "…"
        return ""
    }

    // ---------------------------------------------------------------- header
    Row {
        id: header
        spacing: 14
        Text { text: "ATLAS"; color: Theme.text; font.pixelSize: 22; font.letterSpacing: 3; anchors.verticalCenter: parent.verticalCenter }
        Text { text: "UK AIRSPACE"; color: Theme.muted; font.pixelSize: 13; font.letterSpacing: 3; anchors.verticalCenter: parent.verticalCenter }
    }
    Row {
        id: statusRow
        anchors.top: header.bottom; anchors.topMargin: 6
        spacing: 8
        Rectangle {
            width: 8; height: 8; radius: 4; anchors.verticalCenter: parent.verticalCenter
            color: atlas.live ? Theme.accent : Theme.attention
            SequentialAnimation on opacity {
                running: atlas.live && atlas.visible; loops: Animation.Infinite
                NumberAnimation { to: 0.25; duration: 900; easing.type: Easing.InOutSine }
                NumberAnimation { to: 1; duration: 900; easing.type: Easing.InOutSine }
            }
        }
        Text { text: atlas.statusLine(); color: atlas.live ? Theme.accent : Theme.attention
               font.family: "monospace"; font.pixelSize: 11; font.letterSpacing: 1.2; anchors.verticalCenter: parent.verticalCenter }
    }

    // ---------------------------------------------------------------- map
    Item {
        id: view
        anchors.top: statusRow.bottom; anchors.topMargin: 12
        anchors.left: parent.left; anchors.bottom: attribution.top; anchors.bottomMargin: 6
        width: parent.width - side.width - 16
        clip: true

        // Camera: centre + scale (pixels per degree of latitude). Longitude is
        // scaled by cos(55°) so the UK keeps its shape.
        readonly property real k: Math.cos(55 * Math.PI / 180)
        readonly property real fitScale: Math.min(width / ((3.0 + 11.5) * k), height / (61.2 - 49.3))
        property real cLat: 55.25
        property real cLon: -4.25
        property real zoom: 1
        readonly property real scale: fitScale * zoom
        Behavior on cLat { enabled: !dragArea.pressed; NumberAnimation { duration: 260; easing.type: Easing.OutCubic } }
        Behavior on cLon { enabled: !dragArea.pressed; NumberAnimation { duration: 260; easing.type: Easing.OutCubic } }
        Behavior on zoom { NumberAnimation { duration: 260; easing.type: Easing.OutCubic } }
        function px(lon) { return width / 2 + (lon - cLon) * k * scale }
        function py(lat) { return height / 2 + (cLat - lat) * scale }
        function lonAt(x) { return cLon + (x - width / 2) / (k * scale) }
        function latAt(y) { return cLat - (y - height / 2) / scale }
        function zoomAt(factor, x, y) {
            const nz = Math.max(1, Math.min(14, zoom * factor))
            const lon = lonAt(x), lat = latAt(y)
            // Keep the point under the cursor fixed while zooming.
            const s2 = fitScale * nz
            cLon = lon - (x - width / 2) / (k * s2)
            cLat = lat + (y - height / 2) / s2
            zoom = nz
        }
        function reset() { zoom = 1; cLat = 55.25; cLon = -4.25 }
        function centreOn(p) { cLat = p[4]; cLon = p[5]; if (zoom < 3) zoom = 3 }
        onScaleChanged: repaintAll()
        onCLatChanged: repaintAll()
        onCLonChanged: repaintAll()
        onWidthChanged: repaintAll()
        onHeightChanged: repaintAll()
        function repaintAll() { land.requestPaint(); trails.requestPaint(); aircraftLayer.requestPaint() }

        Chamfer { anchors.fill: parent; cut: 14; fill: Theme.bgBottom; fillOpacity: 0.55; stroke: Theme.line }

        // Land, coast glow, graticule and airports.
        Canvas {
            id: land
            anchors.fill: parent
            renderTarget: Canvas.FramebufferObject
            function rgba(c, a) { return "rgba(" + Math.round(c.r * 255) + "," + Math.round(c.g * 255) + "," + Math.round(c.b * 255) + "," + a + ")" }
            onPaint: {
                const ctx = getContext("2d"), w = width, h = height
                ctx.reset(); ctx.clearRect(0, 0, w, h)
                // Graticule every 2° (every 1° when zoomed in).
                const step = view.zoom >= 3 ? 1 : 2
                ctx.strokeStyle = rgba(Theme.line, 0.35); ctx.lineWidth = 1
                ctx.beginPath()
                for (let lat = 48; lat <= 62; lat += step) { ctx.moveTo(0, view.py(lat)); ctx.lineTo(w, view.py(lat)) }
                for (let lon = -14; lon <= 6; lon += step) { ctx.moveTo(view.px(lon), 0); ctx.lineTo(view.px(lon), h) }
                ctx.stroke()
                ctx.fillStyle = rgba(Theme.muted, 0.55); ctx.font = "9px monospace"
                for (let lat = 50; lat <= 60; lat += 2) ctx.fillText(lat + "°N", 6, view.py(lat) - 3)
                for (let lon = -10; lon <= 2; lon += 2) ctx.fillText(Math.abs(lon) + "°" + (lon < 0 ? "W" : "E"), view.px(lon) + 3, h - 6)
                // Land: soft fill for closed outlines (islands), then a glowing
                // coastline: a wide faint stroke under a crisp one. Coast pieces cut
                // by the data's edge are open lines and are never closed.
                const rings = atlas.map.rings || []
                ctx.beginPath()
                for (const ring of rings) {
                    const n = ring.length
                    if (n < 6 || Math.abs(ring[0] - ring[n - 2]) + Math.abs(ring[1] - ring[n - 1]) > 0.02) continue
                    ctx.moveTo(view.px(ring[0]), view.py(ring[1]))
                    for (let i = 2; i < n; i += 2) ctx.lineTo(view.px(ring[i]), view.py(ring[i + 1]))
                    ctx.closePath()
                }
                ctx.fillStyle = rgba(Theme.glow, 0.16); ctx.fill()
                ctx.beginPath()
                for (const ring of rings) {
                    ctx.moveTo(view.px(ring[0]), view.py(ring[1]))
                    for (let i = 2; i < ring.length; i += 2) ctx.lineTo(view.px(ring[i]), view.py(ring[i + 1]))
                }
                ctx.strokeStyle = rgba(Theme.accent, 0.10); ctx.lineWidth = 6; ctx.stroke()
                ctx.strokeStyle = rgba(Theme.accent, 0.20); ctx.lineWidth = 2.5; ctx.stroke()
                ctx.strokeStyle = rgba(Theme.text, 0.55); ctx.lineWidth = 1; ctx.stroke()
                // Airports: glow, ring sized by the traffic near each one right now.
                const busy = {}
                for (const b of (atlas.stats.busiest || [])) busy[b[0]] = b[2]
                ctx.font = "10px monospace"
                for (const ap of (atlas.map.airports || [])) {
                    const x = view.px(ap[3]), y = view.py(ap[2])
                    const g = ctx.createRadialGradient(x, y, 0, x, y, 16)
                    g.addColorStop(0, rgba(Theme.accent, 0.35)); g.addColorStop(1, rgba(Theme.accent, 0))
                    ctx.fillStyle = g; ctx.fillRect(x - 16, y - 16, 32, 32)
                    ctx.strokeStyle = rgba(Theme.text, 0.8); ctx.lineWidth = 1.2
                    ctx.beginPath(); ctx.arc(x, y, 3.2, 0, Math.PI * 2); ctx.stroke()
                    if (busy[ap[0]]) {
                        ctx.strokeStyle = rgba(Theme.accent, 0.45); ctx.lineWidth = 1
                        ctx.beginPath(); ctx.arc(x, y, 8 + Math.min(14, busy[ap[0]] * 1.5), 0, Math.PI * 2); ctx.stroke()
                    }
                    ctx.fillStyle = rgba(Theme.text, 0.75); ctx.fillText(ap[0], x + 7, y - 5)
                }
            }
        }

        // Trails: the real positions reported in earlier updates, fading with age.
        Canvas {
            id: trails
            anchors.fill: parent
            renderTarget: Canvas.FramebufferObject
            function rgba(c, a) { return "rgba(" + Math.round(c.r * 255) + "," + Math.round(c.g * 255) + "," + Math.round(c.b * 255) + "," + a + ")" }
            onPaint: {
                const ctx = getContext("2d")
                ctx.reset(); ctx.clearRect(0, 0, width, height)
                ctx.lineCap = "round"
                for (const p of atlas.shown) {
                    const t = p[14] || []
                    if (t.length < 2 || p[7]) continue
                    const chosen = p[0] === atlas.selectedHex
                    const col = atlas.colourOf(p), n = t.length / 2
                    ctx.lineWidth = chosen ? 2.2 : 1.2
                    let x0 = view.px(t[1]), y0 = view.py(t[0])
                    for (let i = 1; i <= n; ++i) {
                        const x1 = i < n ? view.px(t[2 * i + 1]) : view.px(p[5]), y1 = i < n ? view.py(t[2 * i]) : view.py(p[4])
                        ctx.strokeStyle = rgba(col, (chosen ? 0.9 : 0.45) * i / n)
                        ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke()
                        x0 = x1; y0 = y1
                    }
                }
            }
        }

        // Aircraft: silhouettes along their track, coloured by altitude band.
        Canvas {
            id: aircraftLayer
            anchors.fill: parent
            renderStrategy: Canvas.Cooperative
            readonly property var shape: [0,-1, .12,-.55, .95,.05, .95,.2, .12,.02, .1,.6, .38,.82, .38,.95, 0,.86,
                                          -.38,.95, -.38,.82, -.1,.6, -.12,.02, -.95,.2, -.95,.05, -.12,-.55]
            function rgba(c, a) { return "rgba(" + Math.round(c.r * 255) + "," + Math.round(c.g * 255) + "," + Math.round(c.b * 255) + "," + a + ")" }
            onPaint: {
                const ctx = getContext("2d"), w = width, h = height, g = atlas.glide
                ctx.reset(); ctx.clearRect(0, 0, w, h)
                const labels = view.zoom >= 3
                ctx.font = "10px monospace"
                for (const p of atlas.shown) {
                    const from = atlas.fromPos[p[0]]
                    const lat = from ? from[0] + (p[4] - from[0]) * g : p[4]
                    const lon = from ? from[1] + (p[5] - from[1]) * g : p[5]
                    const x = view.px(lon), y = view.py(lat)
                    if (x < -20 || y < -20 || x > w + 20 || y > h + 20) continue
                    const chosen = p[0] === atlas.selectedHex
                    const col = atlas.colourOf(p)
                    if (p[7]) {
                        ctx.fillStyle = rgba(col, chosen ? 1 : 0.6)
                        ctx.beginPath(); ctx.arc(x, y, chosen ? 3.5 : 1.8, 0, Math.PI * 2); ctx.fill()
                    } else {
                        const s = (chosen ? 9 : 6) * Math.min(1.6, 0.85 + view.zoom * 0.08)
                        ctx.save(); ctx.translate(x, y); ctx.rotate((p[9] === null ? 0 : p[9]) * Math.PI / 180)
                        ctx.beginPath(); ctx.moveTo(shape[0] * s, shape[1] * s)
                        for (let i = 2; i < shape.length; i += 2) ctx.lineTo(shape[i] * s, shape[i + 1] * s)
                        ctx.closePath()
                        ctx.fillStyle = rgba(col, chosen ? 1 : 0.9); ctx.fill()
                        ctx.restore()
                    }
                    if (chosen) {
                        ctx.strokeStyle = rgba(Theme.text, 0.9); ctx.lineWidth = 1.2
                        ctx.beginPath(); ctx.arc(x, y, 15, 0, Math.PI * 2); ctx.stroke()
                        ctx.strokeStyle = rgba(Theme.accent, 0.5)
                        ctx.beginPath(); ctx.arc(x, y, 21, -0.6, 0.6); ctx.stroke()
                        ctx.beginPath(); ctx.arc(x, y, 21, Math.PI - 0.6, Math.PI + 0.6); ctx.stroke()
                    }
                    if (labels || chosen) {
                        ctx.fillStyle = rgba(chosen ? Theme.text : col, chosen ? 1 : 0.8)
                        ctx.fillText(atlas.nameOf(p), x + 10, y - 6)
                        if (!p[7] && p[6] !== null && (chosen || view.zoom >= 5))
                            ctx.fillText(Math.round(p[6] / 100) + " " + atlas.trend(p), x + 10, y + 6)
                    }
                }
            }
        }

        // Pan (drag), zoom (wheel), select (click), reset (double-click).
        MouseArea {
            id: dragArea
            anchors.fill: parent
            property real lastX: 0
            property real lastY: 0
            property bool moved: false
            cursorShape: pressed && moved ? Qt.ClosedHandCursor : Qt.CrossCursor
            onPressed: mouse => { lastX = mouse.x; lastY = mouse.y; moved = false }
            onPositionChanged: mouse => {
                const dx = mouse.x - lastX, dy = mouse.y - lastY
                if (Math.abs(dx) + Math.abs(dy) > 2) moved = true
                if (!moved) return
                view.cLon -= dx / (view.k * view.scale); view.cLat += dy / view.scale
                lastX = mouse.x; lastY = mouse.y
            }
            onReleased: mouse => {
                if (moved) return
                let best = "", bestD = 16 * 16
                for (const p of atlas.shown) {
                    const dx = view.px(p[5]) - mouse.x, dy = view.py(p[4]) - mouse.y, d = dx * dx + dy * dy
                    if (d < bestD) { bestD = d; best = p[0] }
                }
                atlas.selectedHex = best
            }
            onDoubleClicked: view.reset()
            onWheel: wheel => view.zoomAt(wheel.angleDelta.y > 0 ? 1.35 : 1 / 1.35, wheel.x, wheel.y)
        }
        // Keyboard: +/- zoom, arrows pan, 0 resets.
        focus: true
        activeFocusOnTab: true
        Accessible.name: "Map. Plus and minus zoom, arrow keys move, zero resets."
        Keys.onPressed: event => {
            const step = 60
            if (event.key === Qt.Key_Plus || event.key === Qt.Key_Equal) view.zoomAt(1.35, view.width / 2, view.height / 2)
            else if (event.key === Qt.Key_Minus) view.zoomAt(1 / 1.35, view.width / 2, view.height / 2)
            else if (event.key === Qt.Key_0) view.reset()
            else if (event.key === Qt.Key_Left) view.cLon -= step / (view.k * view.scale)
            else if (event.key === Qt.Key_Right) view.cLon += step / (view.k * view.scale)
            else if (event.key === Qt.Key_Up) view.cLat += step / view.scale
            else if (event.key === Qt.Key_Down) view.cLat -= step / view.scale
            else return
            event.accepted = true
        }
        Rectangle { anchors.fill: parent; anchors.margins: 2; color: "transparent"; border.width: 1; radius: 2
                    border.color: Theme.accent; opacity: view.activeFocus ? 0.55 : 0
                    Behavior on opacity { NumberAnimation { duration: 150 } } }

        // Zoom buttons.
        Column {
            anchors.right: parent.right; anchors.top: parent.top; anchors.margins: 10; spacing: 6
            HudButton { width: 34; implicitHeight: 32; caption: "+"; Accessible.name: "Zoom in"; onClicked: view.zoomAt(1.35, view.width / 2, view.height / 2) }
            HudButton { width: 34; implicitHeight: 32; caption: "−"; Accessible.name: "Zoom out"; onClicked: view.zoomAt(1 / 1.35, view.width / 2, view.height / 2) }
            HudButton { width: 34; implicitHeight: 32; caption: "⌂"; Accessible.name: "Show all of the UK"; onClicked: view.reset() }
        }
        // Legend.
        Row {
            anchors.left: parent.left; anchors.bottom: parent.bottom; anchors.margins: 12; spacing: 12
            Repeater {
                model: ["Ground", "< 10k ft", "10–25k", "25–35k", "> 35k", "Emergency"]
                delegate: Row {
                    required property var modelData
                    required property int index
                    spacing: 5
                    Rectangle { width: 8; height: 8; radius: 4; anchors.verticalCenter: parent.verticalCenter
                                color: index === 5 ? Theme.attention : atlas.bandColours[index] }
                    Text { text: modelData; color: Theme.muted; font.family: "monospace"; font.pixelSize: 9; anchors.verticalCenter: parent.verticalCenter }
                }
            }
        }
        // Nothing to show: say why, on the map itself.
        Text {
            anchors.centerIn: parent
            visible: atlas.planes.length === 0
            text: atlas.info.status === "loading" ? "Waiting for the first update…" :
                  atlas.info.status === "unavailable" ? "No live aircraft to show.\n" + (atlas.info.error || "") : ""
            horizontalAlignment: Text.AlignHCenter
            color: Theme.attention; font.pixelSize: 13
        }
    }
    Text {
        id: attribution
        anchors.bottom: parent.bottom; anchors.left: parent.left
        width: view.width; elide: Text.ElideRight
        text: (atlas.info.attribution || "Flight data: public ADS-B sources") +
              "  ·  Coastline: Natural Earth (public domain)  ·  Trails are earlier reported positions  ·  Airport markers approximate"
        color: Theme.muted; font.pixelSize: 9
    }

    // ---------------------------------------------------------------- side panel
    Item {
        id: side
        anchors.top: parent.top; anchors.right: parent.right; anchors.bottom: parent.bottom
        width: Math.min(340, parent.width * 0.34)

        // Selected flight.
        Item {
            id: selCard
            width: parent.width; height: atlas.selected ? selCol.height + 28 : 64
            Behavior on height { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }
            clip: true
            Chamfer { anchors.fill: parent; cut: 12; fill: Theme.panel; fillOpacity: 0.9; stroke: atlas.selected ? atlas.colourOf(atlas.selected) : Theme.line }
            Text {
                visible: !atlas.selected; anchors.centerIn: parent
                text: "Click an aircraft on the map, or pick one below"; color: Theme.muted; font.pixelSize: 12
            }
            Column {
                id: selCol
                visible: !!atlas.selected
                x: 14; y: 14; width: parent.width - 28; spacing: 8
                Row {
                    width: parent.width; spacing: 8
                    Glyph { width: 20; height: 20; kind: "plane"; stroke: atlas.selected ? atlas.colourOf(atlas.selected) : Theme.accent }
                    Text { text: atlas.selected ? atlas.nameOf(atlas.selected) : ""; color: Theme.text; font.pixelSize: 22; font.weight: Font.DemiBold }
                    Text { anchors.verticalCenter: parent.verticalCenter; text: atlas.selected && atlas.selected[11] ? "EMERGENCY" : ""
                           color: Theme.attention; font.family: "monospace"; font.pixelSize: 11; font.bold: true }
                }
                Text {
                    width: parent.width; elide: Text.ElideRight; color: Theme.muted; font.pixelSize: 12
                    text: !atlas.selected ? "" : [atlas.selected[13] || atlas.selected[3], atlas.selected[2], "ICAO " + atlas.selected[0].toUpperCase()]
                                                  .filter(x => x).join("  ·  ")
                }
                Grid {
                    columns: 2; columnSpacing: 12; rowSpacing: 6; width: parent.width
                    component Fact: Column {
                        property string k: ""
                        property string v: ""
                        property color vc: Theme.text
                        width: (selCol.width - 12) / 2; spacing: 1
                        Text { text: parent.k; color: Theme.muted; font.family: "monospace"; font.pixelSize: 9; font.letterSpacing: 1.4 }
                        Text { text: parent.v; color: parent.vc; font.pixelSize: 15 }
                    }
                    Fact { k: "ALTITUDE"; v: atlas.selected ? atlas.heightOf(atlas.selected) + " " + atlas.trend(atlas.selected) : "" }
                    Fact { k: "VERTICAL"; v: !atlas.selected || atlas.selected[12] === null ? "—" : (atlas.selected[12] > 0 ? "+" : "") + atlas.selected[12] + " ft/min" }
                    Fact { k: "SPEED"; v: !atlas.selected || atlas.selected[8] === null ? "—" : atlas.selected[8] + " kt" }
                    Fact { k: "HEADING"; v: !atlas.selected || atlas.selected[9] === null ? "—" : ("00" + atlas.selected[9]).slice(-3) + "°" }
                    Fact { k: "NEAREST AIRPORT"
                           v: { const n = atlas.selected ? atlas.nearestAirport(atlas.selected) : null; return n ? n[0] + " · " + n[2] + " nm" : "—" } }
                    Fact { k: "POSITION AGE"; v: atlas.selected ? atlas.selected[10] + " s" : ""
                           vc: atlas.selected && atlas.selected[10] > 20 ? Theme.attention : Theme.text }
                }
                Row {
                    spacing: 8
                    HudButton { width: 150; glyph: "mission"; caption: "Focus this flight"; tone: "primary"
                                onClicked: atlas.focusFlight(atlas.selected[1], atlas.selected[0]) }
                    HudButton { width: 80; caption: "Centre"; onClicked: view.centreOn(atlas.selected) }
                    HudButton { width: 40; caption: "✕"; Accessible.name: "Deselect"; onClicked: atlas.selectedHex = "" }
                }
            }
        }

        // Airspace summary (all counts from the current update).
        Item {
            id: statsCard
            anchors.top: selCard.bottom; anchors.topMargin: 10
            width: parent.width; height: statsCol.height + 26
            Chamfer { anchors.fill: parent; cut: 12; fill: Theme.panel; fillOpacity: 0.8; stroke: Theme.line }
            Column {
                id: statsCol
                x: 14; y: 12; width: parent.width - 28; spacing: 6
                Text { text: "AIRSPACE NOW"; color: Theme.text; font.family: "monospace"; font.pixelSize: 10; font.letterSpacing: 2; font.bold: true }
                Repeater {
                    model: (atlas.stats.bands || []).length
                    delegate: Row {
                        required property int index
                        readonly property int count: atlas.stats.bands[index]
                        readonly property int most: Math.max(1, ...atlas.stats.bands)
                        spacing: 8
                        Text { width: 108; text: atlas.stats.bandNames[index]; color: Theme.muted; font.pixelSize: 10 }
                        Rectangle {
                            anchors.verticalCenter: parent.verticalCenter; height: 6; radius: 3
                            width: Math.max(2, (statsCol.width - 150) * count / most)
                            color: atlas.bandColours[index]
                            Behavior on width { NumberAnimation { duration: 500; easing.type: Easing.OutCubic } }
                        }
                        Text { text: count; color: Theme.text; font.family: "monospace"; font.pixelSize: 10 }
                    }
                }
                Text {
                    width: parent.width; wrapMode: Text.WordWrap; color: Theme.muted; font.pixelSize: 11; lineHeight: 1.25
                    text: (atlas.stats.climbing !== undefined ? "▲ " + atlas.stats.climbing + " climbing   ▼ " + atlas.stats.descending + " descending" : "") +
                          (atlas.stats.busiest && atlas.stats.busiest.length ? "\nBusiest: " + atlas.stats.busiest.map(b => b[0] + " " + b[2]).join(" · ") : "") +
                          (atlas.stats.highest ? "\nHighest: " + atlas.stats.highest[0] + " " + atlas.stats.highest[1].toLocaleString(Qt.locale("en_GB"), "f", 0) + " ft" : "") +
                          (atlas.stats.fastest ? "   Fastest: " + atlas.stats.fastest[0] + " " + atlas.stats.fastest[1] + " kt" : "") +
                          (atlas.stats.emergencies ? "\n" + atlas.stats.emergencies + " emergency squawk" : "")
                }
            }
        }

        // Filters + list.
        Row {
            id: filterRow
            anchors.top: statsCard.bottom; anchors.topMargin: 10
            width: parent.width; spacing: 6
            TextField {
                id: findField
                width: parent.width; height: 34
                placeholderText: "Find callsign, registration or type…"; verticalAlignment: TextInput.AlignVCenter
                color: Theme.text; placeholderTextColor: Theme.muted; selectByMouse: true; font.pixelSize: 12
                Accessible.name: "Find aircraft"
                background: Rectangle { radius: 6; color: Theme.raised; border.width: findField.activeFocus ? 2 : 1
                                        border.color: findField.activeFocus ? Theme.accent : Theme.line }
                onTextChanged: atlas.filterText = text.trim()
            }
        }
        Row {
            id: kindRow
            anchors.top: filterRow.bottom; anchors.topMargin: 6
            spacing: 5
            Repeater {
                model: [["all", "All"], ["air", "Airborne"], ["ground", "Ground"], ["emergency", "Emergency"]]
                delegate: HudButton {
                    required property var modelData
                    width: (side.width - 15) / 4; implicitHeight: 30
                    caption: modelData[1]
                    tone: atlas.filterKind === modelData[0] ? "selected" : "normal"
                    onClicked: atlas.filterKind = modelData[0]
                }
            }
        }
        Text {
            id: listHead
            anchors.top: kindRow.bottom; anchors.topMargin: 8
            text: "ON THE MAP  (" + atlas.shown.length + (atlas.shown.length !== atlas.planes.length ? " of " + atlas.planes.length : "") + ")"
            color: Theme.muted; font.family: "monospace"; font.pixelSize: 10; font.letterSpacing: 2
        }
        ListView {
            id: list
            anchors.top: listHead.bottom; anchors.topMargin: 4; anchors.bottom: parent.bottom
            width: parent.width; clip: true
            model: atlas.shown
            ScrollBar.vertical: HudScrollBar {}
            activeFocusOnTab: true
            keyNavigationEnabled: true
            currentIndex: -1
            Accessible.name: "Aircraft on the map"
            Keys.onReturnPressed: if (currentIndex >= 0) atlas.selectedHex = atlas.shown[currentIndex][0]
            Keys.onSpacePressed: if (currentIndex >= 0) atlas.selectedHex = atlas.shown[currentIndex][0]
            onActiveFocusChanged: if (activeFocus && currentIndex < 0 && count > 0) currentIndex = 0
            Connections {
                target: atlas
                // The list is rebuilt every update; keep the keyboard position on the same aircraft.
                function onShownChanged() {
                    for (let i = 0; i < atlas.shown.length; ++i)
                        if (atlas.shown[i][0] === atlas.selectedHex) { list.currentIndex = i; return }
                }
            }
            delegate: ItemDelegate {
                id: row
                required property var modelData
                required property int index
                focusPolicy: Qt.NoFocus
                width: ListView.view.width - 10; height: 26
                Accessible.name: atlas.nameOf(modelData) + ", " + atlas.heightOf(modelData)
                contentItem: Row {
                    spacing: 8
                    Rectangle { width: 6; height: 6; radius: 3; color: atlas.colourOf(row.modelData); anchors.verticalCenter: parent.verticalCenter }
                    Text { width: 86; text: atlas.nameOf(row.modelData); elide: Text.ElideRight; anchors.verticalCenter: parent.verticalCenter
                           color: row.modelData[0] === atlas.selectedHex ? Theme.text : (row.modelData[11] ? Theme.attention : Theme.text)
                           font.family: "monospace"; font.pixelSize: 11 }
                    Text { width: 44; text: row.modelData[3]; color: Theme.muted; font.family: "monospace"; font.pixelSize: 10; anchors.verticalCenter: parent.verticalCenter }
                    Text { text: atlas.heightOf(row.modelData) + " " + atlas.trend(row.modelData); color: Theme.muted; font.pixelSize: 11
                           anchors.verticalCenter: parent.verticalCenter }
                }
                background: Rectangle {
                    radius: 3
                    color: row.modelData[0] === atlas.selectedHex ? Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.14) :
                           row.hovered || (list.activeFocus && list.currentIndex === row.index) ? Theme.hover : "transparent"
                    border.width: list.activeFocus && list.currentIndex === row.index ? 1 : 0; border.color: Theme.text
                    Behavior on color { ColorAnimation { duration: 120 } }
                }
                onClicked: { list.currentIndex = index; atlas.selectedHex = modelData[0] }
            }
        }
    }
}
