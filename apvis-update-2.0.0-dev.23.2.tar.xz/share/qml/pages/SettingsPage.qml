import QtQuick
import QtQuick.Controls
import "../theme"
import "../controls"

// Settings: every value shown is read from the system, and every change is
// read back (see apvis_os.control). Cards fade in, staggered, when it opens.
Item {
    id: page
    readonly property var s: shell.settings || ({})
    readonly property var ctl: (shell.control || {}).state || ({})
    readonly property var remote: ctl.remote || ({})
    readonly property var powerCfg: ctl.power || ({})
    readonly property var u: shell.updates || ({})
    readonly property bool wide: width >= 900
    function focusFirst() { ollamaField.forceActiveFocus() }
    onVisibleChanged: if (visible) { shell.refreshControl(); shell.refreshModels(); entry.restart() }
    Component.onCompleted: if (visible) { shell.refreshControl(); shell.refreshModels() }
    Timer { interval: 5000; repeat: true; running: page.visible; onTriggered: shell.refreshControl() }

    property real reveal: 1
    NumberAnimation { id: entry; target: page; property: "reveal"; from: 0; to: 1; duration: 700; easing.type: Easing.OutCubic }

    component Section: Item {
        id: sec
        property string title: ""
        property string glyph: ""
        property int order: 0
        default property alias content: body.data
        width: page.wide ? (grid.width - grid.columnSpacing) / 2 : grid.width
        height: body.height + 58
        // Staggered entry: each card starts a little later and rises into place.
        readonly property real local: Math.max(0, Math.min(1, page.reveal * 1.6 - order * 0.12))
        opacity: local
        transform: Translate { y: (1 - sec.local) * 18 }
        Chamfer { anchors.fill: parent; cut: 12; fill: Theme.panel; fillOpacity: 0.82; stroke: Theme.line }
        Rectangle { x: 14; y: 44; width: parent.width - 28; height: 1; color: Theme.line; opacity: 0.6 }
        Row {
            x: 16; y: 14; spacing: 10
            Glyph { width: 16; height: 16; kind: sec.glyph; stroke: Theme.accent; anchors.verticalCenter: parent.verticalCenter }
            Text { text: sec.title; color: Theme.text; font.family: "monospace"; font.pixelSize: 11; font.letterSpacing: 2; font.bold: true
                   anchors.verticalCenter: parent.verticalCenter }
        }
        Column { id: body; x: 16; y: 56; width: parent.width - 32; spacing: 10 }
    }
    component Note: Text {
        width: parent ? parent.width : 200; wrapMode: Text.WordWrap; color: Theme.muted; font.pixelSize: 12
    }
    component Chips: Row {
        id: chips
        property var choices: []
        property int value: 0
        signal picked(int minutes)
        spacing: 6
        Repeater {
            model: chips.choices
            delegate: HudButton {
                required property var modelData
                width: 62; implicitHeight: 32
                caption: modelData === 0 ? "Never" : modelData + " min"
                tone: modelData === chips.value ? "selected" : "normal"
                onClicked: chips.picked(modelData)
            }
        }
    }

    Text { id: title; text: "SETTINGS"; color: Theme.text; font.pixelSize: 24; font.letterSpacing: 3; opacity: page.reveal }
    Text { anchors.top: title.bottom; anchors.topMargin: 4; text: "Everything here shows the real system state and checks each change."
           color: Theme.muted; font.pixelSize: 12; opacity: page.reveal }

    Flickable {
        anchors.fill: parent; anchors.topMargin: 64
        contentHeight: grid.height + 20
        clip: true
        boundsBehavior: Flickable.StopAtBounds
        ScrollBar.vertical: HudScrollBar {}
        Flow {
            id: grid
            width: parent.width - 14
            spacing: 14
            readonly property real columnSpacing: 14

            Section {
                title: "POWER"; glyph: "power"; order: 0
                PowerButtons { buttonWidth: Math.min(118, (parent.width - 18) / 4) }
                Text { text: "SCREEN OFF AFTER"; color: Theme.muted; font.family: "monospace"; font.pixelSize: 10; font.letterSpacing: 1.5; topPadding: 4 }
                Chips { choices: page.powerCfg.screenChoices || [0, 2, 5, 10, 15, 30]; value: page.powerCfg.screenOff === undefined ? 10 : page.powerCfg.screenOff
                        onPicked: minutes => shell.setPowerTimers(minutes, page.powerCfg.sleep || 0) }
                Text { text: "SLEEP AFTER"; color: Theme.muted; font.family: "monospace"; font.pixelSize: 10; font.letterSpacing: 1.5; topPadding: 4 }
                Chips { choices: page.powerCfg.sleepChoices || [0, 15, 30, 60, 120]; value: page.powerCfg.sleep || 0
                        onPicked: minutes => shell.setPowerTimers(page.powerCfg.screenOff === undefined ? 10 : page.powerCfg.screenOff, minutes) }
                Note { text: (shell.control || {}).message || "Restart, shut down and sleep ask for a second press." }
            }

            Section {
                title: "ASK  ·  LOCAL AI"; glyph: "brain"; order: 1
                Note { text: "Where Ask finds Ollama: this computer (http://127.0.0.1:11434) or another computer on your home network, " +
                             "e.g. your OptiPlex. Internet addresses are refused, so Ask stays local." }
                Row {
                    width: parent.width; spacing: 8
                    TextField {
                        id: ollamaField
                        width: parent.width - 196; height: 40
                        // Not bound: a settings update must never overwrite what the owner typed.
                        Component.onCompleted: text = page.s.ollamaUrl || ""
                        Connections {
                            target: shell
                            function onSettingsChanged() {
                                if ((page.s.saved || "").startsWith("Saved")) ollamaField.text = page.s.ollamaUrl
                            }
                        }
                        color: Theme.text; selectByMouse: true; font.pixelSize: 13; verticalAlignment: TextInput.AlignVCenter
                        Accessible.name: "Ollama address"
                        background: Rectangle { radius: 6; color: Theme.raised; border.width: ollamaField.activeFocus ? 2 : 1
                                                border.color: ollamaField.activeFocus ? Theme.accent : Theme.line
                                                Behavior on border.color { ColorAnimation { duration: 150 } } }
                        onAccepted: shell.testOllama(text)
                    }
                    HudButton { width: 90; caption: "Test"; onClicked: shell.testOllama(ollamaField.text) }
                    HudButton { width: 90; caption: "Save"; tone: "primary"; onClicked: shell.saveOllama(ollamaField.text) }
                }
                Text { text: "MODELS"; color: Theme.muted; font.family: "monospace"; font.pixelSize: 10; font.letterSpacing: 1.5; topPadding: 4 }
                HudButton {
                    visible: page.s.ollamaUp === false
                    width: 230; glyph: "brain"; tone: "primary"; caption: "Set up local AI…"
                    onClicked: shell.setupLocalAI()
                }
                Note { visible: page.s.ollamaUp === false
                       text: "Ollama isn't running here. This installs it and the two recommended models in a terminal window (you type your password there)." }
                Repeater {
                    model: shell.recommendedModels || []
                    delegate: Row {
                        required property var modelData
                        readonly property bool have: (page.s.installedModels || []).indexOf(modelData.name) >= 0
                        spacing: 10
                        Rectangle { width: 8; height: 8; radius: 4; anchors.verticalCenter: parent.verticalCenter
                                    color: parent.have ? Theme.accent : Theme.muted }
                        Column {
                            width: 250; anchors.verticalCenter: parent.verticalCenter
                            Text { text: modelData.name + "  ·  " + modelData.size; color: Theme.text; font.family: "monospace"; font.pixelSize: 11 }
                            Text { text: modelData.role; color: Theme.muted; font.pixelSize: 10 }
                        }
                        HudButton {
                            anchors.verticalCenter: parent.verticalCenter
                            visible: page.s.ollamaUp === true && !parent.have
                            enabled: !page.s.pulling
                            width: 120; implicitHeight: 30
                            caption: page.s.pulling === modelData.name ? (page.s.pullPct || 0) + "%" : "Download"
                            onClicked: shell.pullModel(modelData.name)
                        }
                        Text { visible: parent.have; text: "Installed"; color: Theme.accent; font.pixelSize: 11; anchors.verticalCenter: parent.verticalCenter }
                    }
                }
                Note { visible: !!page.s.pullMessage; text: page.s.pullMessage || "" }
                Note {
                    visible: text.length > 0
                    text: page.s.saved || page.s.test || ""
                    color: (page.s.saved || "").startsWith("Saved") || page.s.testOk ? Theme.accent :
                           (page.s.test === "Testing…" ? Theme.muted : Theme.attention)
                }
            }

            Section {
                title: "REMOTE ACCESS  ·  SSH"; glyph: "key"; order: 2
                Row {
                    spacing: 10
                    Rectangle { width: 9; height: 9; radius: 4.5; anchors.verticalCenter: parent.verticalCenter
                                color: page.remote.on ? Theme.accent : Theme.muted }
                    Text { anchors.verticalCenter: parent.verticalCenter; color: Theme.text; font.pixelSize: 13
                           text: !page.remote.available ? (page.remote.detail || "Checking…") :
                                 (page.remote.on ? "On" : "Off") + "  ·  " + (page.remote.keys || 0) + (page.remote.keys === 1 ? " key" : " keys") + " authorised" }
                }
                Note {
                    visible: !!page.remote.on && (page.remote.addresses || []).length > 0
                    color: Theme.text; font.family: "monospace"
                    text: "ssh apvis@" + (page.remote.addresses || []).join("   ssh apvis@")
                }
                HudButton {
                    visible: !!page.remote.available
                    width: 200; glyph: "key"
                    caption: page.remote.on ? "Turn remote access off" : "Turn remote access on"
                    tone: page.remote.on ? "selected" : "normal"
                    onClicked: shell.setRemoteAccess(!page.remote.on)
                }
                Note { text: "Keys only (passwords never work) and home-network addresses only. To let a computer in, add its public key " +
                             "to ~/.ssh/authorized_keys. It stays on after a restart until you turn it off." }
            }

            Section {
                title: "UPDATES"; glyph: "restart"; order: 3
                Row {
                    spacing: 10
                    Text { anchors.verticalCenter: parent.verticalCenter; color: Theme.text; font.pixelSize: 14
                           text: "Installed: " + (page.u.installed || "?") }
                    Text { anchors.verticalCenter: parent.verticalCenter; visible: !!page.u.fromUpdate
                           text: "(update on top of " + page.u.base + ")"; color: Theme.muted; font.pixelSize: 11 }
                }
                Row {
                    spacing: 8
                    HudButton {
                        id: checkButton
                        width: 170; glyph: "search"; caption: "Check for updates"
                        enabled: ["checking", "installing"].indexOf(page.u.state) < 0
                        onClicked: shell.checkUpdates()
                    }
                    HudButton {
                        id: installButton
                        property bool armed: false
                        visible: page.u.state === "available"
                        width: 190; glyph: "check"
                        tone: armed ? "warning" : "primary"
                        caption: armed ? "Press again to install" : "Install " + (page.u.latest || "")
                        Timer { id: installDisarm; interval: 4000; onTriggered: installButton.armed = false }
                        onClicked: { if (armed) { armed = false; shell.installUpdate() } else { armed = true; installDisarm.restart() } }
                    }
                    HudButton {
                        visible: !!page.u.fromUpdate && ["checking", "installing"].indexOf(page.u.state) < 0
                        width: 110; glyph: "restart"; caption: "Roll back"
                        onClicked: shell.rollbackUpdate()
                    }
                }
                Note {
                    visible: text.length > 0
                    text: page.u.message || ""
                    color: ["error"].indexOf(page.u.state) >= 0 ? Theme.attention :
                           ["available", "installed", "current", "rolledback"].indexOf(page.u.state) >= 0 ? Theme.accent : Theme.muted
                }
                Note { visible: !!page.u.notes; text: "What's new: " + (page.u.notes || "") }
                Repeater {
                    model: (page.u.history || []).slice(0, 3)
                    delegate: Text { required property var modelData
                                     text: modelData.at + "  " + modelData.event + " " + modelData.version + (modelData.detail ? " · " + modelData.detail : "")
                                     color: Theme.muted; font.family: "monospace"; font.pixelSize: 10 }
                }
                Note { text: "Updates change only APVIS itself (screens and features), are checked against APVIS's signature before " +
                             "anything is replaced, and roll back automatically if Home fails to start." }
            }

            Section {
                title: "NOTIFICATIONS"; glyph: "activity"; order: 3
                Row {
                    width: parent.width; spacing: 12
                    HudButton {
                        width: 200
                        caption: "Do not disturb: " + (page.s.dnd ? "On" : "Off")
                        tone: page.s.dnd ? "selected" : "normal"
                        onClicked: shell.setDoNotDisturb(!page.s.dnd)
                    }
                    Note { anchors.verticalCenter: parent.verticalCenter; width: parent.width - 212
                           text: page.s.dndNote || "Approvals always get through." }
                }
            }

            Section {
                title: "ACCESSIBILITY"; glyph: "check"; order: 4
                Row {
                    width: parent.width; spacing: 12
                    HudButton {
                        width: 200
                        caption: "Reduce motion: " + ((shell.render || {}).reducedMotion ? "On" : "Off")
                        tone: (shell.render || {}).reducedMotion ? "selected" : "normal"
                        onClicked: shell.setReducedMotion(!(shell.render || {}).reducedMotion)
                    }
                    Note { anchors.verticalCenter: parent.verticalCenter; width: parent.width - 212
                           text: "Stills the Nucleus, smoke and drifting effects. Everything still updates." }
                }
            }

            Section {
                title: "SYSTEM"; glyph: "device"; order: 4
                Row {
                    width: parent.width; spacing: 8
                    HudButton { width: (parent.width - 16) / 3; glyph: "wifi"; caption: "Network"; onClicked: shell.launch("network") }
                    HudButton { width: (parent.width - 16) / 3; glyph: "screen"; caption: "Displays"; onClicked: shell.launch("displays") }
                    HudButton { width: (parent.width - 16) / 3; glyph: "volume"; caption: "Sound"; onClicked: shell.launch("sound") }
                }
            }

            Section {
                title: "ABOUT"; glyph: "apvis"; order: 5
                HudButton {
                    visible: !!(shell.installer || {}).live
                    width: 220; glyph: "device"; tone: "primary"
                    caption: "Install APVIS OS…"
                    onClicked: shell.pageRequested("install")
                }
                HudButton {
                    width: 220; glyph: "activity"
                    caption: "Developer mode: " + (shell.developerMode ? "On" : "Off")
                    tone: shell.developerMode ? "selected" : "normal"
                    onClicked: shell.setDeveloperMode(!shell.developerMode)
                }
                Text {
                    width: parent.width; wrapMode: Text.WordWrap; color: Theme.text; font.pixelSize: 12; lineHeight: 1.4
                    text: (page.s.version || "") +
                          "\nGraphics: " + ((shell.render || {}).software ? "CPU (software renderer)" :
                                            (shell.render || {}).renderer === "canvas" ? "GPU · 2D Nucleus" : "GPU · 3D Nucleus") +
                          " · quality " + ((shell.render || {}).tier || "") + "   ·   Accent: " + ((shell.render || {}).accent || "") +
                          ((shell.frameInfo || {}).fps !== undefined ? "\nFrame rate: " + shell.frameInfo.fps + " fps (slowest 5%: " + shell.frameInfo.p95 + " ms)" : "")
                }
            }
        }
    }
}
