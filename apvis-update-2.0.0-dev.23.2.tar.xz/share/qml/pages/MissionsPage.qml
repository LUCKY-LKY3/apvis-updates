import QtQuick
import QtQuick.Controls
import "../theme"

// Mission Control: everything APVIS was asked to do, as a timeline. Changes
// wait for approval; every result is checked afterwards; every run is logged.
Item {
    id: page
    readonly property var missions: shell.missions || []
    function statusText(status) {
        return status === "approval_required" ? "Waiting for you" : status === "completed" ? "Done" :
               status === "failed" ? "Did not complete" : status === "cancelled" ? "Cancelled" :
               status === "running" ? "Running" : status
    }
    function statusColour(status) {
        return status === "approval_required" || status === "failed" ? Theme.attention :
               status === "completed" ? Theme.accent : Theme.muted
    }
    function statusGlyph(status) { return status === "completed" ? "check" : status === "approval_required" ? "mission" : "activity" }
    function count(status) { return missions.filter(m => m.status === status).length }

    property real reveal: 1
    onVisibleChanged: if (visible) entry.restart()
    NumberAnimation { id: entry; target: page; property: "reveal"; from: 0; to: 1; duration: 650; easing.type: Easing.OutCubic }

    Text { id: title; text: "MISSION CONTROL"; color: Theme.text; font.pixelSize: 24; font.letterSpacing: 3; opacity: page.reveal }
    Text {
        id: sub
        anchors.top: title.bottom; anchors.topMargin: 4
        width: parent.width - clearButton.width - 20; wrapMode: Text.WordWrap; opacity: page.reveal
        text: "Everything APVIS was asked to do. Changes wait for your approval, every result is checked afterwards, and every run is logged."
        color: Theme.muted; font.pixelSize: 12
    }
    HudButton {
        id: clearButton
        anchors.right: parent.right; anchors.top: parent.top
        width: 150; caption: "Clear finished"; glyph: "check"
        visible: page.missions.some(m => m.status !== "approval_required" && m.status !== "running")
        onClicked: shell.archiveMissions()
    }

    // Counts.
    Row {
        id: counts
        anchors.top: sub.bottom; anchors.topMargin: 14
        spacing: 10
        opacity: page.reveal
        Repeater {
            model: [["approval_required", "WAITING"], ["completed", "DONE"], ["failed", "DID NOT COMPLETE"], ["cancelled", "CANCELLED"]]
            delegate: Item {
                required property var modelData
                readonly property int n: page.count(modelData[0])
                width: 150; height: 52
                Chamfer { anchors.fill: parent; cut: 8; fill: Theme.panel; fillOpacity: 0.8
                          stroke: n > 0 && modelData[0] === "approval_required" ? Theme.attention : Theme.line }
                Column {
                    x: 12; anchors.verticalCenter: parent.verticalCenter; spacing: 1
                    Text { text: n; color: n > 0 ? page.statusColour(modelData[0]) : Theme.muted; font.pixelSize: 20; font.weight: Font.DemiBold }
                    Text { text: modelData[1]; color: Theme.muted; font.family: "monospace"; font.pixelSize: 9; font.letterSpacing: 1.4 }
                }
            }
        }
    }

    Text {
        visible: page.missions.length === 0
        anchors.top: counts.bottom; anchors.topMargin: 30
        text: "No missions yet. Ask APVIS to do something in the box below, like “open my Downloads” or “set the volume to 40%”."
        color: Theme.muted; font.pixelSize: 13
    }

    ListView {
        id: list
        anchors.top: counts.bottom; anchors.topMargin: 16
        anchors.bottom: parent.bottom
        width: parent.width
        clip: true; spacing: 10
        model: page.missions
        ScrollBar.vertical: HudScrollBar {}
        add: Transition { NumberAnimation { properties: "opacity"; from: 0; to: 1; duration: 260 } }
        remove: Transition { NumberAnimation { properties: "opacity"; to: 0; duration: 200 } }
        displaced: Transition { NumberAnimation { properties: "y"; duration: 240; easing.type: Easing.OutCubic } }
        delegate: Item {
            id: card
            required property var modelData
            required property int index
            readonly property bool waiting: modelData.status === "approval_required"
            width: ListView.view.width - 12; height: body.height + 28
            opacity: Math.max(0, Math.min(1, page.reveal * 2 - index * 0.1))
            // Timeline: a node per mission, joined by a line.
            Rectangle { x: 14; y: 0; width: 1; height: parent.height + 10; color: Theme.line; visible: card.index < list.count - 1 }
            Rectangle {
                x: 5; y: 16; width: 19; height: 19; radius: 9.5
                color: Theme.bgBottom; border.width: 1.5; border.color: page.statusColour(card.modelData.status)
                Glyph { anchors.centerIn: parent; width: 11; height: 11; kind: page.statusGlyph(card.modelData.status); stroke: page.statusColour(card.modelData.status) }
                SequentialAnimation on scale {
                    running: card.waiting && page.visible; loops: Animation.Infinite
                    NumberAnimation { to: 1.18; duration: 700; easing.type: Easing.InOutSine }
                    NumberAnimation { to: 1.0; duration: 700; easing.type: Easing.InOutSine }
                }
            }
            Item {
                x: 36; width: parent.width - 36; height: parent.height
                Chamfer { anchors.fill: parent; cut: 10; fill: Theme.panel; fillOpacity: 0.85
                          stroke: card.waiting ? Theme.attention : Theme.line }
                Column {
                    id: body
                    x: 16; y: 14; width: parent.width - 32 - (actions.visible ? actions.width + 12 : 0); spacing: 4
                    Text { text: page.statusText(card.modelData.status).toUpperCase() + (card.modelData.verified ? "  ·  CHECKED" : "")
                           color: page.statusColour(card.modelData.status); font.family: "monospace"; font.pixelSize: 10; font.letterSpacing: 2 }
                    Text { width: parent.width; text: card.modelData.preview; color: Theme.text; font.pixelSize: 15; wrapMode: Text.WordWrap }
                    Text { width: parent.width; visible: text.length > 0; text: card.modelData.message || card.modelData.error || ""
                           color: card.modelData.status === "failed" ? Theme.attention : Theme.muted; font.pixelSize: 12; wrapMode: Text.WordWrap }
                    Text { width: parent.width; text: "You asked: “" + card.modelData.asked + "”  ·  " + card.modelData.updatedAt.replace("T", " ").replace("Z", " UTC")
                           color: Theme.muted; font.pixelSize: 10; elide: Text.ElideRight }
                }
                Row {
                    id: actions
                    visible: card.waiting
                    anchors.right: parent.right; anchors.rightMargin: 14; anchors.verticalCenter: parent.verticalCenter
                    spacing: 8
                    HudButton { width: 100; caption: "Approve"; tone: "primary"; onClicked: shell.approveMission(card.modelData.id, card.modelData.token) }
                    HudButton { width: 88; caption: "Cancel"; onClicked: shell.cancelMission(card.modelData.id) }
                }
            }
        }
    }
}
