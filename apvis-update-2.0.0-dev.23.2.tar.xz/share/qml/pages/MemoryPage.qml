import QtQuick
import QtQuick.Controls
import "../theme"

// Memory: what APVIS remembers about the owner, and what waits for review.
// Nothing is kept without a Save; every memory is a plain Markdown file in the
// vault, can be opened in an editor, and "Forget" moves it to the Trash.
Item {
    id: page
    readonly property var inbox: shell.inbox || []
    readonly property var memories: shell.notes || []
    property string kindFilter: ""
    property string textFilter: ""
    readonly property var shown: memories.filter(m =>
        (!kindFilter || m.kind === kindFilter) &&
        (!textFilter || (m.title + " " + (m.excerpt || "") + " " + (m.tags || []).join(" ")).toLowerCase().indexOf(textFilter.toLowerCase()) >= 0))
    readonly property bool wide: width >= 980
    property string armedForget: ""
    Timer { id: disarm; interval: 4000; onTriggered: page.armedForget = "" }
    function focusFirst() { filterField.forceActiveFocus() }
    function kindWord(k) { return k === "decision" ? "DECISION" : k === "research" ? "RESEARCH" : "NOTE" }
    function kindColour(k) { return k === "decision" ? Theme.warm : k === "research" ? "#7fb6ff" : Theme.accent }

    property real reveal: 1
    onVisibleChanged: if (visible) entry.restart()
    NumberAnimation { id: entry; target: page; property: "reveal"; from: 0; to: 1; duration: 650; easing.type: Easing.OutCubic }

    Text { id: title; text: "MEMORY"; color: Theme.text; font.pixelSize: 24; font.letterSpacing: 3; opacity: page.reveal }
    Text {
        id: sub
        anchors.top: title.bottom; anchors.topMargin: 4
        width: parent.width - openVault.width - 20; wrapMode: Text.WordWrap; opacity: page.reveal
        text: "What APVIS remembers about you. It only keeps what you Save. Say “remember that …” or “we decided … because …”. " +
              "Each memory is a plain Markdown file in " + shell.vaultPath + "."
        color: Theme.muted; font.pixelSize: 12
    }
    HudButton { id: openVault; anchors.right: parent.right; anchors.top: parent.top; width: 170; glyph: "files"; caption: "Open vault folder"
                onClicked: shell.openVault() }

    // ---- review column
    Item {
        id: reviewCol
        anchors.top: sub.bottom; anchors.topMargin: 18; anchors.bottom: parent.bottom
        width: page.wide ? parent.width * 0.38 : parent.width
        visible: page.wide || page.inbox.length > 0
        height: page.wide ? undefined : Math.min(260, reviewList.contentHeight + 40)
        opacity: page.reveal
        transform: Translate { x: (1 - page.reveal) * -20 }
        Row {
            id: reviewHead; spacing: 8
            Glyph { width: 14; height: 14; kind: "check"; stroke: page.inbox.length ? Theme.attention : Theme.muted; anchors.verticalCenter: parent.verticalCenter }
            Text { text: "WAITING FOR YOUR REVIEW  (" + page.inbox.length + ")"; color: page.inbox.length ? Theme.attention : Theme.muted
                   font.family: "monospace"; font.pixelSize: 10; font.letterSpacing: 2; anchors.verticalCenter: parent.verticalCenter }
        }
        Text { anchors.top: reviewHead.bottom; anchors.topMargin: 10; visible: page.inbox.length === 0
               text: "Nothing waiting. When you ask APVIS to remember something, it appears here first."; wrapMode: Text.WordWrap
               width: parent.width - 10; color: Theme.muted; font.pixelSize: 12 }
        ListView {
            id: reviewList
            anchors.top: reviewHead.bottom; anchors.topMargin: 10; anchors.bottom: parent.bottom
            width: parent.width - (page.wide ? 14 : 0); spacing: 8; clip: true
            model: page.inbox
            add: Transition { NumberAnimation { properties: "opacity"; from: 0; to: 1; duration: 220 } }
            remove: Transition { NumberAnimation { properties: "opacity"; to: 0; duration: 180 } }
            displaced: Transition { NumberAnimation { properties: "y"; duration: 200; easing.type: Easing.OutCubic } }
            delegate: Item {
                required property var modelData
                width: ListView.view.width; height: reviewBody.height + 64
                Chamfer { anchors.fill: parent; cut: 10; fill: Theme.panel; fillOpacity: 0.9; stroke: Theme.attention }
                Column {
                    id: reviewBody
                    x: 14; y: 12; width: parent.width - 28; spacing: 4
                    Text { text: page.kindWord(modelData.kind); color: Theme.attention; font.family: "monospace"; font.pixelSize: 10; font.letterSpacing: 2 }
                    Text { width: parent.width; text: modelData.text; color: Theme.text; font.pixelSize: 14; wrapMode: Text.WordWrap }
                    Text { width: parent.width; visible: text.length > 0; color: Theme.muted; font.pixelSize: 11; wrapMode: Text.WordWrap
                           text: (modelData.reason ? "Why: " + modelData.reason + "   " : "") +
                                 (modelData.similar.length ? "Similar to: " + modelData.similar.join(", ") : "") }
                }
                Row {
                    anchors.bottom: parent.bottom; anchors.bottomMargin: 10; x: 14; spacing: 8
                    HudButton { width: 90; caption: "Save"; tone: "primary"; onClicked: shell.acceptMemory(modelData.id) }
                    HudButton { width: 110; caption: "Don't save"; onClicked: shell.rejectMemory(modelData.id) }
                }
            }
        }
    }

    // ---- remembered
    Item {
        anchors.top: page.wide ? sub.bottom : reviewCol.bottom
        anchors.topMargin: 18; anchors.bottom: parent.bottom
        x: page.wide ? reviewCol.width + 10 : 0
        width: parent.width - x
        opacity: page.reveal
        transform: Translate { x: (1 - page.reveal) * 20 }
        Row {
            id: filters
            width: parent.width; spacing: 8
            TextField {
                id: filterField
                width: Math.max(160, parent.width - kinds.width - 8); height: 36
                placeholderText: "Find in memory…"; verticalAlignment: TextInput.AlignVCenter
                color: Theme.text; placeholderTextColor: Theme.muted; selectByMouse: true; font.pixelSize: 13
                Accessible.name: "Find in memory"
                background: Rectangle { radius: 6; color: Theme.raised; border.width: filterField.activeFocus ? 2 : 1
                                        border.color: filterField.activeFocus ? Theme.accent : Theme.line }
                onTextChanged: page.textFilter = text.trim()
            }
            Row {
                id: kinds; spacing: 6
                Repeater {
                    model: [["", "All"], ["note", "Notes"], ["decision", "Decisions"], ["research", "Research"]]
                    delegate: HudButton {
                        required property var modelData
                        implicitHeight: 36; width: 84
                        caption: modelData[1]
                        tone: page.kindFilter === modelData[0] ? "selected" : "normal"
                        onClicked: page.kindFilter = modelData[0]
                    }
                }
            }
        }
        Text {
            id: countLine
            anchors.top: filters.bottom; anchors.topMargin: 12
            text: "REMEMBERED  (" + page.shown.length + (page.shown.length !== page.memories.length ? " of " + page.memories.length : "") + ")"
            color: Theme.muted; font.family: "monospace"; font.pixelSize: 10; font.letterSpacing: 2
        }
        Text {
            anchors.top: countLine.bottom; anchors.topMargin: 10; visible: page.shown.length === 0
            width: parent.width; wrapMode: Text.WordWrap; color: Theme.muted; font.pixelSize: 12
            text: page.memories.length === 0 ? "APVIS doesn't remember anything yet." : "Nothing matches."
        }
        GridView {
            id: memGrid
            anchors.top: countLine.bottom; anchors.topMargin: 10; anchors.bottom: parent.bottom
            width: parent.width; clip: true
            readonly property int columns: width > 760 ? 2 : 1
            cellWidth: width / columns; cellHeight: 132
            model: page.shown
            ScrollBar.vertical: HudScrollBar {}
            delegate: Item {
                id: card
                required property var modelData
                required property int index
                width: memGrid.cellWidth; height: memGrid.cellHeight
                // Cards cascade in when the page opens.
                opacity: Math.max(0, Math.min(1, page.reveal * 2 - index * 0.08))
                Chamfer { x: 0; y: 0; width: parent.width - 10; height: parent.height - 10; cut: 10; fill: Theme.panel; fillOpacity: 0.85
                          stroke: cardMouse.containsMouse ? page.kindColour(card.modelData.kind) : Theme.line }
                MouseArea { id: cardMouse; anchors.fill: parent; hoverEnabled: true; acceptedButtons: Qt.NoButton }
                Rectangle { x: 0; y: 12; width: 3; height: parent.height - 34; color: page.kindColour(card.modelData.kind) }
                Column {
                    x: 16; y: 12; width: parent.width - 36; spacing: 3
                    Text { text: page.kindWord(card.modelData.kind) + (card.modelData.updated ? "  ·  " + card.modelData.updated.slice(0, 10) : "")
                           color: page.kindColour(card.modelData.kind); font.family: "monospace"; font.pixelSize: 10; font.letterSpacing: 1.5 }
                    Text { width: parent.width; text: card.modelData.title; color: Theme.text; font.pixelSize: 14; elide: Text.ElideRight }
                    Text { width: parent.width; text: card.modelData.excerpt || " "; color: Theme.muted; font.pixelSize: 11; elide: Text.ElideRight }
                }
                Row {
                    x: 16; anchors.bottom: parent.bottom; anchors.bottomMargin: 20; spacing: 8
                    HudButton { width: 76; implicitHeight: 30; caption: "Open"; onClicked: shell.openNote(card.modelData.path) }
                    HudButton {
                        width: 100; implicitHeight: 30
                        tone: page.armedForget === card.modelData.path ? "warning" : "normal"
                        caption: page.armedForget === card.modelData.path ? "Press again" : "Forget"
                        Accessible.name: "Forget " + card.modelData.title
                        onClicked: {
                            if (page.armedForget === card.modelData.path) { page.armedForget = ""; shell.forgetMemory(card.modelData.path) }
                            else { page.armedForget = card.modelData.path; disarm.restart() }
                        }
                    }
                }
            }
        }
    }
}
