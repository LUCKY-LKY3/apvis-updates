import QtQuick

// A HUD-style box: two cut corners, optional accent brackets. Used as the
// background of buttons, dock tiles and the Ask bar.
Canvas {
    id: box
    property color fill: Theme.raised
    property real fillOpacity: 0.8
    property color stroke: Theme.line
    property real strokeWidth: 1
    property real cut: 8
    property bool brackets: false
    onFillChanged: requestPaint()
    onStrokeChanged: requestPaint()
    onStrokeWidthChanged: requestPaint()
    onBracketsChanged: requestPaint()
    onWidthChanged: requestPaint()
    onHeightChanged: requestPaint()
    Component.onCompleted: requestPaint()
    function rgba(c, a) { return "rgba(" + Math.round(c.r * 255) + "," + Math.round(c.g * 255) + "," + Math.round(c.b * 255) + "," + a + ")" }
    onPaint: {
        const c = getContext("2d"), w = width, h = height, k = Math.min(cut, w / 3, h / 3), o = strokeWidth / 2
        c.reset(); c.clearRect(0, 0, w, h)
        c.beginPath(); c.moveTo(o, o); c.lineTo(w - k, o); c.lineTo(w - o, k); c.lineTo(w - o, h - o)
        c.lineTo(k, h - o); c.lineTo(o, h - k); c.closePath()
        c.fillStyle = rgba(fill, fillOpacity); c.fill()
        c.strokeStyle = rgba(stroke, 1); c.lineWidth = strokeWidth; c.stroke()
        if (brackets) {
            c.strokeStyle = rgba(Theme.accent, 0.95); c.lineWidth = 1.6
            c.beginPath(); c.moveTo(o, 10); c.lineTo(o, o); c.lineTo(10, o); c.stroke()
            c.beginPath(); c.moveTo(w - o, h - 10); c.lineTo(w - o, h - o); c.lineTo(w - 10, h - o); c.stroke()
        }
    }
}
