pragma Singleton
import QtQuick

// APVIS V2 colour tokens. Behaviour never depends on colour; the owner picks
// the accent from real renders (owner chose emerald-silver on 2026-09-23).
QtObject {
    id: theme
    property string accentName: "emerald-silver"

    readonly property var accents: ({
        "emerald":    { accent: "#62e3b1", accentSoft: "#2a8a67", line: "#315a4b", panel: "#091510", raised: "#10241d", hover: "#18392c",
                        bgTop: "#0b1913", bgMid: "#07100c", bgBottom: "#030806", text: "#e4f2eb", muted: "#91ada0", glow: "#23684c" },
        "cyan-steel": { accent: "#6cc6ff", accentSoft: "#2e6f96", line: "#2c4b5e", panel: "#08121a", raised: "#0e1f2b", hover: "#16324a",
                        bgTop: "#0a141c", bgMid: "#060d13", bgBottom: "#03070a", text: "#e3eef5", muted: "#8fa6b3", glow: "#1f5577" },
        // Owner-requested blends of emerald and cyan-steel (2026-09-23).
        "aqua":       { accent: "#64d6d6", accentSoft: "#2c7d80", line: "#2e5357", panel: "#081415", raised: "#0f2225", hover: "#17363a",
                        bgTop: "#0a1718", bgMid: "#060f10", bgBottom: "#030708", text: "#e3f0f0", muted: "#90aaaa", glow: "#215f62" },
        "emerald-steel": { accent: "#62e3b1", accentSoft: "#2a8a67", line: "#2c4b5e", panel: "#08121a", raised: "#0e1f2b", hover: "#16324a",
                        bgTop: "#0a141c", bgMid: "#060d13", bgBottom: "#03070a", text: "#e3eef5", muted: "#8fa6b3", glow: "#23684c" },
        "emerald-silver": { accent: "#62e3b1", accentSoft: "#2a8a67", line: "#454d51", panel: "#0d1012", raised: "#161a1d", hover: "#23292d",
                        bgTop: "#121518", bgMid: "#0a0c0e", bgBottom: "#050607", text: "#eef2f4", muted: "#9aa3a8", glow: "#23684c" },
        "cool-white": { accent: "#dfe8ee", accentSoft: "#7d8a93", line: "#3a4248", panel: "#0d1012", raised: "#161a1d", hover: "#23292d",
                        bgTop: "#121518", bgMid: "#0a0c0e", bgBottom: "#050607", text: "#eef2f4", muted: "#9aa3a8", glow: "#4a555c" }
    })
    readonly property var set: accents[accentName] || accents["emerald-silver"]

    readonly property color accent: set.accent
    readonly property color accentSoft: set.accentSoft
    readonly property color line: set.line
    readonly property color panel: set.panel
    readonly property color raised: set.raised
    readonly property color hover: set.hover
    readonly property color bgTop: set.bgTop
    readonly property color bgMid: set.bgMid
    readonly property color bgBottom: set.bgBottom
    readonly property color text: set.text
    readonly property color muted: set.muted
    readonly property color glow: set.glow
    // Semantic colours are fixed across accents: amber = your attention,
    // red = verified critical error only.
    readonly property color attention: "#e8bc70"
    readonly property color critical: "#e46a5f"
    readonly property color warm: "#f0b36a"
}
