import QtQuick

// The APVIS mark (V3, owner 2026-10-09): a miniature of the core, so the logo is the thing people see on
// Home. An outer ring broken by four gaps, a segmented reactor ring, an inner ring and a bright centre
// point, in the accent colour with a soft glow. (The earlier faceted "A" looked too much like Arch Linux.)
// Painted once per size or colour change.
Item {
    id: mark
    property color tint: Theme.accent
    property real glow: 0.6            // 0 = no glow
    implicitWidth: 64
    implicitHeight: 64

    function rgba(c, a, k) {
        k = k === undefined ? 1 : k
        return "rgba(" + Math.round(Math.min(255, c.r * 255 * k)) + "," + Math.round(Math.min(255, c.g * 255 * k)) + "," +
               Math.round(Math.min(255, c.b * 255 * k)) + "," + a + ")"
    }
    onTintChanged: art.requestPaint()
    onGlowChanged: art.requestPaint()

    Canvas {
        id: art
        anchors.fill: parent
        anchors.margins: -Math.max(mark.width, mark.height) * 0.25
        antialiasing: true
        onWidthChanged: requestPaint()
        onHeightChanged: requestPaint()
        Component.onCompleted: requestPaint()
        onPaint: {
            const c = getContext("2d")
            c.reset(); c.clearRect(0, 0, width, height)
            const T = mark.tint, cx = width / 2, cy = height / 2
            const R = Math.min(mark.width, mark.height) / 2          // the mark's own radius
            const lw = Math.max(1, R * 0.07)
            if (mark.glow > 0) {
                const g = c.createRadialGradient(cx, cy, R * 0.2, cx, cy, R * 1.45)
                g.addColorStop(0, mark.rgba(T, 0.18 * mark.glow)); g.addColorStop(0.55, mark.rgba(T, 0.05 * mark.glow))
                g.addColorStop(1, mark.rgba(T, 0))
                c.fillStyle = g; c.fillRect(0, 0, width, height)
            }
            c.lineCap = "round"
            // A fine outer ring broken at the four diagonals.
            c.strokeStyle = mark.rgba(T, 0.95, 1.15); c.lineWidth = Math.max(1, R * 0.06)
            for (let i = 0; i < 4; i++) {
                const mid = i * Math.PI / 2
                c.beginPath(); c.arc(cx, cy, R * 0.92, mid - 0.55, mid + 0.55); c.stroke()
            }
            // Six short segments of light closer in.
            c.strokeStyle = mark.rgba(T, 0.8); c.lineWidth = Math.max(1, R * 0.08)
            for (let i = 0; i < 6; i++) {
                const mid = i * Math.PI / 3 + Math.PI / 6
                c.beginPath(); c.arc(cx, cy, R * 0.62, mid - 0.32, mid + 0.32); c.stroke()
            }
            // The bright core of light.
            const p = c.createRadialGradient(cx, cy, 0, cx, cy, R * 0.34)
            p.addColorStop(0, mark.rgba(Theme.markGlint, 1)); p.addColorStop(0.35, mark.rgba(T, 1, 1.2))
            p.addColorStop(0.7, mark.rgba(T, 0.35)); p.addColorStop(1, mark.rgba(T, 0))
            c.fillStyle = p; c.beginPath(); c.arc(cx, cy, R * 0.34, 0, Math.PI * 2); c.fill()
        }
    }
    Accessible.role: Accessible.Graphic
    Accessible.name: "APVIS"
}
