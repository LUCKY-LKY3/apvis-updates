import QtQuick
import QtQuick.Controls
import QtQuick.Window
import "theme"
import "controls"
import "pages"
import "nucleus"
import "atlas"
import "home"

// V2 Home on the APVIS 7.0.1 layout the owner prefers (command spine with tabs,
// activity rail, a large Neural Fabric core, core nodes, command dock), in the
// emerald-silver accent. Every card reports real, sourced state.
Window {
    id: root
    visible: true
    visibility: previewWindowed ? Window.Windowed : Window.Maximized
    // Home is the desktop surface, not a decorated app window.
    flags: previewWindowed ? Qt.Window : (Qt.Window | Qt.FramelessWindowHint)
    minimumWidth: 900
    minimumHeight: 620
    width: 1440
    height: 900
    color: Theme.bgBottom
    title: "APVIS OS V2 — Home"

    readonly property color emerald: Theme.accent
    readonly property color pale: Theme.text
    readonly property color muted: Theme.muted
    readonly property color line: Theme.line
    Component.onCompleted: {
        Theme.accentName = (shell.render || {}).accent || "emerald-silver"
        shell.setSharedDisplay(sharedDisplay)
        shell.setFrameMeasuring(measuring)
        if (controlOpen) shell.refreshControl()
    }
    readonly property var state: shell.state || ({})
    readonly property var focus: state.focus || null
    readonly property var counts: state.task_counts || ({})
    readonly property var sys: shell.system || ({})
    readonly property var tel: shell.telemetry || ({})
    readonly property var route: shell.route || ({})
    readonly property var atlasInfo: shell.atlas || ({})
    property bool settingsOpen: previewPage === "settings"
    property bool missionsOpen: previewPage === "missions"
    property bool devOpen: previewPage === "dev"
    // Booted with "Install APVIS OS" from the USB menu: open the installer.
    property bool installOpen: previewPage === "install" || !!(shell.installer || {}).requested
    property bool atlasOpen: previewPage === "atlas" || previewPage === "atlas-home"
    property bool notesOpen: previewPage === "notes"
    // Smoke-test hook: visit Atlas, then return Home (renders the live card).
    Timer { running: previewPage === "atlas-home"; interval: 12000; onTriggered: root.openPage("") }
    // Smoke-test hook: "search:<text>" opens search with that text.
    Timer { running: previewPage.startsWith("search:"); interval: 600; onTriggered: { root.openSearch(); searchField.text = previewPage.slice(7) } }
    readonly property bool pageOpen: settingsOpen || missionsOpen || atlasOpen || notesOpen || devOpen || installOpen
    readonly property bool roomy: width >= 1180
    property Item selectedTab: null
    // Lite look (no GPU / minimal tier): the room is frozen into one cached
    // texture and decorative motion stops; the Nucleus and real data still live.
    readonly property bool lite: !!(shell.render || {}).lite
    readonly property bool calm: !!(shell.render || {}).reducedMotion || lite
    // Frame times only count while Home animates continuously (see setFrameMeasuring).
    readonly property bool measuring: !pageOpen && !calm && nucleus.animating
    onMeasuringChanged: shell.setFrameMeasuring(measuring)
    property date nowTick: new Date()
    Timer { interval: 1000; running: true; repeat: true; onTriggered: root.nowTick = new Date() }
    function bytes(n) { return n < 1024 ? n + " B/s" : n < 1048576 ? (n / 1024).toFixed(1) + " KB/s" : (n / 1048576).toFixed(1) + " MB/s" }
    function hms(ms) { const s = Math.max(0, Math.floor(ms / 1000)), h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60
                       return h + "h " + m + "m " + x + "s" }
    Connections {
        target: shell
        function onPageRequested(name) { root.openPage(name) }
        function onDevChanged() { if (!shell.developerMode && root.devOpen) root.devOpen = false }
    }
    // Opening a page puts the keyboard in its first field (Esc returns to Ask).
    onNotesOpenChanged: if (notesOpen) Qt.callLater(() => memoryPage.focusFirst())
    onSettingsOpenChanged: if (settingsOpen) Qt.callLater(() => settingsPage.focusFirst())
    // Example chips on the pages put their text in the Ask bar (the owner still presses Enter).
    function suggestAsk(text) { focusInput.text = text; focusInput.forceActiveFocus(); focusInput.cursorPosition = text.length }
    function openPage(name) {
        settingsOpen = name === "settings"; missionsOpen = name === "missions"; atlasOpen = name === "atlas"
        notesOpen = name === "notes"; devOpen = name === "dev" && shell.developerMode
        installOpen = name === "install" && !!(shell.installer || {}).live
    }
    Shortcut {
        sequences: [StandardKey.Cancel]
        enabled: (root.answering || root.pageOpen) && !root.searchOpen && !root.controlOpen && !root.keysOpen && !root.powerMenuOpen
        onActivated: { shell.closeAnswer(); root.openPage(""); focusInput.forceActiveFocus() }
    }
    readonly property var missions: shell.missions || []
    // Presentation privacy (V2-13): with a second screen attached, private context
    // (Focus, mission and note text, Notes/Missions pages) stays hidden until the
    // owner confirms the screens are theirs. Resets when the extra screen goes.
    property bool trustedScreens: false
    readonly property int screenCount: Qt.application.screens.length
    readonly property bool sharedDisplay: (screenCount > 1 || previewPage === "shared") && !trustedScreens
    onScreenCountChanged: if (screenCount < 2) trustedScreens = false
    onSharedDisplayChanged: shell.setSharedDisplay(sharedDisplay)
    function priv(text) { return sharedDisplay ? "Hidden · second screen" : text }
    readonly property var activeMissions: missions.filter(m => m.status === "approval_required" || m.status === "running")
    // Tell the owner when something waits for approval while another app is in front.
    property var notifiedApprovals: ({})
    onMissionsChanged: {
        for (const m of missions) {
            if (m.status !== "approval_required" || notifiedApprovals[m.id]) continue
            notifiedApprovals[m.id] = true
            if (Qt.application.state !== Qt.ApplicationActive)
                shell.notify("APVIS needs your approval", m.preview || m.title)
        }
    }
    function statusText(status) {
        return status === "approval_required" ? "Waiting for you" : status === "completed" ? "Done" :
               status === "failed" ? "Did not complete" : status === "cancelled" ? "Cancelled" :
               status === "running" ? "Running" : status
    }
    function statusColor(status) {
        return status === "approval_required" || status === "failed" ? Theme.attention :
               status === "completed" ? Theme.accent : Theme.muted
    }
    readonly property var activity: {
        const items = missions.map(m => ({ glyph: m.status === "completed" ? "check" : "mission", text: m.preview,
                                           kind: "MISSION", when: m.updatedAt, color: statusColor(m.status) }))
            .concat((shell.notes || []).map(n => ({ glyph: "notes", text: "Saved: " + n.title, kind: "VAULT", when: n.updated, color: Theme.accent })))
        items.sort((a, b) => (b.when || "").localeCompare(a.when || ""))
        return items.slice(0, 6)
    }
    readonly property var answer: shell.ask || ({ state: "closed" })
    readonly property bool answering: (answer.state || "closed") !== "closed"
    readonly property string modeWord: answering ? "ANSWERING" : state.nucleus_mode === "attention" ? "ATTENTION" :
                                       state.nucleus_mode === "continuity_unknown" ? "CHECK" : "STANDBY"
    readonly property int airborne: (JSON.parse(shell.atlasAircraft || "[]")).filter(p => !p[7]).length
    readonly property int nodeCount: 1 + (route.host && !route.thisDevice ? 1 : 0)
    readonly property int linkCount: route.reachable ? 1 : 0
    readonly property int channelCount: (route.reachable ? 1 : 0) + (atlasOpen && atlasInfo.status === "live" ? 1 : 0)


    // A HUD panel frame (used by the right-hand lists and pages).
    component Card: Item {
        id: card
        property string title: ""
        property string glyph: ""
        property string code: ""
        default property alias content: body.data
        width: parent ? parent.width : 280
        height: body.y + body.childrenRect.height + 14
        Chamfer { anchors.fill: parent; cut: 12; fill: Theme.panel; fillOpacity: 0.7; brackets: true }
        Text { x: 14; y: 11; text: card.title; color: Theme.text; font.family: "monospace"; font.pixelSize: 11; font.letterSpacing: 2; font.bold: true }
        Text { anchors.right: parent.right; anchors.rightMargin: 16; y: 12; text: card.code; color: Theme.muted
               font.family: "monospace"; font.pixelSize: 9; font.letterSpacing: 1 }
        Item { id: body; x: 14; y: 36; width: card.width - 28 }
    }

    // Activity rail service card (V7 style): icon disc, name, status line, state word, waveform.
    component RailCard: Item {
        id: rail
        property string glyph: "core"
        property string title: ""
        property string detail: ""
        property string word: "READY"
        property color wordColour: Theme.accent
        property var series: []
        property bool active: false
        signal activated()
        width: parent ? parent.width : 230
        height: 78

        // Holographic finish: light from the core on the facing edge, a slow light
        // sweep, and a staggered entry when Home appears.
        property int order: 0
        property real coreSide: 1       // 1 = core is to the right of this card, -1 = to the left
        opacity: 0
        transform: Translate { id: slide; x: -24 * coreSide }
        Component.onCompleted: entry.start()
        SequentialAnimation {
            id: entry
            PauseAnimation { duration: 120 + order * 90 }
            ParallelAnimation {
                NumberAnimation { target: rail; property: "opacity"; to: 1; duration: 520; easing.type: Easing.OutCubic }
                NumberAnimation { target: slide; property: "x"; to: 0; duration: 620; easing.type: Easing.OutCubic }
            }
        }
        Rectangle {
            width: 26; height: parent.height - 8; y: 4
            x: rail.coreSide > 0 ? parent.width - width : 0
            gradient: Gradient { orientation: Gradient.Horizontal
                GradientStop { position: 0; color: rail.coreSide > 0 ? "transparent" : Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.16) }
                GradientStop { position: 1; color: rail.coreSide > 0 ? Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.16) : "transparent" } }
        }
        Rectangle { width: 1.5; height: parent.height - 16; y: 8; x: rail.coreSide > 0 ? parent.width - 1.5 : 0; color: Theme.accent; opacity: 0.7 }
        Item {
            anchors.fill: parent; clip: true
            Rectangle {
                id: sweep
                width: parent.width * 0.35; height: parent.height * 2; y: -parent.height / 2; rotation: 18
                x: -width * 2
                gradient: Gradient { orientation: Gradient.Horizontal
                    GradientStop { position: 0; color: "transparent" }
                    GradientStop { position: 0.5; color: Qt.rgba(Theme.text.r, Theme.text.g, Theme.text.b, 0.05) }
                    GradientStop { position: 1; color: "transparent" } }
                SequentialAnimation on x {
                    loops: Animation.Infinite
                    running: !root.calm
                    PauseAnimation { duration: 6000 + rail.order * 1300 }
                    NumberAnimation { from: -sweep.width * 2; to: rail.width + sweep.width; duration: 1600; easing.type: Easing.InOutSine }
                }
            }
        }
        Chamfer { anchors.fill: parent; cut: 10; fill: Theme.panel; fillOpacity: rail.active ? 0.9 : 0.7
                  stroke: rail.active || railMouse.containsMouse ? Theme.accent : Theme.line }
        Rectangle { visible: rail.active; width: 3; height: parent.height - 20; y: 10; color: Theme.accent }
        Rectangle {
            x: 12; anchors.verticalCenter: parent.verticalCenter
            width: 38; height: 38; radius: 19; color: Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.08)
            border.color: Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.45)
            Glyph { anchors.centerIn: parent; width: 18; height: 18; kind: rail.glyph; stroke: Theme.accent }
        }
        Column {
            x: 62; anchors.verticalCenter: parent.verticalCenter; width: parent.width - 62 - spark.width - 14; spacing: 3
            Text { text: rail.title; color: Theme.text; font.family: "monospace"; font.pixelSize: rail.width < 250 ? 10 : 11; font.letterSpacing: rail.width < 250 ? 0 : 1; elide: Text.ElideRight; width: parent.width }
            Text { text: rail.detail; color: Theme.muted; font.pixelSize: 10; elide: Text.ElideRight; width: parent.width }
            Text { text: rail.word; color: rail.wordColour; font.family: "monospace"; font.pixelSize: 9; font.letterSpacing: 1.2 }
        }
        Sparkline { id: spark; anchors.right: parent.right; anchors.rightMargin: 10; anchors.verticalCenter: parent.verticalCenter
                    width: rail.width < 250 ? 40 : 60; height: 26; values: rail.series; colour: rail.wordColour }
        MouseArea { id: railMouse; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: rail.activated() }
        Accessible.role: Accessible.Button
        Accessible.name: title + ": " + detail + ", " + word
    }

    // Core node card (V7 style): big icon, name, state, role, waveform.
    component NodeCard: Item {
        id: node
        property string glyph: "device"
        property string title: ""
        property string word: ""
        property color wordColour: Theme.accent
        property string role: ""
        property var series: []
        width: parent ? parent.width : 250
        height: 112

        // Holographic finish: light from the core on the facing edge, a slow light
        // sweep, and a staggered entry when Home appears.
        property int order: 0
        property real coreSide: 1       // 1 = core is to the right of this card, -1 = to the left
        opacity: 0
        transform: Translate { id: slide; x: -24 * coreSide }
        Component.onCompleted: entry.start()
        SequentialAnimation {
            id: entry
            PauseAnimation { duration: 120 + order * 90 }
            ParallelAnimation {
                NumberAnimation { target: node; property: "opacity"; to: 1; duration: 520; easing.type: Easing.OutCubic }
                NumberAnimation { target: slide; property: "x"; to: 0; duration: 620; easing.type: Easing.OutCubic }
            }
        }
        Rectangle {
            width: 26; height: parent.height - 8; y: 4
            x: node.coreSide > 0 ? parent.width - width : 0
            gradient: Gradient { orientation: Gradient.Horizontal
                GradientStop { position: 0; color: node.coreSide > 0 ? "transparent" : Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.16) }
                GradientStop { position: 1; color: node.coreSide > 0 ? Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.16) : "transparent" } }
        }
        Rectangle { width: 1.5; height: parent.height - 16; y: 8; x: node.coreSide > 0 ? parent.width - 1.5 : 0; color: Theme.accent; opacity: 0.7 }
        Item {
            anchors.fill: parent; clip: true
            Rectangle {
                id: sweep
                width: parent.width * 0.35; height: parent.height * 2; y: -parent.height / 2; rotation: 18
                x: -width * 2
                gradient: Gradient { orientation: Gradient.Horizontal
                    GradientStop { position: 0; color: "transparent" }
                    GradientStop { position: 0.5; color: Qt.rgba(Theme.text.r, Theme.text.g, Theme.text.b, 0.05) }
                    GradientStop { position: 1; color: "transparent" } }
                SequentialAnimation on x {
                    loops: Animation.Infinite
                    running: !root.calm
                    PauseAnimation { duration: 6000 + node.order * 1300 }
                    NumberAnimation { from: -sweep.width * 2; to: node.width + sweep.width; duration: 1600; easing.type: Easing.InOutSine }
                }
            }
        }
        Chamfer { anchors.fill: parent; cut: 12; fill: Theme.panel; fillOpacity: 0.75; brackets: true }
        Rectangle { width: 3; height: parent.height - 24; y: 12; color: Theme.accent; opacity: 0.8 }
        Rectangle {
            x: 14; y: 14; width: 46; height: 46; radius: 23; color: Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.08)
            border.color: Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.5)
            Glyph { anchors.centerIn: parent; width: 24; height: 24; kind: node.glyph; stroke: Theme.text }
        }
        Column {
            x: 72; y: 14; width: parent.width - 86; spacing: 3
            Text { text: node.title; color: Theme.text; font.family: "monospace"; font.pixelSize: 13; font.bold: true; font.letterSpacing: 1; elide: Text.ElideRight; width: parent.width }
            Text { text: node.word; color: node.wordColour; font.family: "monospace"; font.pixelSize: 10; font.letterSpacing: 1.2 }
            Text { text: node.role; color: Theme.muted; font.pixelSize: 10; elide: Text.ElideRight; width: parent.width }
        }
        Sparkline { x: 12; y: parent.height - 34; width: parent.width - 24; height: 24; values: node.series }
    }

    // Section heading: accent mark, spaced title, and a rule fading to the right.
    component SectionLabel: Item {
        id: sl
        property string text: ""
        width: parent ? parent.width : 240; height: 22
        Rectangle { width: 5; height: 5; rotation: 45; color: Theme.accent; anchors.verticalCenter: parent.verticalCenter; x: 1 }
        Text { id: slText; x: 14; anchors.verticalCenter: parent.verticalCenter; text: sl.text; color: Theme.text
               font.family: "monospace"; font.pixelSize: 11; font.letterSpacing: 2; font.bold: true }
        Rectangle {
            x: slText.x + slText.implicitWidth + 10; anchors.verticalCenter: parent.verticalCenter
            width: Math.max(0, parent.width - x); height: 1
            gradient: Gradient { orientation: Gradient.Horizontal
                GradientStop { position: 0; color: Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.5) }
                GradientStop { position: 1; color: "transparent" } }
        }
    }

    component KeyValue: Item {
        property string k: ""
        property string v: ""
        property color vColour: Theme.text
        property string glyph: ""
        property real fraction: -1       // 0..1 shows a load bar under the row
        width: parent ? parent.width : 240
        height: 26
        Glyph { visible: parent.glyph.length > 0; width: 13; height: 13; kind: parent.glyph; stroke: Theme.accent; anchors.verticalCenter: parent.verticalCenter }
        Text { x: parent.glyph.length > 0 ? 22 : 0; anchors.verticalCenter: parent.verticalCenter; text: parent.k; color: Theme.muted
               font.family: "monospace"; font.pixelSize: 10; font.letterSpacing: 1.2 }
        Text { anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter; text: parent.v; color: parent.vColour
               font.family: "monospace"; font.pixelSize: 11 }
        Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1; color: Theme.line; opacity: 0.6 }
        Rectangle { visible: parent.fraction >= 0; anchors.bottom: parent.bottom; height: 2; radius: 1
                    width: parent.width * Math.max(0, Math.min(1, parent.fraction))
                    color: parent.fraction >= 0.9 ? Theme.attention : Theme.accent; opacity: 0.85
                    Behavior on width { NumberAnimation { duration: 600; easing.type: Easing.OutCubic } } }
    }

    // ------------------------------------------------------------ backdrop
    // Volumetric smoke on the GPU tier; cached haze on Safe Graphics.
    // GPU smoke only on the Full tier: the quality loop sheds the smoke first,
    // before particles or the 3D Nucleus (dev.18 OptiPlex: smoke was the cost).
    readonly property bool gpuSmoke: ((shell.render || {}).renderer || "canvas") === "sphere3d"
                                     && ((shell.render || {}).tier || "") === "full"
    readonly property point coreCentre: Qt.point((centre.x + nucleus.x + nucleus.width / 2) / Math.max(1, root.width),
                                                 (centre.y + nucleus.y + nucleus.height / 2) / Math.max(1, root.height))
    readonly property real coreRadius: nucleus.width * 0.36 / Math.max(1, root.height)
    Item {
    id: room
    anchors.fill: parent
    layer.enabled: root.lite
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: Theme.bgTop }
            GradientStop { position: 0.55; color: Theme.bgMid }
            GradientStop { position: 1.0; color: Theme.bgBottom }
        }
    }
    Backdrop {
        anchors.fill: parent
        phase: nucleus.time
        reducedMotion: root.calm
        horizon: 0.70
    }
    HudGrid { anchors.fill: parent; opacity: 0.45 }
    Loader {
        anchors.fill: parent
        active: root.gpuSmoke && !root.calm
        source: "home/Smoke.qml"
        onLoaded: {
            item.time = Qt.binding(() => nucleus.time)
            item.center = Qt.binding(() => root.coreCentre)
            item.radius = Qt.binding(() => root.coreRadius)
            item.strength = Qt.binding(() => root.pageOpen ? 0.45 : 1.0)
        }
    }
    Atmosphere {
        // Cached haze across the room; lighter where the GPU smoke takes over at the core.
        anchors.fill: parent
        phase: nucleus.time
        reducedMotion: root.calm
        focusX: 0.5
        focusY: (centre.y + nucleus.y + nucleus.height / 2) / Math.max(1, root.height)
        opacity: root.pageOpen ? 0.45 : root.gpuSmoke && !root.calm ? 0.55 : 1
        Behavior on opacity { NumberAnimation { duration: 400 } }
    }
    }

    LinkLayer {
        id: links
        anchors.fill: parent
        // Fades/slides instead of popping; hidden (and idle) once fully faded.
        opacity: (!root.pageOpen && root.roomy) ? 1 : 0
        visible: (!root.pageOpen && root.roomy) || opacity > 0.01
        Behavior on opacity { NumberAnimation { duration: 240; easing.type: Easing.OutCubic } }
        core: Qt.point(root.coreCentre.x * root.width, root.coreCentre.y * root.height)
        ring: nucleus.width * 0.43
    }
    function edge(item, side) {
        if (!item || !item.visible) return null
        const p = item.mapToItem(null, side > 0 ? item.width : 0, item.height / 2)
        return p
    }
    function updateLinks() {
        const spec = [["sys", railSys, 1, root.sys.available], ["mission", railMission, 1, root.activeMissions.length > 0],
                      ["osiris", railOsiris, 1, root.atlasOpen && root.atlasInfo.status === "live"],
                      ["vault", railVault, 1, (shell.inbox || []).length > 0],
                      ["host", nodeHost, -1, true], ["ai", nodeAi, -1, !!root.route.reachable]]
        const out = []
        for (const s of spec) {
            const p = edge(s[1], s[2])
            if (p) out.push({ key: s[0], x: p.x, y: p.y, side: s[2], live: s[3] })
        }
        if (JSON.stringify(out) !== JSON.stringify(links.sockets)) links.sockets = out
    }
    Timer { interval: 1500; running: !root.pageOpen; repeat: true; triggeredOnStart: true; onTriggered: root.updateLinks() }
    onWidthChanged: Qt.callLater(updateLinks)
    onHeightChanged: Qt.callLater(updateLinks)
    // Pulses mark real data arriving: telemetry samples, AI host checks, flight
    // snapshots, mission changes and vault changes.
    Connections { target: shell
        function onSystemChanged() { links.pulse("sys"); links.pulse("host") }
        function onMissionsChanged() { links.pulse("mission") }
        function onAtlasChanged() { if (root.atlasInfo.status === "live") links.pulse("osiris") }
        function onMemoryChanged() { links.pulse("vault") }
    }
    property string lastRouteModel: ""
    onRouteChanged: if ((route.model || "") + route.reachable !== lastRouteModel) { lastRouteModel = (route.model || "") + route.reachable; links.pulse("ai") }

    // ------------------------------------------------------------ command spine (V7)
    Item {
        id: topBar
        x: 0; y: 0; width: root.width; height: 66
        Canvas {
            anchors.fill: parent
            onWidthChanged: requestPaint(); Component.onCompleted: requestPaint()
            function rgba(c, a) { return "rgba(" + Math.round(c.r * 255) + "," + Math.round(c.g * 255) + "," + Math.round(c.b * 255) + "," + a + ")" }
            onPaint: {
                const c = getContext("2d"), w = width, h = height, mid = w / 2, nav = Math.min(360, w * 0.26)
                c.reset(); c.clearRect(0, 0, w, h); c.lineWidth = 1
                c.strokeStyle = rgba(Theme.accent, 0.35)
                c.beginPath(); c.moveTo(14, h - 2); c.lineTo(mid - nav - 50, h - 2); c.lineTo(mid - nav - 32, h - 20); c.lineTo(mid - nav, h - 20); c.stroke()
                c.beginPath(); c.moveTo(mid + nav, h - 20); c.lineTo(mid + nav + 32, h - 20); c.lineTo(mid + nav + 50, h - 2); c.lineTo(w - 14, h - 2); c.stroke()
                c.strokeStyle = rgba(Theme.accent, 0.75)
                c.beginPath(); c.moveTo(mid - nav, h - 20); c.lineTo(mid - nav + 22, h - 44); c.lineTo(mid + nav - 22, h - 44); c.lineTo(mid + nav, h - 20); c.stroke()
                c.fillStyle = rgba(Theme.accent, 0.95)
                c.beginPath(); c.arc(mid - nav + 10, h - 20, 2.2, 0, Math.PI * 2); c.arc(mid + nav - 10, h - 20, 2.2, 0, Math.PI * 2); c.fill()
                c.strokeStyle = rgba(Theme.accent, 0.4)
                c.beginPath(); c.moveTo(mid - nav + 80, h - 2); c.lineTo(mid - nav + 220, h - 2); c.moveTo(mid + nav - 220, h - 2); c.lineTo(mid + nav - 80, h - 2); c.stroke()
            }
        }
        Row {
            x: 24; anchors.verticalCenter: parent.verticalCenter; spacing: 14
            Glyph { width: 34; height: 34; kind: "apvis"; anchors.verticalCenter: parent.verticalCenter }
            Text { text: "APVIS"; color: Theme.text; font.pixelSize: 22; font.weight: Font.DemiBold; font.letterSpacing: 4; anchors.verticalCenter: parent.verticalCenter }
        }
        Rectangle {
            id: tabPill
            visible: root.selectedTab !== null
            y: tabs.y; height: 30
            x: tabs.x + (root.selectedTab ? root.selectedTab.x : 0)
            width: root.selectedTab ? root.selectedTab.width : 0
            color: Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.12)
            border.width: 1; border.color: Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.5)
            Behavior on x { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } }
            Behavior on width { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } }
            Rectangle { anchors.horizontalCenter: parent.horizontalCenter; anchors.bottom: parent.bottom
                        width: parent.width * 0.6; height: 2; color: Theme.accent }
            Rectangle { anchors.horizontalCenter: parent.horizontalCenter; anchors.bottom: parent.bottom; anchors.bottomMargin: -3
                        width: parent.width * 0.8; height: 5; radius: 2.5; color: Theme.accent; opacity: 0.18 }
        }
        Row {
            id: tabs
            anchors.horizontalCenter: parent.horizontalCenter
            y: 22
            spacing: 4
            Repeater {
                model: [["CORE", ""], ["MISSIONS", "missions"], ["ATLAS", "atlas"], ["MEMORY", "notes"], ["SETTINGS", "settings"]]
                       .concat(shell.developerMode ? [["DEV", "dev"]] : [])
                delegate: Button {
                    id: tab
                    required property var modelData
                    readonly property bool selected: modelData[1] === "" ? !root.pageOpen :
                        (modelData[1] === "missions" && root.missionsOpen) || (modelData[1] === "atlas" && root.atlasOpen) ||
                        (modelData[1] === "notes" && root.notesOpen) || (modelData[1] === "settings" && root.settingsOpen) ||
                        (modelData[1] === "dev" && root.devOpen)
                    readonly property bool badge: (modelData[1] === "missions" && root.activeMissions.length > 0) ||
                                                  (modelData[1] === "settings" && (shell.updates || {}).state === "available") ||
                                                  (modelData[1] === "notes" && (shell.inbox || []).length > 0)
                    width: modelData[0].length * 8 + 34; height: 30
                    onSelectedChanged: if (selected) root.selectedTab = tab
                    Component.onCompleted: if (selected) root.selectedTab = tab
                    Accessible.name: modelData[0] + (badge ? ", needs attention" : "")
                    onClicked: root.openPage(modelData[1])
                    contentItem: Item {
                        Text { anchors.centerIn: parent; text: tab.modelData[0]; color: tab.selected || tab.hovered ? Theme.text : Theme.muted
                               font.family: "monospace"; font.pixelSize: 10; font.letterSpacing: 1.4
                               Behavior on color { ColorAnimation { duration: 180 } } }
                        Rectangle { visible: tab.badge; width: 5; height: 5; radius: 2.5; color: Theme.attention; anchors.right: parent.right; anchors.rightMargin: 4; y: 4 }
                    }
                    // The selection itself is one pill that slides between tabs (tabPill).
                    background: Rectangle {
                        color: tab.hovered && !tab.selected ? Theme.hover : "transparent"
                        Behavior on color { ColorAnimation { duration: 150 } }
                        border.width: tab.activeFocus ? 2 : 0
                        border.color: Theme.text
                    }
                }
            }
        }
        HudButton {
            id: powerTop
            anchors.right: parent.right; anchors.rightMargin: 18; anchors.verticalCenter: parent.verticalCenter
            width: 38; implicitHeight: 34
            glyph: "power"; caption: ""
            tone: root.powerMenuOpen ? "selected" : "normal"
            Accessible.name: "Power menu"
            ToolTip.visible: hovered; ToolTip.text: "Power"
            onClicked: root.powerMenuOpen = !root.powerMenuOpen
        }
        Column {
            anchors.right: powerTop.left; anchors.rightMargin: 16; anchors.verticalCenter: parent.verticalCenter
            Text { anchors.right: parent.right; text: root.atlasOpen ? "ATLAS FABRIC" : root.missionsOpen ? "MISSION CONTROL" : root.notesOpen ? "MEMORY VAULT" : root.settingsOpen ? "SETTINGS" : root.devOpen ? "DEVELOPER" : root.installOpen ? "INSTALL" : "NEURAL FABRIC"
                   color: Theme.text; font.family: "monospace"; font.pixelSize: 13; font.letterSpacing: 1.5 }
            Text { anchors.right: parent.right; text: root.modeWord; color: root.modeWord === "ATTENTION" ? Theme.attention : Theme.accent
                   font.family: "monospace"; font.pixelSize: 11; font.letterSpacing: 1.2 }
        }
    }

    // ------------------------------------------------------------ activity rail (left)
    Item {
        id: leftCol
        // Fades/slides instead of popping; hidden (and idle) once fully faded.
        opacity: (!root.pageOpen && root.roomy) ? 1 : 0
        visible: (!root.pageOpen && root.roomy) || opacity > 0.01
        Behavior on opacity { NumberAnimation { duration: 240; easing.type: Easing.OutCubic } }
        transform: Translate { x: (!root.pageOpen && root.roomy) ? 0 : -30; y: (!root.pageOpen && root.roomy) ? 0 : 0
            Behavior on x { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } }
            Behavior on y { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } } }
        x: 18; y: topBar.height + 14
        width: Math.min(270, root.width * 0.19)
        height: dock.y - y - 18
        Chamfer { anchors.fill: parent; cut: 14; fill: Theme.bgBottom; fillOpacity: 0.35; stroke: Theme.line }
        SectionLabel { x: 14; y: 9; width: parent.width - 28; text: "ACTIVITY RAIL" }
        Column {
            id: railColumn
            x: 12; y: 38; width: parent.width - 24; spacing: 10
            RailCard {
                id: railSys; order: 0
                glyph: "activity"; title: "SYSTEM WATCHER"
                detail: root.sys.available ? "CPU " + root.sys.cpu + "% · MEM " + root.sys.memory + "%" : "Measurements unavailable"
                word: !root.sys.available ? "UNAVAILABLE" : (root.sys.cpu >= 90 || root.sys.memory >= 90) ? "HIGH LOAD" : "LIVE"
                wordColour: !root.sys.available || root.sys.cpu >= 90 || root.sys.memory >= 90 ? Theme.attention : Theme.accent
                series: (root.tel.history || {}).cpu || []
            }
            RailCard {
                id: railMission; order: 1
                glyph: "mission"; title: "MISSION CONTROL"
                detail: root.activeMissions.length ? root.priv(root.activeMissions[0].preview) : (root.missions.length ? root.missions.length + " recent · none waiting" : "Awaiting a request")
                word: root.activeMissions.length ? root.activeMissions.length + " WAITING" : "READY"
                wordColour: root.activeMissions.length ? Theme.attention : Theme.accent
                active: root.activeMissions.length > 0
                onActivated: root.openPage("missions")
            }
            RailCard {
                id: railOsiris; order: 2
                glyph: "plane"; title: "OSIRIS FEED"
                detail: root.atlasInfo.fetched_at ? "Atlas · " + root.airborne + " airborne" : "Starts when Atlas opens"
                word: root.atlasOpen && root.atlasInfo.status === "live" ? "LIVE" : root.atlasInfo.fetched_at ? "LAST SNAPSHOT" : "STANDBY"
                wordColour: root.atlasOpen && root.atlasInfo.status === "live" ? Theme.accent : Theme.muted
                series: (root.tel.history || {}).down || []
                onActivated: root.openPage("atlas")
            }
            RailCard {
                order: 3
                glyph: "brain"; title: "PRIVACY WATCH"
                detail: "Ask: " + (root.route.policy === "local-only" || !root.route.policy ? "local only" : root.route.policy)
                word: "LOCAL"
            }
            RailCard {
                id: railVault; order: 4
                glyph: "notes"; title: "MEMORY VAULT"
                detail: (shell.notes || []).length + " memories" + ((shell.inbox || []).length ? " · " + (shell.inbox || []).length + " to review" : "")
                word: (shell.inbox || []).length ? "REVIEW" : "SYNCED"
                wordColour: (shell.inbox || []).length ? Theme.attention : Theme.accent
                onActivated: root.openPage("notes")
            }
        }
        Item {
            x: 12; y: railColumn.y + railColumn.height + 12
            width: parent.width - 24; height: parent.height - y - 12
            visible: height > 60
            Chamfer { anchors.fill: parent; cut: 10; fill: Theme.panel; fillOpacity: 0.6 }
            Text { x: 10; y: 9; text: "EVENT LOG"; color: Theme.text; font.family: "monospace"; font.pixelSize: 10; font.letterSpacing: 1.8; font.bold: true }
            Column {
                x: 10; y: 30; width: parent.width - 20; spacing: 5
                clip: true; height: parent.height - 36
                Text { visible: root.activity.length === 0; text: "• " + Qt.formatDateTime(root.nowTick, "HH:mm:ss") + "  SYSTEM"
                       color: Theme.muted; font.family: "monospace"; font.pixelSize: 10 }
                Text { visible: root.activity.length === 0; text: root.state.status_text ? root.state.status_text.toUpperCase() : "NO EVENTS YET"
                       color: Theme.accent; font.family: "monospace"; font.pixelSize: 10; width: parent.width; elide: Text.ElideRight }
                Repeater {
                    model: root.activity
                    delegate: Column {
                        required property var modelData
                        width: parent.width
                        Text { text: "• " + (modelData.when ? Qt.formatDateTime(new Date(modelData.when), "HH:mm:ss") : "--:--:--") + "  " + modelData.kind
                               color: Theme.muted; font.family: "monospace"; font.pixelSize: 10 }
                        Text { width: parent.width; text: root.priv(modelData.text).toUpperCase(); color: modelData.color; font.family: "monospace"; font.pixelSize: 10; elide: Text.ElideRight }
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------ core nodes (right)
    Column {
        id: rightCol
        // Fades/slides instead of popping; hidden (and idle) once fully faded.
        opacity: (!root.pageOpen && root.roomy) ? 1 : 0
        visible: (!root.pageOpen && root.roomy) || opacity > 0.01
        Behavior on opacity { NumberAnimation { duration: 240; easing.type: Easing.OutCubic } }
        transform: Translate { x: (!root.pageOpen && root.roomy) ? 0 : 30; y: (!root.pageOpen && root.roomy) ? 0 : 0
            Behavior on x { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } }
            Behavior on y { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } } }
        width: Math.min(290, root.width * 0.2)
        x: root.width - width - 18; y: topBar.height + 14; spacing: 12
        SectionLabel { text: "CORE NODES" }
        NodeCard {
            id: nodeHost; order: 1; coreSide: -1
            glyph: "device"; title: (root.sys.hostname || "THIS DEVICE").toUpperCase()
            word: "ONLINE"; role: "ORCHESTRATOR · THIS DEVICE"
            series: (root.tel.history || {}).memory || []
        }
        NodeCard {
            id: nodeAi; order: 2; coreSide: -1
            glyph: "brain"
            title: root.route.thisDevice || !root.route.host ? "LOCAL AI" : "AI HOST"
            word: root.route.reachable ? "ONLINE" : root.route.checking ? "CHECKING" : "NOT REACHABLE"
            wordColour: root.route.reachable ? Theme.accent : Theme.attention
            role: root.route.reachable ? (root.route.model || "no model") + " · Ollama " + (root.route.version || "") : (root.route.host || "set in Settings")
            series: (root.tel.history || {}).up || []
        }
        SectionLabel { text: "SYSTEM METRICS" }
        Item {
            width: parent.width; height: metrics.height + 16
            Chamfer { anchors.fill: parent; cut: 10; fill: Theme.raised; fillOpacity: 0.7; fill2: Theme.bgBottom; fill2Opacity: 0.7; edgeGlow: true }
            Column {
                id: metrics
                x: 12; y: 8; width: parent.width - 24
                KeyValue { glyph: "cpu"; k: "CPU"; v: root.sys.available ? root.sys.cpu + "%" : "—"; fraction: root.sys.available ? root.sys.cpu / 100 : -1 }
                KeyValue { glyph: "memory"; k: "RAM"; v: root.tel.memoryUsedGb ? root.tel.memoryUsedGb + "/" + root.tel.memoryTotalGb + " GB  " + root.sys.memory + "%" : "—"
                           fraction: root.sys.available ? root.sys.memory / 100 : -1 }
                KeyValue { glyph: "storage"; k: "DISK"; v: root.sys.available && root.sys.disk !== null ? root.sys.disk + "%" : "—"
                           fraction: root.sys.available && root.sys.disk !== null ? root.sys.disk / 100 : -1 }
                KeyValue { glyph: "activity"; k: "UPTIME"; v: root.sys.boot_epoch_ms ? root.hms(root.nowTick.getTime() - root.sys.boot_epoch_ms) : "—" }
                KeyValue { glyph: "wifi"; k: "NETWORK"; v: root.sys.netRates ? "▼ " + root.bytes(root.sys.netRates.down) + "  ▲ " + root.bytes(root.sys.netRates.up) : "—" }
            }
        }
        SectionLabel { text: "ENVIRONMENT" }
        Item {
            width: parent.width; height: env.height + 16
            Chamfer { anchors.fill: parent; cut: 10; fill: Theme.raised; fillOpacity: 0.7; fill2: Theme.bgBottom; fill2Opacity: 0.7; edgeGlow: true }
            Column {
                id: env
                x: 12; y: 8; width: parent.width - 24
                KeyValue { glyph: "brain"; k: "PRIVACY"; v: "LOCAL ONLY"; vColour: Theme.accent }
                KeyValue { glyph: "mission"; k: "FOCUS"; v: root.sharedDisplay ? "HIDDEN" : root.focus ? root.focus.label.toUpperCase() : "NONE"; vColour: root.focus ? Theme.text : Theme.muted }
                KeyValue { glyph: "check"; k: "APPROVALS"; v: root.activeMissions.length ? root.activeMissions.length + " WAITING" : "NONE"
                           vColour: root.activeMissions.length ? Theme.attention : Theme.muted }
            }
        }
    }

    // ------------------------------------------------------------ centre: the Neural Fabric, or an open page
    Item {
        id: centre
        readonly property real leftEdge: root.pageOpen || !root.roomy ? 18 : leftCol.x + leftCol.width + 8
        readonly property real rightEdge: root.pageOpen || !root.roomy ? root.width - 18 : rightCol.x - 8
        x: leftEdge; y: topBar.height + 2
        width: Math.max(350, rightEdge - leftEdge)
        height: dock.y - y - 6
        Nucleus {
            id: nucleus
            // Fades/slides instead of popping; hidden (and idle) once fully faded.
            opacity: (!root.pageOpen) ? 1 : 0
            visible: (!root.pageOpen) || opacity > 0.01
            Behavior on opacity { NumberAnimation { duration: 280; easing.type: Easing.OutCubic } }
            scale: (!root.pageOpen) ? 1 : 0.9
            Behavior on scale { NumberAnimation { duration: 340; easing.type: Easing.OutCubic } }
            width: Math.min(parent.width, parent.height * 1.02)
            height: width
            x: (parent.width - width) / 2
            y: (parent.height - height) / 2
            renderer: (shell.render || {}).renderer || "canvas"
            particles: (shell.render || {}).particles || 900
            reducedMotion: !!(shell.render || {}).reducedMotion
            canvasPoints: shell.canvasPoints
            clock: shell.clock
            motion: (shell.nucleus || {}).motion || ({})
            shape: root.answering ? "aperture" : ((shell.nucleus || {}).shape || "sphere")
            answer: root.answer
            onCloseAnswer: { shell.closeAnswer(); focusInput.forceActiveFocus() }
            onAcceptMemory: (proposalId) => { shell.acceptMemory(proposalId); focusInput.forceActiveFocus() }
            onRejectMemory: (proposalId) => { shell.rejectMemory(proposalId); focusInput.forceActiveFocus() }
            onApproveMission: (missionId, token) => { shell.approveMission(missionId, token); focusInput.forceActiveFocus() }
            onCancelMission: (missionId) => { shell.cancelMission(missionId); focusInput.forceActiveFocus() }
            pin: (shell.nucleus || {}).pin || null
            preview: !!(shell.nucleus || {}).preview
            hasFocus: !!root.focus
            approvals: root.counts.approval_required || 0
            running: root.counts.running || 0
            attention: (root.counts.interrupted || 0) + (root.state.unreadable_task_count || 0)
            modeText: root.answering ? "ANSWERING" :
                      root.state.nucleus_mode === "attention" ? "ATTENTION" :
                      root.state.nucleus_mode === "continuity_unknown" ? "CONTINUITY UNCONFIRMED" : "IDLE"
            modeColor: root.state.nucleus_mode === "attention" ? Theme.attention : Theme.muted
            cpu: root.sys.available ? root.sys.cpu : -1
            memory: root.sys.available ? root.sys.memory : -1
            aiOnline: !!root.route.reachable
            aiWord: root.route.reachable ? "ONLINE" : root.route.checking ? "CHECKING" : "OFFLINE"
            rich: !root.lite
        }
        Loader {
            x: -centre.x; y: -centre.y; width: root.width; height: root.height
            active: root.gpuSmoke && !root.calm && !root.pageOpen && !root.answering
            source: "home/Smoke.qml"
            onLoaded: {
                item.front = true
                item.time = Qt.binding(() => nucleus.time)
                item.center = Qt.binding(() => root.coreCentre)
                item.radius = Qt.binding(() => root.coreRadius)
            }
        }
        Item {
            id: pages
            anchors.fill: parent
            anchors.topMargin: 10
        Column {
            visible: root.sharedDisplay && (root.notesOpen || root.missionsOpen)
            anchors.centerIn: parent; spacing: 12
            Glyph { anchors.horizontalCenter: parent.horizontalCenter; width: 34; height: 34; kind: "brain"; stroke: Theme.attention }
            Text { anchors.horizontalCenter: parent.horizontalCenter; text: "Private — a second screen is connected"; color: root.pale; font.pixelSize: 18 }
            Text { anchors.horizontalCenter: parent.horizontalCenter; text: "Your memory and missions stay hidden until you confirm the screens are yours."
                   color: root.muted; font.pixelSize: 12 }
        }
        SettingsPage {
            id: settingsPage
            // Fades/slides instead of popping; hidden (and idle) once fully faded.
            opacity: (root.settingsOpen) ? 1 : 0
            visible: (root.settingsOpen) || opacity > 0.01
            Behavior on opacity { NumberAnimation { duration: 240; easing.type: Easing.OutCubic } }
            transform: Translate { x: (root.settingsOpen) ? 0 : 0; y: (root.settingsOpen) ? 0 : 16
                Behavior on x { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } }
                Behavior on y { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } } }
            anchors.fill: parent
            anchors.margins: 10
        }
        Atlas {
            id: atlasPage
            // Fades/slides instead of popping; hidden (and idle) once fully faded.
            opacity: (root.atlasOpen) ? 1 : 0
            visible: (root.atlasOpen) || opacity > 0.01
            Behavior on opacity { NumberAnimation { duration: 240; easing.type: Easing.OutCubic } }
            transform: Translate { x: (root.atlasOpen) ? 0 : 0; y: (root.atlasOpen) ? 0 : 16
                Behavior on x { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } }
                Behavior on y { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } } }
            anchors.fill: parent
            anchors.margins: 10
            info: shell.atlas || ({ status: "off" })
            aircraftJson: shell.atlasAircraft
            mapJson: shell.atlasMap
            worldJson: shell.atlasWorld
            landJson: shell.worldLand
            dotsJson: shell.earthDots
            onAreaChanged: (lat, lon) => shell.setAtlasArea(lat, lon)
            onVisibleChanged: shell.setAtlasVisible(visible)
            Component.onCompleted: shell.setAtlasVisible(visible)
            onFocusFlight: (callsign, hexId) => shell.focusFlight(callsign, hexId)
        }
        InstallPage {
            id: installPage
            opacity: root.installOpen ? 1 : 0
            visible: root.installOpen || opacity > 0.01
            Behavior on opacity { NumberAnimation { duration: 240; easing.type: Easing.OutCubic } }
            anchors.fill: parent
            anchors.margins: 10
        }
        DeveloperPage {
            id: devPage
            opacity: root.devOpen ? 1 : 0
            visible: root.devOpen || opacity > 0.01
            Behavior on opacity { NumberAnimation { duration: 240; easing.type: Easing.OutCubic } }
            anchors.fill: parent
            anchors.margins: 10
        }
        MemoryPage {
            id: memoryPage
            // Fades/slides instead of popping; hidden (and idle) once fully faded.
            opacity: (root.notesOpen && !root.sharedDisplay) ? 1 : 0
            visible: (root.notesOpen && !root.sharedDisplay) || opacity > 0.01
            Behavior on opacity { NumberAnimation { duration: 240; easing.type: Easing.OutCubic } }
            transform: Translate { x: (root.notesOpen && !root.sharedDisplay) ? 0 : 0; y: (root.notesOpen && !root.sharedDisplay) ? 0 : 16
                Behavior on x { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } }
                Behavior on y { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } } }
            anchors.fill: parent
            anchors.margins: 10
            onSuggest: text => root.suggestAsk(text)
        }
        Item {
            id: missionsPage
            // Fades/slides instead of popping; hidden (and idle) once fully faded.
            opacity: (root.missionsOpen && !root.sharedDisplay) ? 1 : 0
            visible: (root.missionsOpen && !root.sharedDisplay) || opacity > 0.01
            Behavior on opacity { NumberAnimation { duration: 240; easing.type: Easing.OutCubic } }
            transform: Translate { x: (root.missionsOpen && !root.sharedDisplay) ? 0 : 0; y: (root.missionsOpen && !root.sharedDisplay) ? 0 : 16
                Behavior on x { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } }
                Behavior on y { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } } }
            anchors.fill: parent
            anchors.margins: 10
            MissionsPage { anchors.fill: parent; onSuggest: text => root.suggestAsk(text) }
        }
        }
    }

    // ------------------------------------------------------------ command dock (V7)
    Item {
        id: dock
        // Never under the footer counts or the clock (dev.9: overlapped at 1280 px).
        width: Math.min(root.width - 2 * (Math.max(counts.width, clockRow.width) + 48), 760)
        height: 58
        x: (root.width - width) / 2
        y: root.height - height - 22
        Chamfer { anchors.fill: parent; cut: 12; fill: Theme.panel; fillOpacity: 0.85; stroke: Theme.line; brackets: true }
        component DockIcon: Button {
            id: di
            property string glyph: "core"
            property string caption: ""
            property color tint: Theme.accent
            width: 38; height: 38
            Accessible.name: caption
            ToolTip.visible: hovered; ToolTip.text: caption
            transform: Translate { y: di.hovered || di.activeFocus ? -3 : 0
                                   Behavior on y { NumberAnimation { duration: 150; easing.type: Easing.OutCubic } } }
            scale: di.pressed ? 0.94 : 1
            Behavior on scale { NumberAnimation { duration: 90 } }
            contentItem: Item { Glyph { anchors.centerIn: parent; width: 18; height: 18; kind: di.glyph; stroke: di.tint } }
            background: Item {
                Chamfer { anchors.fill: parent; cut: 6; fill: Theme.raised; stroke: Theme.line }
                Chamfer { anchors.fill: parent; cut: 6; fill: Theme.hover; stroke: di.activeFocus ? Theme.text : Theme.accent
                          strokeWidth: di.activeFocus ? 2 : 1
                          opacity: di.hovered || di.activeFocus ? 1 : 0
                          Behavior on opacity { NumberAnimation { duration: 150 } } }
                Rectangle { anchors.horizontalCenter: parent.horizontalCenter; anchors.top: parent.bottom; anchors.topMargin: 4
                            width: parent.width * 0.6; height: 2; radius: 1; color: di.tint
                            opacity: di.hovered || di.activeFocus ? 0.9 : 0
                            Behavior on opacity { NumberAnimation { duration: 150 } } }
            }
        }
        Row {
            id: dockIcons
            x: 10; anchors.verticalCenter: parent.verticalCenter; spacing: 8
            DockIcon { glyph: "files"; caption: "Files"; onClicked: shell.launch("files") }
            DockIcon { glyph: "apps"; caption: "Apps"; onClicked: shell.launch("apps") }
            DockIcon { glyph: "terminal"; caption: "Terminal"; onClicked: shell.launch("terminal") }
            DockIcon { glyph: "search"; caption: "Search this computer (Ctrl+K)"; onClicked: root.openSearch() }
            DockIcon { glyph: "volume"; caption: "Control Centre"; onClicked: root.toggleControl() }
            DockIcon { glyph: "mission"; caption: "Set Focus from the text"; tint: Theme.warm; onClicked: { shell.setFocus(focusInput.text); focusInput.text = "" } }
        }
        TextField {
            id: focusInput
            x: dockIcons.x + dockIcons.width + 12
            width: parent.width - x - 64; height: 40
            anchors.verticalCenter: parent.verticalCenter
            placeholderText: "Ask APVIS anything…"
            color: root.pale; placeholderTextColor: root.muted
            selectByMouse: true; font.pixelSize: 14
            verticalAlignment: TextInput.AlignVCenter
            focus: true  // typing on Home goes straight to Ask
            Accessible.name: "Ask APVIS"
            background: Item {}
            onAccepted: { shell.askQuestion(text); text = "" }
            Keys.onEscapePressed: shell.closeAnswer()
        }
        Button {
            id: send
            anchors.right: parent.right; anchors.rightMargin: 8; anchors.verticalCenter: parent.verticalCenter
            width: 44; height: 40
            Accessible.name: "Ask"
            onClicked: { shell.askQuestion(focusInput.text); focusInput.text = "" }
            contentItem: Text { text: "›"; color: Theme.bgBottom; font.pixelSize: 26; font.bold: true
                                horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter }
            background: Chamfer { cut: 6; fill: send.hovered || send.activeFocus ? Theme.text : Theme.accent; fillOpacity: 1
                                  stroke: send.activeFocus ? Theme.text : Theme.accent }
        }
    }

    // Footer rails: real counts on the left, clock and state on the right (V7).
    Row {
        id: counts
        x: 24; anchors.verticalCenter: dock.verticalCenter; spacing: 18
        component Count: Row {
            property string glyph: ""
            property string k: ""
            property int n: 0
            spacing: 6
            Glyph { width: 12; height: 12; kind: parent.glyph; stroke: Theme.accent; anchors.verticalCenter: parent.verticalCenter }
            Text { text: parent.k + "  " + parent.n; color: Theme.muted; font.family: "monospace"; font.pixelSize: 10; font.letterSpacing: 1; anchors.verticalCenter: parent.verticalCenter }
        }
        Count { glyph: "wifi"; k: "LINKS"; n: root.linkCount }
        Count { glyph: "device"; k: "NODES"; n: root.nodeCount }
        Count { glyph: "activity"; k: "CHANNELS"; n: root.channelCount }
    }
    Row {
        id: clockRow
        anchors.right: parent.right; anchors.rightMargin: 24; anchors.verticalCenter: dock.verticalCenter; spacing: 10
        Text { text: Qt.formatDateTime(root.nowTick, "HH:mm:ss"); color: Theme.text; font.family: "monospace"; font.pixelSize: 13; anchors.verticalCenter: parent.verticalCenter }
        Rectangle { width: 7; height: 7; radius: 3.5; color: root.modeWord === "ATTENTION" ? Theme.attention : Theme.accent; anchors.verticalCenter: parent.verticalCenter }
        Text { text: root.modeWord === "STANDBY" ? "READY" : root.modeWord; color: root.modeWord === "ATTENTION" ? Theme.attention : Theme.accent
               font.family: "monospace"; font.pixelSize: 11; font.letterSpacing: 1.2; anchors.verticalCenter: parent.verticalCenter }
    }
    Text {
        visible: shell.actionError.length > 0
        anchors.horizontalCenter: dock.horizontalCenter; y: dock.y - 18
        text: shell.actionError; color: Theme.attention; font.pixelSize: 11
    }

    // ------------------------------------------------------------ power menu (top right)
    property bool powerMenuOpen: previewPage === "power"
    Shortcut { sequences: [StandardKey.Cancel]; enabled: root.powerMenuOpen; onActivated: root.powerMenuOpen = false }
    MouseArea { anchors.fill: parent; visible: root.powerMenuOpen; onClicked: root.powerMenuOpen = false }
    Item {
        id: powerMenu
        visible: root.powerMenuOpen || opacity > 0.01
        opacity: root.powerMenuOpen ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }
        transform: Translate { y: root.powerMenuOpen ? 0 : -8; Behavior on y { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } } }
        width: powerMenuRow.width + 28; height: powerMenuCol.height + 28
        x: root.width - width - 14; y: topBar.height - 4
        MouseArea { anchors.fill: parent }
        Chamfer { anchors.fill: parent; cut: 12; fill: Theme.raised; fillOpacity: 0.97; fill2: Theme.bgBottom; fill2Opacity: 0.97
                  stroke: Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.6); brackets: true; edgeGlow: true }
        Column {
            id: powerMenuCol
            x: 14; y: 14; spacing: 10
            SectionLabel { width: powerMenuRow.width; text: "POWER" }
            PowerButtons { id: powerMenuRow; buttonWidth: 112 }
            Text { text: (shell.control || {}).message || "Press a button twice to confirm."; color: Theme.muted; font.pixelSize: 11 }
        }
    }

    // ------------------------------------------------------------ Control Centre
    // Sound, Wi-Fi and Do not disturb with the real state; every change is read back.
    property bool controlOpen: previewPage === "control"
    function toggleControl() {
        controlOpen = !controlOpen
        if (controlOpen) { shell.refreshControl(); controlFirst.forceActiveFocus() } else focusInput.forceActiveFocus()
    }
    Shortcut { sequences: [StandardKey.Cancel]; enabled: root.controlOpen && !root.keysOpen; onActivated: root.toggleControl() }
    readonly property var ctl: shell.control || ({})
    readonly property var ctlSound: (ctl.state || {}).sound || ({})
    // The sound state arrives after the panel opens: move focus to the slider then.
    onCtlSoundChanged: if (controlOpen && ctlSound.available && dndButton.activeFocus) volSlider.forceActiveFocus()
    readonly property var ctlWifi: (ctl.state || {}).wifi || ({})
    Timer { interval: 5000; repeat: true; running: root.controlOpen; onTriggered: shell.refreshControl() }
    MouseArea { anchors.fill: parent; visible: root.controlOpen; onClicked: root.controlOpen = false }
    Item {
        id: controlPanel
        // Fades/slides instead of popping; hidden (and idle) once fully faded.
        opacity: (root.controlOpen) ? 1 : 0
        visible: (root.controlOpen) || opacity > 0.01
        Behavior on opacity { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
        transform: Translate { x: (root.controlOpen) ? 0 : 0; y: (root.controlOpen) ? 0 : 10
            Behavior on x { NumberAnimation { duration: 240; easing.type: Easing.OutCubic } }
            Behavior on y { NumberAnimation { duration: 240; easing.type: Easing.OutCubic } } }
        scale: (root.controlOpen) ? 1 : 0.97
        Behavior on scale { NumberAnimation { duration: 240; easing.type: Easing.OutCubic } }
        width: 360; height: controlCol.height + 32
        x: Math.min(root.width - width - 18, dock.x + dock.width - width); y: dock.y - height - 12
        MouseArea { anchors.fill: parent }
        Chamfer { anchors.fill: parent; cut: 12; fill: Theme.raised; fillOpacity: 0.97; fill2: Theme.bgBottom; fill2Opacity: 0.97
                  stroke: Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.6); brackets: true; edgeGlow: true }
        // Keyboard entry point (the slider when sound exists, else the first button).
        Item { id: controlFirst; focus: false
               onActiveFocusChanged: if (activeFocus) (volSlider.visible ? volSlider : wifiButton.visible ? wifiButton : dndButton).forceActiveFocus() }
        component CtlRow: Item {
            property string glyph: ""
            property string label: ""
            property string value: ""
            width: parent.width; height: 26
            Glyph { width: 16; height: 16; kind: parent.glyph; stroke: Theme.accent; anchors.verticalCenter: parent.verticalCenter }
            Text { x: 26; text: parent.label; color: Theme.text; font.family: "monospace"; font.pixelSize: 11; font.letterSpacing: 1.2; anchors.verticalCenter: parent.verticalCenter }
            Text { anchors.right: parent.right; text: parent.value; color: Theme.muted; font.pixelSize: 12; anchors.verticalCenter: parent.verticalCenter
                   width: parent.width - 130; horizontalAlignment: Text.AlignRight; elide: Text.ElideRight }
        }
        Column {
            id: controlCol
            x: 16; y: 16; width: parent.width - 32; spacing: 10
            SectionLabel { text: "CONTROL CENTRE" }
            CtlRow { glyph: "volume"; label: "SOUND"
                     value: !root.ctlSound.available ? (root.ctlSound.detail || "Checking…") : root.ctlSound.muted ? "Muted" : root.ctlSound.volume + "%" }
            Item {
                visible: !!root.ctlSound.available
                width: parent.width; height: 42
                Slider {
                    id: volSlider
                    anchors.verticalCenter: parent.verticalCenter
                    width: parent.width - 100; from: 0; to: 100; stepSize: 1
                    value: root.ctlSound.volume || 0
                    Accessible.name: "Volume"
                    onMoved: volDebounce.restart()
                    background: Item {
                        x: volSlider.leftPadding; y: volSlider.topPadding + volSlider.availableHeight / 2 - 2
                        width: volSlider.availableWidth; height: 4
                        Rectangle { anchors.fill: parent; radius: 2; color: Theme.raised; border.color: Theme.line }
                        Rectangle { width: volSlider.visualPosition * parent.width; height: parent.height; radius: 2; color: Theme.accent }
                    }
                    handle: Rectangle {
                        x: volSlider.leftPadding + volSlider.visualPosition * (volSlider.availableWidth - width)
                        y: volSlider.topPadding + volSlider.availableHeight / 2 - height / 2
                        width: 16; height: 16; radius: 8; color: Theme.text
                        border.width: volSlider.activeFocus ? 3 : 1; border.color: Theme.accent
                    }
                    Timer { id: volDebounce; interval: 180; onTriggered: shell.setVolume(Math.round(volSlider.value)) }
                }
                HudButton { anchors.right: parent.right; width: 90; caption: root.ctlSound.muted ? "Unmute" : "Mute"; onClicked: shell.setMuted(!root.ctlSound.muted) }
            }
            CtlRow { glyph: "wifi"; label: "WI-FI"; visible: !(root.ctlWifi.available && root.ctlWifi.hasWifi)
                     value: !root.ctlWifi.available ? (root.ctlWifi.detail || "Checking…") : "No Wi-Fi adapter" }
            HudToggle {
                id: wifiButton
                visible: !!root.ctlWifi.available && !!root.ctlWifi.hasWifi
                width: parent.width; on: !!root.ctlWifi.on; caption: "Wi-Fi"
                detail: !root.ctlWifi.on ? "Off" : (root.ctlWifi.network || "On · not connected")
                onClicked: shell.setWifi(!root.ctlWifi.on)
            }
            CtlRow { glyph: "wired"; label: "WIRED"; visible: !!root.ctlWifi.available
                     value: root.ctlWifi.wired || "Not connected" }
            HudToggle { id: dndButton; width: parent.width; on: !!(shell.settings || {}).dnd; caption: "Do not disturb"
                        detail: "Hides notifications. Approvals always get through."
                        onClicked: shell.setDoNotDisturb(!(shell.settings || {}).dnd) }
            Text {
                width: parent.width; wrapMode: Text.WordWrap; font.pixelSize: 11
                visible: text.length > 0
                text: root.ctl.message || ""
                color: root.ctl.ok === false ? Theme.attention : Theme.accent
            }
            Text { text: "POWER"; color: Theme.muted; font.family: "monospace"; font.pixelSize: 10; font.letterSpacing: 1.5; topPadding: 4 }
            PowerButtons { buttonWidth: (controlCol.width - 18) / 4 }
            Row {
                spacing: 8
                HudButton { width: 100; glyph: "volume"; caption: "Sound"; onClicked: shell.launch("sound") }
                HudButton { width: 100; glyph: "wifi"; caption: "Network"; onClicked: shell.launch("network") }
                HudButton { width: 100; glyph: "screen"; caption: "Displays"; onClicked: shell.launch("displays") }
            }
        }
    }

    // Trying from the USB: say so, and offer the installer.
    Item {
        visible: !!(shell.installer || {}).live && !root.pageOpen && !root.sharedDisplay
        width: tryRow.width + 28; height: 40
        x: (root.width - width) / 2; y: topBar.height + 6
        Chamfer { anchors.fill: parent; cut: 8; fill: Theme.panel; fillOpacity: 0.92; stroke: Theme.line }
        Row {
            id: tryRow
            anchors.centerIn: parent; spacing: 12
            Glyph { width: 16; height: 16; kind: "device"; stroke: Theme.accent; anchors.verticalCenter: parent.verticalCenter }
            Text { text: "You're trying APVIS OS from the USB — nothing is saved to this computer"; color: Theme.text; font.pixelSize: 12
                   anchors.verticalCenter: parent.verticalCenter }
            HudButton { width: 110; implicitHeight: 30; caption: "Install…"; tone: "primary"; anchors.verticalCenter: parent.verticalCenter
                        onClicked: root.openPage("install") }
        }
    }

    // Second-screen privacy banner.
    Item {
        visible: root.sharedDisplay
        width: bannerRow.width + 28; height: 40
        x: (root.width - width) / 2; y: topBar.height + 6
        Chamfer { anchors.fill: parent; cut: 8; fill: Theme.panel; fillOpacity: 0.95; stroke: Theme.attention }
        Row {
            id: bannerRow
            anchors.centerIn: parent; spacing: 12
            Glyph { width: 16; height: 16; kind: "device"; stroke: Theme.attention; anchors.verticalCenter: parent.verticalCenter }
            Text { text: "Second screen connected — private details hidden"; color: root.pale; font.pixelSize: 12; anchors.verticalCenter: parent.verticalCenter }
            HudButton { width: 150; caption: "They're my screens"; onClicked: root.trustedScreens = true; anchors.verticalCenter: parent.verticalCenter }
        }
    }

    // Terminal from Home with keys compact keyboards can press (Win+Enter is
    // awkward on Rii mini keyboards): Ctrl+Alt+T or Ctrl+Alt+Del.
    Shortcut { sequences: ["Ctrl+Alt+T", "Ctrl+Alt+Del", "Ctrl+Alt+Backspace"]; onActivated: shell.launch("terminal") }

    // ------------------------------------------------------------ shortcuts (F1)
    // Mirrors /etc/apvis-os/labwc/rc.xml and the Home shortcuts; keep them in step.
    property bool keysOpen: previewPage === "keys"
    Shortcut { sequences: ["F1"]; onActivated: root.keysOpen = !root.keysOpen }
    Shortcut { sequences: [StandardKey.Cancel]; enabled: root.keysOpen; onActivated: root.keysOpen = false }
    Rectangle {
        anchors.fill: parent; color: Qt.rgba(0, 0, 0, 0.5)
        opacity: root.keysOpen ? 1 : 0; visible: root.keysOpen || opacity > 0.01
        Behavior on opacity { NumberAnimation { duration: 180 } }
        MouseArea { anchors.fill: parent; onClicked: root.keysOpen = false }
    }
    Item {
        opacity: root.keysOpen ? 1 : 0
        visible: root.keysOpen || opacity > 0.01
        Behavior on opacity { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
        scale: root.keysOpen ? 1 : 0.97
        Behavior on scale { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }
        width: Math.min(620, root.width - 80); height: keysCol.height + 40
        x: (root.width - width) / 2; y: (root.height - height) / 2
        Chamfer { anchors.fill: parent; cut: 14; fill: Theme.raised; fillOpacity: 0.97; fill2: Theme.bgBottom; fill2Opacity: 0.97
                  stroke: Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.6); brackets: true; edgeGlow: true }
        Column {
            id: keysCol
            x: 24; y: 20; width: parent.width - 48; spacing: 7
            Text { text: "KEYBOARD SHORTCUTS"; color: Theme.text; font.family: "monospace"; font.pixelSize: 13; font.letterSpacing: 2; font.bold: true; bottomPadding: 6 }
            Repeater {
                model: [
                    ["Ctrl + K", "Search this computer"], ["F1", "This list"], ["Esc", "Close a panel, page or answer"],
                    ["Type on Home", "Ask APVIS"], ["Win + P", "Bring APVIS Home back"],
                    ["Win + Space", "All apps"], ["Win + E", "Files"], ["Win + Enter  or  Ctrl + Alt + T / Del", "Terminal"],
                    ["Alt + Tab", "Next window"], ["Alt + F4", "Close window"],
                    ["Win + ← / →", "Previous / next workspace"], ["Win + Shift + ← / →", "Move window to that workspace"]
                ]
                delegate: Item {
                    required property var modelData
                    width: keysCol.width; height: 24
                    Rectangle { width: keyText.width + 16; height: 22; radius: 3; color: Theme.raised; border.color: Theme.line
                        Text { id: keyText; anchors.centerIn: parent; text: modelData[0]; color: Theme.accent; font.family: "monospace"; font.pixelSize: 11 } }
                    Text { x: 200; anchors.verticalCenter: parent.verticalCenter; text: modelData[1]; color: root.pale; font.pixelSize: 13 }
                }
            }
        }
    }

    // ------------------------------------------------------------ search (Ctrl+K)
    // One local search: apps, pages, settings, notes, missions and home files.
    // Nothing leaves this computer; only listed results can be opened.
    property bool searchOpen: false
    function openSearch() { searchOpen = true; searchField.text = ""; shell.search(""); searchField.forceActiveFocus() }
    function closeSearch() { searchOpen = false; focusInput.forceActiveFocus() }
    function openHit(i) {
        const r = (shell.searchResults || [])[i]
        if (!r) return
        closeSearch()
        shell.openResult(r.kind, r.key)
    }
    function hitGlyph(r) {
        if (r.kind === "page") return r.key === "home" ? "home" : r.key === "missions" ? "mission" : r.key
        return { app: "apps", setting: "settings", note: "notes", mission: "mission", file: "files", folder: "files" }[r.kind] || "search"
    }
    Shortcut { sequences: ["Ctrl+K", "Ctrl+F"]; onActivated: root.searchOpen ? root.closeSearch() : root.openSearch() }
    Rectangle {
        anchors.fill: parent; color: Qt.rgba(0, 0, 0, 0.5)
        opacity: root.searchOpen ? 1 : 0; visible: root.searchOpen || opacity > 0.01
        Behavior on opacity { NumberAnimation { duration: 180 } }
        MouseArea { anchors.fill: parent; onClicked: root.closeSearch() }
    }
    Item {
        id: searchPanel
        opacity: root.searchOpen ? 1 : 0
        visible: root.searchOpen || opacity > 0.01
        Behavior on opacity { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
        scale: root.searchOpen ? 1 : 0.97
        Behavior on scale { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }
        width: Math.min(660, root.width - 80)
        height: 62 + (hitList.count ? hitList.height + 10 : searchField.text.length ? 40 : 0) + 26
        x: (root.width - width) / 2; y: Math.max(70, root.height * 0.14)
        MouseArea { anchors.fill: parent }  // clicks inside do not close it
        Chamfer { anchors.fill: parent; cut: 14; fill: Theme.raised; fillOpacity: 0.97; fill2: Theme.bgBottom; fill2Opacity: 0.97
                  stroke: Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.6); brackets: true; edgeGlow: true }
        Glyph { x: 20; y: 21; width: 20; height: 20; kind: "search"; stroke: Theme.accent }
        TextField {
            id: searchField
            x: 50; y: 9; width: parent.width - 66; height: 44
            placeholderText: "Search apps, files, notes, settings…"
            color: root.pale; placeholderTextColor: root.muted
            font.pixelSize: 16; selectByMouse: true
            background: Item {}
            Accessible.name: "Search this computer"
            onTextChanged: { hitList.currentIndex = 0; searchDebounce.restart() }
            Keys.onDownPressed: hitList.incrementCurrentIndex()
            Keys.onUpPressed: hitList.decrementCurrentIndex()
            Keys.onEscapePressed: root.closeSearch()
            onAccepted: root.openHit(hitList.currentIndex)
        }
        Timer { id: searchDebounce; interval: 120; onTriggered: shell.search(searchField.text) }
        Rectangle { x: 14; y: 58; width: parent.width - 28; height: 1; color: Theme.line }
        ListView {
            id: hitList
            x: 10; y: 66; width: parent.width - 20
            height: Math.min(count, 8) * 46
            clip: true; currentIndex: 0
            model: shell.searchResults || []
            delegate: Item {
                id: hit
                required property var modelData
                required property int index
                readonly property bool current: ListView.isCurrentItem
                width: ListView.view.width; height: 46
                Rectangle { anchors.fill: parent; anchors.margins: 2; radius: 3
                            color: hit.current ? Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.14) : hitMouse.containsMouse ? Theme.hover : "transparent"
                            border.width: hit.current ? 1 : 0; border.color: Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.5) }
                Glyph { x: 14; anchors.verticalCenter: parent.verticalCenter; width: 18; height: 18; kind: root.hitGlyph(hit.modelData); stroke: hit.current ? Theme.accent : Theme.muted }
                Column {
                    x: 46; anchors.verticalCenter: parent.verticalCenter; width: parent.width - 46 - 90; spacing: 2
                    Text { width: parent.width; text: hit.modelData.title; color: Theme.text; font.pixelSize: 14; elide: Text.ElideRight }
                    Text { width: parent.width; text: hit.modelData.detail; color: Theme.muted; font.pixelSize: 11; elide: Text.ElideMiddle }
                }
                Text { anchors.right: parent.right; anchors.rightMargin: 14; anchors.verticalCenter: parent.verticalCenter
                       text: hit.modelData.kind.toUpperCase(); color: hit.current ? Theme.accent : Theme.muted
                       font.family: "monospace"; font.pixelSize: 9; font.letterSpacing: 1.2 }
                MouseArea { id: hitMouse; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: root.openHit(hit.index) }
                Accessible.role: Accessible.ListItem
                Accessible.name: hit.modelData.title + ", " + hit.modelData.kind
            }
        }
        Text {
            visible: searchField.text.length > 0 && hitList.count === 0
            x: 50; y: 70; text: "Nothing on this computer matches."
            color: Theme.muted; font.pixelSize: 13
        }
        Text {
            anchors.bottom: parent.bottom; anchors.bottomMargin: 8; x: 20
            text: "↑ ↓ choose   ·   Enter open   ·   Esc close   ·   F1 shortcuts   ·   this computer only"
            color: Theme.muted; font.family: "monospace"; font.pixelSize: 9; font.letterSpacing: 0.8
        }
    }
}
