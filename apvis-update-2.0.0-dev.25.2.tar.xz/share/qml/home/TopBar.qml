import QtQuick
import QtQuick.Controls
import "../theme"

// The menu bar (owner concept): APVIS mark and menus on the left, real status
// on the right (network, volume, battery when there is one, date and time).
// Menu choices are emitted as action keys; Home carries them out.
Item {
    id: bar
    property string openMenu: ""
    property date now: new Date()
    property bool powerOpen: false
    signal action(string key)
    height: 40

    readonly property var sys: shell.system || ({})
    readonly property var menus: ({
        "System": [["About this computer", "page:devices", ""], ["System monitor", "page:system", ""], ["Control Centre", "control", ""],
                   ["-"], ["Displays", "launch:displays", ""], ["Sound", "launch:sound", ""], ["Network", "launch:network", ""],
                   ["-"], ["Keyboard shortcuts", "keys", "F1"], ["Lock", "lock", "Win+L"], ["Sleep, restart or shut down…", "power", ""]],
        "Apps": [["All apps", "launch:apps", "Win+Space"], ["APVIS Browser", "launch:browser", "Win+B"], ["Files", "launch:files", "Win+E"], ["Terminal", "launch:terminal", "Ctrl+Alt+T"],
                 ["Text editor", "launch:editor", ""], ["-"], ["Search this computer", "search", "Ctrl+K"]],
        "APVIS": [["Ask APVIS", "ask", ""], ["What was I doing?", "continuity", ""], ["-"], ["Automation", "page:missions", ""],
                  ["Memory", "page:notes", ""], ["Intelligence", "page:atlas", ""], ["-"], ["Check for updates", "updates", ""]]
    })

    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0; color: Qt.rgba(0, 0, 0, 0.85) }
            GradientStop { position: 1; color: Qt.rgba(0, 0, 0, 0.55) }
        }
    }
    Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1; color: Qt.rgba(Theme.line.r, Theme.line.g, Theme.line.b, 0.7) }

    Row {
        id: left
        x: 18; height: parent.height; spacing: 26
        Row {
            spacing: 10; anchors.verticalCenter: parent.verticalCenter
            ApvisMark { width: 20; height: 18; glow: 0.3; anchors.verticalCenter: parent.verticalCenter }
            Text { text: "APVIS OS"; color: Theme.text; font.pixelSize: 14; font.weight: Font.Medium; font.letterSpacing: 0.5
                   anchors.verticalCenter: parent.verticalCenter }
        }
        Repeater {
            model: ["System", "Apps", "APVIS", "Settings"]
            delegate: AbstractButton {
                id: menuTitle
                required property string modelData
                readonly property bool open: bar.openMenu === modelData
                height: 28; width: menuText.implicitWidth + 16; anchors.verticalCenter: parent.verticalCenter
                Accessible.name: modelData + " menu"
                onClicked: {
                    if (modelData === "Settings") { bar.openMenu = ""; bar.action("page:settings"); return }
                    bar.openMenu = open ? "" : modelData
                }
                // Moving across the bar while a menu is open switches menus, like a desktop menu bar.
                onHoveredChanged: if (hovered && bar.openMenu !== "" && modelData !== "Settings") bar.openMenu = modelData
                background: Rectangle { radius: 6; color: menuTitle.open ? Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.14) :
                                                           menuTitle.hovered ? Qt.rgba(1, 1, 1, 0.06) : "transparent"
                                        border.width: menuTitle.visualFocus ? 1.5 : 0; border.color: Theme.text }
                contentItem: Text { id: menuText; text: menuTitle.modelData; horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter
                                    color: menuTitle.open || menuTitle.hovered ? Theme.text : Qt.rgba(Theme.text.r, Theme.text.g, Theme.text.b, 0.72)
                                    font.pixelSize: 14 }
            }
        }
    }

    Row {
        id: right
        anchors.right: parent.right; anchors.rightMargin: 14; height: parent.height; spacing: 18
        // Network: Wi-Fi when joined, wired when plugged in, dim when neither.
        Glyph {
            anchors.verticalCenter: parent.verticalCenter; width: 17; height: 17
            readonly property bool wifi: !!(bar.sys.wifi && bar.sys.wifi.connected)
            kind: wifi ? "wifi" : "wired"
            stroke: wifi || bar.sys.wired ? Theme.text : Theme.muted
            opacity: wifi || bar.sys.wired ? 1 : 0.5
            ToolTip.visible: netMouse.containsMouse
            ToolTip.text: wifi ? "Wi-Fi · " + bar.sys.wifi.ssid : bar.sys.wired ? "Wired network" : "Not connected"
            MouseArea { id: netMouse; anchors.fill: parent; hoverEnabled: true; onClicked: bar.action("control") }
        }
        Item {
            anchors.verticalCenter: parent.verticalCenter
            width: volRow.width; height: 24
            Row {
                id: volRow
                anchors.verticalCenter: parent.verticalCenter; spacing: 6
                Glyph { width: 17; height: 17; kind: "volume"; stroke: bar.sys.muted ? Theme.muted : Theme.text; anchors.verticalCenter: parent.verticalCenter }
                Text { visible: bar.sys.volume !== undefined && bar.sys.volume !== null; anchors.verticalCenter: parent.verticalCenter
                       text: bar.sys.muted ? "Muted" : bar.sys.volume + "%"; color: Theme.text; font.pixelSize: 13 }
            }
            MouseArea { anchors.fill: parent; onClicked: bar.action("control") }
        }
        Row {
            visible: !!bar.sys.battery
            anchors.verticalCenter: parent.verticalCenter; spacing: 6
            Glyph { width: 19; height: 19; kind: "battery"; stroke: bar.sys.battery && bar.sys.battery.percent < 15 ? Theme.attention : Theme.text
                    anchors.verticalCenter: parent.verticalCenter }
            Text { anchors.verticalCenter: parent.verticalCenter; color: Theme.text; font.pixelSize: 13
                   text: bar.sys.battery ? bar.sys.battery.percent + "%" + (bar.sys.battery.plugged ? " ⚡" : "") : "" }
        }
        Text { anchors.verticalCenter: parent.verticalCenter; text: Qt.formatDateTime(bar.now, "ddd d MMM"); color: Theme.text; font.pixelSize: 14 }
        Text { anchors.verticalCenter: parent.verticalCenter; text: Qt.formatDateTime(bar.now, "HH:mm"); color: Theme.text; font.pixelSize: 14; font.weight: Font.Medium }
        AbstractButton {
            id: powerButton
            width: 30; height: 28; anchors.verticalCenter: parent.verticalCenter
            Accessible.name: "Power menu"
            onClicked: bar.action("power")
            background: Rectangle { radius: 6; color: bar.powerOpen ? Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.16) :
                                                       powerButton.hovered ? Qt.rgba(1, 1, 1, 0.07) : "transparent"
                                    border.width: powerButton.visualFocus ? 1.5 : 0; border.color: Theme.text }
            contentItem: Item { Glyph { anchors.centerIn: parent; width: 16; height: 16; kind: "power"; stroke: bar.powerOpen ? Theme.accent : Theme.text } }
        }
    }

    // ---- the open menu
    Item {
        id: dropdown
        visible: bar.openMenu !== "" && opacity > 0.01
        opacity: bar.openMenu !== "" ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: 140 } }
        readonly property Item anchorItem: {
            for (let i = 0; i < left.children.length; ++i) {
                const ch = left.children[i]
                if (ch.modelData === bar.openMenu) return ch
            }
            return null
        }
        x: left.x + (anchorItem ? anchorItem.x : 0) - 6
        y: bar.height + 4
        width: 280; height: menuCol.height + 16
        Chamfer { anchors.fill: parent; cut: 12; fill: Theme.panel; fillOpacity: 0.97; fill2: Theme.bgBottom; fill2Opacity: 0.97
                  stroke: Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.35); edgeGlow: true }
        Column {
            id: menuCol
            x: 8; y: 8; width: parent.width - 16
            Repeater {
                model: bar.openMenu ? bar.menus[bar.openMenu] || [] : []
                delegate: Item {
                    id: entry
                    required property var modelData
                    readonly property bool separator: modelData[0] === "-"
                    width: menuCol.width; height: separator ? 9 : 34
                    Rectangle { visible: entry.separator; anchors.centerIn: parent; width: parent.width - 16; height: 1; color: Theme.line }
                    Rectangle {
                        visible: !entry.separator
                        anchors.fill: parent; radius: 6
                        color: entryMouse.containsMouse ? Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.14) : "transparent"
                        Text { x: 12; anchors.verticalCenter: parent.verticalCenter; text: entry.modelData[0]; color: Theme.text; font.pixelSize: 13 }
                        Text { anchors.right: parent.right; anchors.rightMargin: 12; anchors.verticalCenter: parent.verticalCenter
                               text: entry.modelData[2] || ""; color: Theme.muted; font.pixelSize: 11; font.family: "monospace" }
                        MouseArea { id: entryMouse; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                    onClicked: { const key = entry.modelData[1]; bar.openMenu = ""; bar.action(key) } }
                    }
                }
            }
        }
    }
}
