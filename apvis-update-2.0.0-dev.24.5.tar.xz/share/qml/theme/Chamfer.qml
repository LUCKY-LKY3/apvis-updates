import QtQuick

// A HUD-style box: two cut corners, optional accent brackets. Used as the
// background of buttons, dock tiles, panels and the Ask bar. Paints once per
// size or colour change, so it costs nothing while the screen is still.
Canvas {
    id: box
    property color fill: Theme.raised
    property real fillOpacity: 0.8
    // Optional vertical gradient: fill at the top to fill2 at the bottom.
    property color fill2: fill
    property real fill2Opacity: -1
    property color stroke: Theme.line
    property real strokeWidth: 1
    property real cut: 8
    property bool brackets: false
    property color bracketColour: Theme.accent
    // A lit top edge (bright in the middle, fading to the corners).
    property bool edgeGlow: false
    property color glowColour: Theme.accent
    onFillChanged: requestPaint()
    onFill2Changed: requestPaint()
    onFillOpacityChanged: requestPaint()
    onStrokeChanged: requestPaint()
    onStrokeWidthChanged: requestPaint()
    onBracketsChanged: requestPaint()
    onBracketColourChanged: requestPaint()
    onEdgeGlowChanged: requestPaint()
    onGlowColourChanged: requestPaint()
    Connections { target: Theme; function onStyleChanged() { box.requestPaint() } function onAccentNameChanged() { box.requestPaint() } }
    onWidthChanged: requestPaint()
    onHeightChanged: requestPaint()
    Component.onCompleted: requestPaint()
    function rgba(c, a) { return "rgba(" + Math.round(c.r * 255) + "," + Math.round(c.g * 255) + "," + Math.round(c.b * 255) + "," + a + ")" }
    onPaint: {
        const c = getContext("2d"), w = width, h = height, k = Math.min(cut, w / 3, h / 3), o = strokeWidth / 2
        const glass = Theme.glass, rr = Math.min(cut * 0.85, w / 2 - 1, h / 2 - 1)
        c.reset(); c.clearRect(0, 0, w, h)
        function outline() {
            c.beginPath()
            if (glass) {
                c.moveTo(o + rr, o); c.lineTo(w - o - rr, o); c.arcTo(w - o, o, w - o, o + rr, rr)
                c.lineTo(w - o, h - o - rr); c.arcTo(w - o, h - o, w - o - rr, h - o, rr)
                c.lineTo(o + rr, h - o); c.arcTo(o, h - o, o, h - o - rr, rr)
                c.lineTo(o, o + rr); c.arcTo(o, o, o + rr, o, rr)
            } else {
                c.moveTo(o, o); c.lineTo(w - k, o); c.lineTo(w - o, k); c.lineTo(w - o, h - o)
                c.lineTo(k, h - o); c.lineTo(o, h - k)
            }
            c.closePath()
        }
        outline()
        if (fill2Opacity >= 0) {
            const g = c.createLinearGradient(0, 0, 0, h)
            g.addColorStop(0, rgba(fill, fillOpacity)); g.addColorStop(1, rgba(fill2, fill2Opacity))
            c.fillStyle = g
        } else {
            c.fillStyle = rgba(fill, fillOpacity)
        }
        c.fill()
        c.strokeStyle = rgba(stroke, stroke.a); c.lineWidth = strokeWidth; c.stroke()
        if (edgeGlow && w > 40 && glass) {
            // Glass: a faint sheen along the top edge.
            const g = c.createLinearGradient(0, 0, w, 0)
            g.addColorStop(0, rgba(glowColour, 0)); g.addColorStop(0.3, rgba(glowColour, 0.55))
            g.addColorStop(0.7, rgba(glowColour, 0.55)); g.addColorStop(1, rgba(glowColour, 0))
            c.strokeStyle = g; c.lineWidth = 1
            c.beginPath(); c.moveTo(rr + 2, o); c.lineTo(w - rr - 2, o); c.stroke()
            const v = c.createLinearGradient(0, 0, 0, Math.min(46, h))
            v.addColorStop(0, rgba(glowColour, 0.05)); v.addColorStop(1, rgba(glowColour, 0))
            c.save(); outline(); c.clip(); c.fillStyle = v; c.fillRect(0, 0, w, Math.min(46, h)); c.restore()
        } else if (edgeGlow && w > 40) {
            const g = c.createLinearGradient(0, 0, w - k, 0)
            g.addColorStop(0, rgba(glowColour, 0)); g.addColorStop(0.35, rgba(glowColour, 0.9))
            g.addColorStop(0.65, rgba(glowColour, 0.9)); g.addColorStop(1, rgba(glowColour, 0))
            c.strokeStyle = g
            c.globalAlpha = 0.18; c.lineWidth = 5
            c.beginPath(); c.moveTo(k, o + 1); c.lineTo(w - k - 4, o + 1); c.stroke()
            c.globalAlpha = 1; c.lineWidth = 1.2
            c.beginPath(); c.moveTo(k, o); c.lineTo(w - k - 4, o); c.stroke()
            // Light falling from the edge into the panel.
            const v = c.createLinearGradient(0, 0, 0, Math.min(60, h))
            v.addColorStop(0, rgba(glowColour, 0.07)); v.addColorStop(1, rgba(glowColour, 0))
            c.fillStyle = v
            c.beginPath(); c.moveTo(o, o); c.lineTo(w - k, o); c.lineTo(w - o, k); c.lineTo(w - o, Math.min(60, h)); c.lineTo(o, Math.min(60, h)); c.closePath(); c.fill()
        }
        if (brackets && !glass) {
            const b = Math.min(14, w / 4, h / 4)
            c.strokeStyle = rgba(bracketColour, 0.95); c.lineWidth = 1.6
            c.beginPath(); c.moveTo(o, b); c.lineTo(o, o); c.lineTo(b, o); c.stroke()
            c.beginPath(); c.moveTo(w - o, h - b); c.lineTo(w - o, h - o); c.lineTo(w - b, h - o); c.stroke()
        }
    }
}
