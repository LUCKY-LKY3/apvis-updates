import QtQuick

// The APVIS mark as in the owner's concept: a faceted green "A" — two legs
// meeting at the apex and a separate chevron between them — with a soft glow.
// Painted once per size or colour change.
Item {
    id: mark
    property color tint: Theme.accent
    property real glow: 0.6            // 0 = no glow
    implicitWidth: 64
    implicitHeight: 56

    function rgba(c, a, k) {
        k = k === undefined ? 1 : k
        return "rgba(" + Math.round(Math.min(255, c.r * 255 * k)) + "," + Math.round(Math.min(255, c.g * 255 * k)) + "," +
               Math.round(Math.min(255, c.b * 255 * k)) + "," + a + ")"
    }
    onTintChanged: art.requestPaint()
    onGlowChanged: art.requestPaint()

    Canvas {
        id: art
        anchors.fill: parent
        anchors.margins: -Math.max(mark.width, mark.height) * 0.25
        antialiasing: true
        onWidthChanged: requestPaint()
        onHeightChanged: requestPaint()
        Component.onCompleted: requestPaint()
        onPaint: {
            const c = getContext("2d")
            c.reset(); c.clearRect(0, 0, width, height)
            const m = Math.max(mark.width, mark.height) * 0.25
            const w = mark.width, h = mark.height
            const X = u => m + u * w, Y = v => m + v * h
            const T = mark.tint
            function poly(pts, fill) {
                c.beginPath(); c.moveTo(X(pts[0]), Y(pts[1]))
                for (let i = 2; i < pts.length; i += 2) c.lineTo(X(pts[i]), Y(pts[i + 1]))
                c.closePath(); c.fillStyle = fill; c.fill()
            }
            // Glow behind the mark.
            if (mark.glow > 0) {
                const g = c.createRadialGradient(X(0.5), Y(0.6), 0, X(0.5), Y(0.6), Math.max(w, h) * 0.85)
                g.addColorStop(0, mark.rgba(T, 0.35 * mark.glow)); g.addColorStop(0.5, mark.rgba(T, 0.12 * mark.glow)); g.addColorStop(1, mark.rgba(T, 0))
                c.fillStyle = g; c.fillRect(0, 0, width, height)
            }
            // Left leg: bright outer face, shaded inner face, a mid facet.
            poly([0.50, 0.00, 0.00, 1.00, 0.17, 1.00, 0.50, 0.36], mark.rgba(T, 1, 1.12))
            poly([0.50, 0.00, 0.22, 0.62, 0.17, 1.00, 0.00, 1.00], mark.rgba(T, 1, 1.28))
            poly([0.50, 0.00, 0.50, 0.36, 0.30, 0.62], mark.rgba(T, 1, 0.92))
            // Right leg: darker, with lighter ridges.
            poly([0.50, 0.00, 1.00, 1.00, 0.80, 1.00, 0.50, 0.36], mark.rgba(T, 1, 0.78))
            poly([0.50, 0.00, 0.62, 0.30, 0.50, 0.36], mark.rgba(T, 1, 1.05))
            poly([0.62, 0.30, 1.00, 1.00, 0.86, 0.72], mark.rgba(T, 1, 0.95))
            poly([0.50, 0.36, 0.80, 1.00, 0.70, 0.78], mark.rgba(T, 1, 0.62))
            // Chevron between the legs.
            poly([0.26, 0.93, 0.50, 0.70, 0.73, 0.93, 0.50, 0.80], mark.rgba(T, 1, 1.05))
            poly([0.50, 0.70, 0.73, 0.93, 0.50, 0.80], mark.rgba(T, 1, 0.8))
            // Crisp highlight on the apex ridge.
            c.strokeStyle = "rgba(235,255,240,0.55)"; c.lineWidth = Math.max(0.8, w * 0.012)
            c.beginPath(); c.moveTo(X(0.5), Y(0.01)); c.lineTo(X(0.02), Y(0.99)); c.stroke()
        }
    }
    Accessible.role: Accessible.Graphic
    Accessible.name: "APVIS"
}
