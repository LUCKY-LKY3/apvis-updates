import QtQuick
import QtQuick.Controls
import "../theme"

// Memory: what APVIS remembers about the owner, and what waits for review.
// Nothing is kept without a Save; every memory is a plain Markdown file in the
// vault, can be opened in an editor, and "Forget" moves it to the Trash.
Item {
    id: page
    readonly property var inbox: shell.inbox || []
    readonly property var memories: shell.notes || []
    property string kindFilter: ""
    property string textFilter: ""
    readonly property var shown: memories.filter(m =>
        (!kindFilter || m.kind === kindFilter) &&
        (!textFilter || (m.title + " " + (m.excerpt || "") + " " + (m.tags || []).join(" ")).toLowerCase().indexOf(textFilter.toLowerCase()) >= 0))
    readonly property bool wide: width >= 980
    property string armedForget: ""
    signal suggest(string text)
    Timer { id: disarm; interval: 4000; onTriggered: page.armedForget = "" }
    function focusFirst() { filterField.forceActiveFocus() }
    function kindWord(k) { return k === "decision" ? "DECISION" : k === "research" ? "RESEARCH" : "NOTE" }
    function kindColour(k) { return k === "decision" ? Theme.warm : k === "research" ? "#7fb6ff" : Theme.accent }
    function kindCount(k) { return memories.filter(m => m.kind === k).length }

    property real reveal: 1
    onVisibleChanged: if (visible) entry.restart()
    NumberAnimation { id: entry; target: page; property: "reveal"; from: 0; to: 1; duration: 800; easing.type: Easing.OutCubic }

    PageHeader {
        id: header
        width: parent.width
        code: "04"; title: "MEMORY"; reveal: page.reveal
        subtitle: "What APVIS remembers about you. It only keeps what you Save. Each memory is a plain Markdown file in " + shell.vaultPath + "."
        HudButton { width: 170; glyph: "files"; caption: "Open vault folder"; onClicked: shell.openVault() }
    }

    Row {
        id: counts
        anchors.top: header.bottom; anchors.topMargin: 16
        width: parent.width; spacing: 12
        readonly property real tileWidth: (width - 4 * spacing) / 5
        StatTile { width: counts.tileWidth; order: 0; reveal: page.reveal; label: "REMEMBERED"; glyph: "memory"
                   value: String(page.memories.length); live: page.memories.length > 0 }
        StatTile { width: counts.tileWidth; order: 1; reveal: page.reveal; label: "NOTES"; glyph: "notes"
                   value: String(page.kindCount("note")); live: page.kindCount("note") > 0
                   fraction: page.memories.length ? page.kindCount("note") / page.memories.length : 0 }
        StatTile { width: counts.tileWidth; order: 2; reveal: page.reveal; label: "DECISIONS"; glyph: "check"; tint: Theme.warm
                   value: String(page.kindCount("decision")); live: page.kindCount("decision") > 0
                   fraction: page.memories.length ? page.kindCount("decision") / page.memories.length : 0 }
        StatTile { width: counts.tileWidth; order: 3; reveal: page.reveal; label: "RESEARCH"; glyph: "search"; tint: "#7fb6ff"
                   value: String(page.kindCount("research")); live: page.kindCount("research") > 0
                   fraction: page.memories.length ? page.kindCount("research") / page.memories.length : 0 }
        StatTile { width: counts.tileWidth; order: 4; reveal: page.reveal; label: "WAITING FOR REVIEW"; glyph: "ask"; tint: Theme.attention
                   value: String(page.inbox.length); live: page.inbox.length > 0; sub: page.inbox.length ? "review below" : "" }
    }

    // ---- review column
    Flickable {
        id: reviewCol
        anchors.top: counts.bottom; anchors.topMargin: 16
        width: page.wide ? Math.min(420, parent.width * 0.34) : parent.width
        height: page.wide ? parent.height - y : Math.min(300, reviewStack.height)
        visible: page.wide || page.inbox.length > 0
        contentHeight: reviewStack.height
        clip: true; boundsBehavior: Flickable.StopAtBounds
        ScrollBar.vertical: HudScrollBar {}
        Column {
            id: reviewStack
            width: reviewCol.width - 10; spacing: 14
            HudPanel {
                width: parent.width; reveal: page.reveal; order: 2
                title: "WAITING FOR YOUR REVIEW"; glyph: "ask"
                tint: page.inbox.length ? Theme.attention : Theme.accent
                highlighted: page.inbox.length > 0
                meta: page.inbox.length ? page.inbox.length + " NEW" : "CLEAR"
                metaColour: page.inbox.length ? Theme.attention : Theme.muted
                Text { visible: page.inbox.length === 0; width: parent.width; wrapMode: Text.WordWrap; color: Theme.muted; font.pixelSize: 12
                       text: "Nothing waiting. When you ask APVIS to remember something, it appears here first and is only kept if you Save it." }
                Repeater {
                    model: page.inbox
                    delegate: Item {
                        required property var modelData
                        width: parent.width; height: reviewBody.height + 62
                        Chamfer { anchors.fill: parent; cut: 10; fill: Theme.bgBottom; fillOpacity: 0.6; stroke: Qt.rgba(Theme.attention.r, Theme.attention.g, Theme.attention.b, 0.6) }
                        Rectangle { x: 0; y: 10; width: 2.5; height: parent.height - 20; color: Theme.attention }
                        Column {
                            id: reviewBody
                            x: 14; y: 12; width: parent.width - 28; spacing: 4
                            Text { text: page.kindWord(modelData.kind); color: Theme.attention; font.family: "monospace"; font.pixelSize: 10; font.letterSpacing: 2 }
                            Text { width: parent.width; text: modelData.text; color: Theme.text; font.pixelSize: 14; wrapMode: Text.WordWrap }
                            Text { width: parent.width; visible: text.length > 0; color: Theme.muted; font.pixelSize: 11; wrapMode: Text.WordWrap
                                   text: (modelData.reason ? "Why: " + modelData.reason + "   " : "") +
                                         (modelData.similar.length ? "Similar to: " + modelData.similar.join(", ") : "") }
                        }
                        Row {
                            anchors.bottom: parent.bottom; anchors.bottomMargin: 10; x: 14; spacing: 8
                            HudButton { width: 90; implicitHeight: 32; caption: "Save"; glyph: "check"; tone: "primary"; onClicked: shell.acceptMemory(modelData.id) }
                            HudButton { width: 110; implicitHeight: 32; caption: "Don't save"; onClicked: shell.rejectMemory(modelData.id) }
                        }
                    }
                }
            }
            HudPanel {
                visible: page.wide
                width: parent.width; reveal: page.reveal; order: 3
                title: "HOW MEMORY WORKS"; glyph: "brain"
                Repeater {
                    model: [["ask", "Say it", "“remember that …” or “we decided … because …” in the Ask bar."],
                            ["check", "You review it", "It waits above until you press Save. Nothing is kept on its own."],
                            ["notes", "It's a file you own", "Plain Markdown in your vault. Open it, edit it, or Forget it (goes to the Trash)."],
                            ["brain", "Ask uses it", "Relevant memories are given to the local AI when you ask, and nothing leaves this computer."]]
                    delegate: Row {
                        required property var modelData
                        width: parent.width; spacing: 12
                        Rectangle { width: 28; height: 28; radius: 14; color: Theme.bgBottom
                                    border.width: 1; border.color: Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.55)
                                    Glyph { anchors.centerIn: parent; width: 13; height: 13; kind: modelData[0]; stroke: Theme.accent } }
                        Column {
                            width: parent.width - 40; spacing: 2
                            Text { text: modelData[1].toUpperCase(); color: Theme.text; font.family: "monospace"; font.pixelSize: 11; font.letterSpacing: 1.4 }
                            Text { width: parent.width; text: modelData[2]; color: Theme.muted; font.pixelSize: 11; wrapMode: Text.WordWrap }
                        }
                    }
                }
            }
        }
    }

    // ---- remembered
    Item {
        id: memArea
        anchors.top: page.wide ? counts.bottom : reviewCol.bottom
        anchors.topMargin: 16; anchors.bottom: parent.bottom
        x: page.wide ? reviewCol.width + 12 : 0
        width: parent.width - x
        opacity: page.reveal
        transform: Translate { x: (1 - page.reveal) * 20 }
        Row {
            id: filters
            width: parent.width; spacing: 10
            TextField {
                id: filterField
                width: Math.max(160, parent.width - kinds.width - 10); height: 34
                placeholderText: "Find in memory…"; verticalAlignment: TextInput.AlignVCenter
                leftPadding: 34
                color: Theme.text; placeholderTextColor: Theme.muted; selectByMouse: true; font.pixelSize: 13
                Accessible.name: "Find in memory"
                background: Item {
                    Chamfer { anchors.fill: parent; cut: 8; fill: Theme.bgBottom; fillOpacity: 0.6
                              stroke: filterField.activeFocus ? Theme.accent : Theme.line; strokeWidth: filterField.activeFocus ? 1.5 : 1 }
                    Glyph { x: 11; anchors.verticalCenter: parent.verticalCenter; width: 14; height: 14; kind: "search"
                            stroke: filterField.activeFocus ? Theme.accent : Theme.muted }
                }
                onTextChanged: page.textFilter = text.trim()
            }
            Segmented {
                id: kinds
                options: ["", "note", "decision", "research"]
                value: page.kindFilter
                label: v => v === "" ? "All" : v === "note" ? "Notes" : v === "decision" ? "Decisions" : "Research"
                onPicked: v => page.kindFilter = v
            }
        }
        Text {
            id: countLine
            anchors.top: filters.bottom; anchors.topMargin: 14
            text: "REMEMBERED  ·  " + page.shown.length + (page.shown.length !== page.memories.length ? " OF " + page.memories.length : "")
            color: Theme.muted; font.family: "monospace"; font.pixelSize: 10; font.letterSpacing: 2
        }
        EmptyState {
            visible: page.memories.length === 0
            anchors.top: countLine.bottom; anchors.topMargin: Math.max(10, (memArea.height - countLine.y - height) / 2 - 40)
            width: parent.width
            glyph: "memory"; title: "Nothing remembered yet"
            hint: "Tell APVIS something worth keeping. It shows up for your review first, then lives here as a note you own."
            suggestions: ["remember that I like short answers", "we decided on emerald because it looks best"]
            onSuggested: text => page.suggest(text)
        }
        Text {
            anchors.top: countLine.bottom; anchors.topMargin: 12; visible: page.memories.length > 0 && page.shown.length === 0
            width: parent.width; wrapMode: Text.WordWrap; color: Theme.muted; font.pixelSize: 12
            text: "Nothing matches."
        }
        GridView {
            id: memGrid
            anchors.top: countLine.bottom; anchors.topMargin: 10; anchors.bottom: parent.bottom
            width: parent.width; clip: true
            readonly property int columns: width > 1100 ? 3 : width > 700 ? 2 : 1
            cellWidth: width / columns; cellHeight: 150
            model: page.shown
            ScrollBar.vertical: HudScrollBar {}
            delegate: Item {
                id: card
                required property var modelData
                required property int index
                readonly property color tone: page.kindColour(modelData.kind)
                width: memGrid.cellWidth; height: memGrid.cellHeight
                // Cards cascade in when the page opens.
                readonly property real local: Math.max(0, Math.min(1, page.reveal * 2 - index * 0.08))
                opacity: local
                transform: Translate { y: (1 - card.local) * 14 }
                Chamfer { x: 0; y: 0; width: parent.width - 12; height: parent.height - 12; cut: 12
                          fill: Theme.raised; fillOpacity: 0.8; fill2: Theme.bgBottom; fill2Opacity: 0.75
                          stroke: cardMouse.containsMouse ? card.tone : Theme.line
                          edgeGlow: cardMouse.containsMouse; glowColour: card.tone }
                MouseArea { id: cardMouse; anchors.fill: parent; hoverEnabled: true; acceptedButtons: Qt.NoButton }
                Rectangle { x: 0; y: 12; width: 2.5; height: parent.height - 36; color: card.tone }
                Column {
                    x: 16; y: 13; width: parent.width - 40; spacing: 4
                    Row {
                        spacing: 8
                        Rectangle {
                            width: kindText.implicitWidth + 12; height: 17; radius: 3
                            color: Qt.rgba(card.tone.r, card.tone.g, card.tone.b, 0.12); border.width: 1
                            border.color: Qt.rgba(card.tone.r, card.tone.g, card.tone.b, 0.5)
                            Text { id: kindText; anchors.centerIn: parent; text: page.kindWord(card.modelData.kind); color: card.tone
                                   font.family: "monospace"; font.pixelSize: 9; font.letterSpacing: 1.5 }
                        }
                        Text { anchors.verticalCenter: parent.verticalCenter; text: card.modelData.updated ? card.modelData.updated.slice(0, 10) : ""
                               color: Theme.muted; font.family: "monospace"; font.pixelSize: 10 }
                    }
                    Text { width: parent.width; text: card.modelData.title; color: Theme.text; font.pixelSize: 15; elide: Text.ElideRight }
                    Text { width: parent.width; text: card.modelData.excerpt || " "; color: Theme.muted; font.pixelSize: 11
                           wrapMode: Text.WordWrap; maximumLineCount: 2; elide: Text.ElideRight }
                }
                Row {
                    x: 16; anchors.bottom: parent.bottom; anchors.bottomMargin: 22; spacing: 8
                    HudButton { width: 76; implicitHeight: 28; caption: "Open"; onClicked: shell.openNote(card.modelData.path) }
                    HudButton {
                        width: 100; implicitHeight: 28
                        tone: page.armedForget === card.modelData.path ? "warning" : "normal"
                        caption: page.armedForget === card.modelData.path ? "Press again" : "Forget"
                        Accessible.name: "Forget " + card.modelData.title
                        onClicked: {
                            if (page.armedForget === card.modelData.path) { page.armedForget = ""; shell.forgetMemory(card.modelData.path) }
                            else { page.armedForget = card.modelData.path; disarm.restart() }
                        }
                    }
                    Text { anchors.verticalCenter: parent.verticalCenter; visible: (card.modelData.tags || []).length > 0
                           text: (card.modelData.tags || []).slice(0, 3).map(t => "#" + t).join("  "); color: Theme.muted
                           font.family: "monospace"; font.pixelSize: 10; elide: Text.ElideRight; width: Math.max(0, card.width - 240) }
                }
            }
        }
    }
}
