import QtQuick
import QtQuick.Controls
import "../theme"

// System: a live monitor of this computer (measured every ~3 s by the status
// thread): load history, per-core use, temperatures, and the busiest
// programs. Your own programs can be ended (press twice); Home itself cannot.
Item {
    id: page
    readonly property var sys: shell.system || ({})
    readonly property var tel: shell.telemetry || ({})
    readonly property var hist: tel.history || ({})
    readonly property string me: (shell.host || {}).user || ""
    property int armed: -1
    Timer { id: disarm; interval: 4000; onTriggered: page.armed = -1 }
    onVisibleChanged: { shell.setSystemPageVisible(visible); if (visible) entry.restart() }
    property real reveal: 1
    NumberAnimation { id: entry; target: page; property: "reveal"; from: 0; to: 1; duration: 800; easing.type: Easing.OutCubic }
    function rate(n) { return n === undefined || n === null ? "—" : n < 1024 ? n + " B/s" : n < 1048576 ? (n / 1024).toFixed(1) + " KB/s" : (n / 1048576).toFixed(1) + " MB/s" }
    function last(a) { return a && a.length ? a[a.length - 1] : null }

    PageHeader {
        id: header
        width: parent.width
        code: "07"; title: "SYSTEM"; reveal: page.reveal
        subtitle: "This computer right now: measured every few seconds, nothing estimated."
    }
    Row {
        id: tiles
        anchors.top: header.bottom; anchors.topMargin: 16
        width: parent.width; spacing: 12
        readonly property real w: (width - 3 * spacing) / 4
        StatTile { width: tiles.w; order: 0; reveal: page.reveal; label: "CPU"; glyph: "cpu"
                   value: page.sys.available ? page.sys.cpu + "%" : "—"; sub: page.tel.freqMhz ? (page.tel.freqMhz / 1000).toFixed(2) + " GHz" : ""
                   fraction: page.sys.available ? page.sys.cpu / 100 : -1; tint: page.sys.cpu >= 90 ? Theme.attention : Theme.accent }
        StatTile { width: tiles.w; order: 1; reveal: page.reveal; label: "MEMORY"; glyph: "memory"
                   value: page.sys.available ? page.sys.memory + "%" : "—"
                   sub: page.tel.memoryUsedGb ? page.tel.memoryUsedGb + " / " + page.tel.memoryTotalGb + " GB" : ""
                   fraction: page.sys.available ? page.sys.memory / 100 : -1; tint: page.sys.memory >= 90 ? Theme.attention : Theme.accent }
        StatTile { width: tiles.w; order: 2; reveal: page.reveal; label: "STORAGE"; glyph: "storage"
                   value: page.sys.disk !== null && page.sys.disk !== undefined ? page.sys.disk + "%" : "—"; sub: "home folder's disk"
                   fraction: page.sys.disk ? page.sys.disk / 100 : -1; tint: page.sys.disk >= 90 ? Theme.attention : Theme.accent }
        StatTile { width: tiles.w; order: 3; reveal: page.reveal; label: "NETWORK"; glyph: "wifi"
                   value: "▼ " + page.rate(page.last(page.hist.down)); sub: "▲ " + page.rate(page.last(page.hist.up)) }
    }

    Flickable {
        anchors.top: tiles.bottom; anchors.topMargin: 16; anchors.bottom: parent.bottom
        width: parent.width; contentHeight: grid.height + 10; clip: true
        boundsBehavior: Flickable.StopAtBounds
        ScrollBar.vertical: HudScrollBar {}
        Flow {
            id: grid
            width: parent.width - 12; spacing: 14
            readonly property real half: (width - spacing) / 2

            HudPanel {
                width: grid.half; reveal: page.reveal; order: 4
                title: "LOAD HISTORY"; glyph: "activity"; meta: "LAST FEW MINUTES"
                Text { text: "CPU  ·  memory"; color: Theme.muted; font.pixelSize: 11 }
                Sparkline { width: parent.width; height: 90; values: page.hist.cpu || []; second: page.hist.memory || []; maxValue: 100 }
                Text { text: "Network  ·  ▼ download  ▲ upload"; color: Theme.muted; font.pixelSize: 11 }
                Sparkline { width: parent.width; height: 70; values: page.hist.down || []; second: page.hist.up || [] }
            }
            HudPanel {
                width: grid.half; reveal: page.reveal; order: 5
                title: "CPU CORES"; glyph: "chip"; meta: (page.tel.cores || []).length + " CORES"
                Flow {
                    width: parent.width; spacing: 10
                    Repeater {
                        model: page.tel.cores || []
                        delegate: Item {
                            required property var modelData
                            required property int index
                            width: 58; height: 104
                            Rectangle { x: 20; y: 0; width: 18; height: 80; radius: 3; color: Qt.rgba(1, 1, 1, 0.06); border.color: Theme.line
                                Rectangle { anchors.bottom: parent.bottom; width: parent.width; radius: 3
                                            height: parent.height * Math.min(1, modelData / 100)
                                            color: modelData >= 90 ? Theme.attention : Theme.accent
                                            Behavior on height { NumberAnimation { duration: 600; easing.type: Easing.OutCubic } } } }
                            Text { anchors.horizontalCenter: parent.horizontalCenter; y: 84; text: modelData + "%"; color: Theme.text; font.pixelSize: 11 }
                            Text { anchors.horizontalCenter: parent.horizontalCenter; y: 97; text: "#" + (index + 1); color: Theme.muted; font.pixelSize: 9 }
                        }
                    }
                }
                Text { visible: !(page.tel.cores || []).length; text: "Measuring…"; color: Theme.muted; font.pixelSize: 12 }
                Rectangle { width: parent.width; height: 1; color: Theme.line }
                Text { text: "TEMPERATURES"; color: Theme.muted; font.pixelSize: 10; font.letterSpacing: 1.6 }
                Flow {
                    width: parent.width; spacing: 14
                    Repeater {
                        model: page.tel.temps || []
                        delegate: Text { required property var modelData
                                         text: modelData.label + "  " + modelData.c + " °C"; font.pixelSize: 12
                                         color: modelData.c >= 85 ? Theme.attention : Theme.text }
                    }
                }
                Text { visible: !(page.tel.temps || []).length; text: "No temperature sensors reported."; color: Theme.muted; font.pixelSize: 12 }
            }
            HudPanel {
                width: grid.width; reveal: page.reveal; order: 6
                title: "BUSIEST PROGRAMS"; glyph: "cpu"; meta: (page.tel.processCount || 0) + " RUNNING"
                Item {
                    width: parent.width; height: 22
                    Text { x: 0; text: "PROGRAM"; color: Theme.muted; font.pixelSize: 10; font.letterSpacing: 1.4 }
                    Text { x: parent.width * 0.42; text: "CPU"; color: Theme.muted; font.pixelSize: 10; font.letterSpacing: 1.4 }
                    Text { x: parent.width * 0.56; text: "MEMORY"; color: Theme.muted; font.pixelSize: 10; font.letterSpacing: 1.4 }
                    Text { x: parent.width * 0.70; text: "OWNER"; color: Theme.muted; font.pixelSize: 10; font.letterSpacing: 1.4 }
                }
                Repeater {
                    model: page.tel.processes || []
                    delegate: Item {
                        id: proc
                        required property var modelData
                        readonly property bool mine: !!page.me && modelData.user === page.me
                        width: parent.width; height: 34
                        Rectangle { anchors.fill: parent; radius: 6; color: procMouse.containsMouse ? Qt.rgba(1, 1, 1, 0.04) : "transparent" }
                        MouseArea { id: procMouse; anchors.fill: parent; hoverEnabled: true; acceptedButtons: Qt.NoButton }
                        Text { x: 4; anchors.verticalCenter: parent.verticalCenter; width: parent.width * 0.4; elide: Text.ElideRight
                               text: proc.modelData.name; color: Theme.text; font.pixelSize: 13 }
                        Item {
                            x: parent.width * 0.42; width: parent.width * 0.12; height: parent.height
                            Text { anchors.verticalCenter: parent.verticalCenter; text: proc.modelData.cpu + "%"; color: proc.modelData.cpu >= 50 ? Theme.attention : Theme.text; font.pixelSize: 13 }
                        }
                        Text { x: parent.width * 0.56; anchors.verticalCenter: parent.verticalCenter; text: proc.modelData.mem + "%"; color: Theme.text; font.pixelSize: 13 }
                        Text { x: parent.width * 0.70; anchors.verticalCenter: parent.verticalCenter; width: parent.width * 0.16; elide: Text.ElideRight
                               text: proc.modelData.user || "system"; color: Theme.muted; font.pixelSize: 12 }
                        HudButton {
                            visible: proc.mine
                            anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter
                            width: 110; implicitHeight: 28
                            tone: page.armed === proc.modelData.pid ? "warning" : "normal"
                            caption: page.armed === proc.modelData.pid ? "Press again" : "End"
                            Accessible.name: "End " + proc.modelData.name
                            onClicked: {
                                if (page.armed === proc.modelData.pid) { page.armed = -1; shell.endProcess(proc.modelData.pid) }
                                else { page.armed = proc.modelData.pid; disarm.restart() }
                            }
                        }
                    }
                }
                Text { visible: !(page.tel.processes || []).length; text: "Measuring…"; color: Theme.muted; font.pixelSize: 12 }
                Text { width: parent.width; wrapMode: Text.WordWrap; color: Theme.muted; font.pixelSize: 11
                       text: "Only your own programs can be ended here, and ending asks the program to close (like closing its window)." }
            }
        }
    }
}
