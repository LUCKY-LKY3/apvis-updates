import QtQuick
import "../theme"

// The brand block (owner concept): the faceted mark, name and version, and
// what APVIS is for.
Item {
    id: brand
    property string version: ""
    property real markSize: 104
    implicitWidth: row.width
    implicitHeight: row.height
    Row {
        id: row
        spacing: 22
        ApvisMark { width: brand.markSize; height: brand.markSize * 0.88; glow: 0.9 }
        Column {
            anchors.verticalCenter: parent.verticalCenter
            spacing: 4
            Row {
                spacing: 8
                Text { id: name; text: "APVIS OS"; color: Theme.text; font.pixelSize: brand.markSize * 0.29; font.weight: Font.Light; font.letterSpacing: 1.5 }
                Text { anchors.baseline: name.baseline; text: brand.version; color: Theme.muted; font.pixelSize: 11 }
            }

        }
    }
}
