"""Ask: answer the owner's questions with local Ollama models (LOCAL ONLY by default).

Routing is owner-configured by role: a fast default, a smarter general model
for harder questions, and a code model for PC/code help. Answers are text only;
Ask never runs commands or changes the system (actions arrive with Mission
Control and always need approval).
"""

from __future__ import annotations

import json
import os
import re
import tempfile
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable

from .common import redact_sensitive, utc_now
from .missions import CAPABILITIES as MISSION_CAPABILITIES
from .vault import Vault, notes_context
from .intelligence import CapabilityRequirement, DataSensitivity, DestinationPolicy, ProviderLocality, eligible_candidates
from .ollama import DEFAULT_URL, InstalledModel, OllamaAdapter, OllamaClient, OllamaError, local_url

ROLES = ("fast", "general", "code", "deep")
# Owner decision 2026-09-23: llama3.2:1b is the fast default and the coder model
# handles PC/code help; qwen3:4b was to step in for harder questions only if fast
# enough. Measured on the OptiPlex (2026-09-24, CPU only) it always reasons first
# and took 2-5 minutes per answer, so it is the opt-in "deep" role and is never
# chosen automatically. Later entries are fallbacks when a model is not installed.
DEFAULT_ROLES: dict[str, list[str]] = {
    "fast": ["llama3.2:1b", "llama3.2:3b"],
    "general": ["llama3.2:3b", "llama3.2:1b"],
    "code": ["qwen2.5-coder:1.5b", "llama3.2:1b", "llama3.2:3b"],
    "deep": ["qwen3:4b", "qwen2.5-coder:7b", "llama3.2:3b", "llama3.2:1b"],
}
SYSTEM_PROMPT = (
    "You are APVIS, the assistant built into the owner's computer (APVIS OS). "
    "Answer the question directly, confidently, clearly and briefly, like a knowledgeable friend. "
    "Do not apologise or describe your limitations unless the owner asks you to do something "
    "on the computer or look something up online; then say you cannot do that yet. "
    "Never invent specific numbers, names or dates you do not know."
)
MAX_QUESTION = 4000
HISTORY_LIMIT = 200

_CODE = re.compile(r"(?i)\b(code|script|bash|python|terminal|command|error|traceback|compile|function|regex|sql|git|linux|sudo|apt|install|debug|bug)\b|```")
_HARD = re.compile(r"(?i)\b(explain|why|compare|difference|plan|design|analy[sz]e|pros and cons|step[- ]by[- ]step|summari[sz]e|essay|reason|prove|calculate|how does|how do)\b")


_ACTION = re.compile(
    r"(?i)^\s*(?:(?:hey|ok|okay)?\s*apvis[,:]?\s*)?(?:please\s+|can you\s+|could you\s+|would you\s+)?"
    r"(open|launch|start|run|close|quit|kill|install|uninstall|update|upgrade|delete|remove|erase|format|"
    r"shut\s*down|restart|reboot|turn\s+(?:on|off)|switch\s+(?:on|off)|enable|disable|set|change|mute|unmute|"
    r"play|pause|download|create|make\s+a\s+(?:file|folder)|move|copy|rename|send|email|buy)\b"
)
ACTION_REPLY = (
    "I can't do that one yet. Right now I can " + MISSION_CAPABILITIES + ". "
    "Anything that changes something asks for your approval first."
)


def is_action_request(question: str) -> bool:
    """Requests to act are answered honestly by APVIS itself, never by a model that might claim it acted."""
    return bool(_ACTION.match(question))


def classify(question: str) -> str:
    """Pick a role from the question itself; short everyday questions stay fast."""
    if _CODE.search(question):
        return "code"
    if _HARD.search(question) or len(question) > 220 or question.count("?") > 1:
        return "general"
    return "fast"


ROUTER_PROMPT = (
    "You route questions for a computer assistant. Reply with exactly one word:\n"
    "chat - everyday questions, facts, advice, conversation\n"
    "code - programming, scripts, terminal commands, Linux or PC problems, errors\n"
    "deep - long multi-step reasoning, detailed plans, maths proofs, in-depth analysis\n"
    "Reply with only chat, code or deep."
)
ROUTE_ROLES = {"chat": "fast", "code": "code", "deep": "deep"}


def parse_route(reply: str) -> str | None:
    """The router's one-word answer -> a role; None if it said something else."""
    words = re.findall(r"[a-z]+", (reply or "").lower())
    for word in words[:3]:
        if word in ROUTE_ROLES:
            return ROUTE_ROLES[word]
    return None


def resolve_model(role: str, roles: dict[str, list[str]], installed: list[InstalledModel]) -> str | None:
    # "llama3.2" and "llama3.2:latest" are the same model to Ollama.
    actual = {m.name.removesuffix(":latest"): m.name for m in installed}
    for candidate_role in (role, *ROLES):
        for wanted in roles.get(candidate_role, []):
            if wanted.removesuffix(":latest") in actual:
                return actual[wanted.removesuffix(":latest")]
    return None


def _state_dir() -> Path:
    return Path(os.environ.get("APVIS_OS_STATE_DIR", "/var/lib/apvis-os")) / "ask"


@dataclass
class AskConfig:
    ollama_url: str = DEFAULT_URL
    roles: dict[str, list[str]] = field(default_factory=lambda: {k: list(v) for k, v in DEFAULT_ROLES.items()})
    destination_policy: str = DestinationPolicy.LOCAL_ONLY.value

    def validate(self) -> "AskConfig":
        self.ollama_url = local_url(self.ollama_url)
        DestinationPolicy(self.destination_policy)
        for role, models in self.roles.items():
            if role not in ROLES or not isinstance(models, list) or not all(isinstance(m, str) and m.strip() for m in models):
                raise ValueError(f"invalid model list for role {role!r}")
        for role in ROLES:
            self.roles.setdefault(role, list(DEFAULT_ROLES[role]))
        return self

    @classmethod
    def load(cls, path: Path | None = None) -> "AskConfig":
        path = path or _state_dir() / "config.json"
        config = cls()
        for source in (Path("/etc/apvis-os/ask.json"), path):
            try:
                data = json.loads(source.read_text(encoding="utf-8"))
            except FileNotFoundError:
                continue
            if not isinstance(data, dict):
                raise ValueError(f"{source} must contain an object")
            config.ollama_url = data.get("ollama_url", config.ollama_url)
            config.roles.update(data.get("roles", {}))
            config.destination_policy = data.get("destination_policy", config.destination_policy)
        if os.environ.get("APVIS_OLLAMA_URL"):
            config.ollama_url = os.environ["APVIS_OLLAMA_URL"]
        return config.validate()

    def save(self, path: Path | None = None) -> Path:
        self.validate()
        path = path or _state_dir() / "config.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        _atomic_write(path, json.dumps(asdict(self), indent=2, sort_keys=True) + "\n")
        return path


def _atomic_write(path: Path, text: str) -> None:
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(text)
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


@dataclass
class AskResult:
    question: str
    status: str                       # completed | unavailable | failed | cancelled
    answer: str = ""
    role: str = ""
    model: str | None = None
    provider: str = "ollama"
    endpoint: str = ""
    locality: str = ProviderLocality.LOCAL.value
    error: str | None = None
    first_token_s: float | None = None
    notes_used: list[str] = field(default_factory=list)
    total_s: float | None = None
    routed_by: str | None = None       # the fast model that picked the role, when it did
    route_s: float | None = None
    observed_at: str = field(default_factory=utc_now)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class AskService:
    def __init__(self, config: AskConfig | None = None, client: OllamaClient | None = None,
                 history: Path | None = None, clock: Callable[[], float] = time.perf_counter,
                 vault: Vault | None = None) -> None:
        self.config = config or AskConfig.load()
        self.client = client or OllamaClient(self.config.ollama_url)
        self.history = history or _state_dir() / "history.jsonl"
        self.vault = vault or Vault()
        self._clock = clock

    def status(self) -> dict[str, Any]:
        """What Ask would use right now; never claims a model that was not observed."""
        result: dict[str, Any] = {"endpoint": self.client.url, "destination_policy": self.config.destination_policy,
                                  "observed_at": utc_now()}
        try:
            result["ollama_version"] = self.client.version()
            installed = self.client.models()
        except OllamaError as exc:
            result.update({"status": "unavailable", "error": str(exc)})
            return result
        result["installed"] = [m.name for m in installed]
        result["roles"] = {role: resolve_model(role, self.config.roles, installed) for role in ROLES}
        result["status"] = "available" if any(result["roles"].values()) else "no-model"
        return result

    def ask(self, question: str, *, role: str | None = None, model: str | None = None,
            on_text: Callable[[str], None] | None = None, cancelled: Callable[[], bool] = lambda: False) -> AskResult:
        question = (question or "").strip()
        if not question:
            raise ValueError("a question is required")
        if len(question) > MAX_QUESTION:
            raise ValueError(f"questions are limited to {MAX_QUESTION} characters")
        start = self._clock()
        routed_by, route_s = None, None
        if role is None and model is None and not is_action_request(question):
            role, routed_by = self.route(question)
            route_s = round(self._clock() - start, 2) if routed_by else None
        role = role or classify(question)
        if role not in ROLES:
            raise ValueError(f"unknown role {role!r}")
        result = AskResult(question, "failed", role=role, endpoint=self.client.url, routed_by=routed_by, route_s=route_s)
        if model is None and is_action_request(question):
            result.status, result.answer, result.provider, result.model = "completed", ACTION_REPLY, "apvis", "APVIS"
            result.first_token_s = result.total_s = round(self._clock() - start, 2)
            if on_text:
                on_text(ACTION_REPLY)
            return self._record(result)
        try:
            installed = self.client.models()
            chosen = model if model and model in {m.name for m in installed} else resolve_model(role, self.config.roles, installed)
            if model and chosen != model:
                raise OllamaError(f"model {model} is not installed")
            if chosen is None:
                result.status = "unavailable"
                result.error = "no Ollama model is installed for Ask"
                return self._record(result)
            # Hard privacy rule: Ask only ever uses LOCAL candidates under the configured policy.
            adapter = OllamaAdapter(self.client, chosen)
            requirement = CapabilityRequirement.CODE if role == "code" else CapabilityRequirement.GENERAL
            if not eligible_candidates(requirement, DestinationPolicy(self.config.destination_policy),
                                       DataSensitivity.PRIVATE, [adapter.candidate]):
                raise OllamaError("routing policy refused the local model")
            result.model = chosen
            system = SYSTEM_PROMPT
            try:
                context, result.notes_used = notes_context(self.vault, question)
            except OSError:
                context = ""
            if context:
                # The owner's own vault notes, used locally only; the model is told they may be irrelevant.
                system += ("\n\nThe owner's own notes that may be relevant (use them only if they answer the "
                           "question, and say which note you used):\n\n" + context)
            messages = [{"role": "system", "content": system}, {"role": "user", "content": question}]
            parts: list[str] = []
            for text in self.client.chat_stream(chosen, messages, cancelled=cancelled):
                if result.first_token_s is None:
                    result.first_token_s = round(self._clock() - start, 2)
                parts.append(text)
                if on_text:
                    on_text("".join(parts))
            result.answer = "".join(parts).strip()
            result.status = "cancelled" if cancelled() else "completed"
        except OllamaError as exc:
            result.status = "unavailable" if "not reachable" in str(exc) else "failed"
            result.error = str(exc)
        result.total_s = round(self._clock() - start, 2)
        return self._record(result)

    def route(self, question: str) -> tuple[str | None, str | None]:
        """The fast model decides which role answers (owner's design, 2026-09-25).

        Skipped when every role would land on the same model anyway. Anything
        unexpected (no fast model, a timeout, a reply that is not one of the
        three words) falls back to the keyword rules in classify().
        """
        try:
            installed = self.client.models()
        except OllamaError:
            return None, None
        if classify(question) == "fast":
            return None, None     # short everyday question: no extra model call before answering
        fast = resolve_model("fast", self.config.roles, installed)
        targets = {resolve_model(r, self.config.roles, installed) for r in ("fast", "code", "deep")}
        if fast is None or len(targets) < 2:
            return None, None
        messages = [{"role": "system", "content": ROUTER_PROMPT}, {"role": "user", "content": question[:1500]}]
        try:
            reply = "".join(self.client.chat_stream(fast, messages, max_tokens=4, read_timeout=20.0))
        except OllamaError:
            return None, None
        chosen = parse_route(reply)
        return (chosen, fast) if chosen else (None, None)

    def _record(self, result: AskResult) -> AskResult:
        """Keep a private local history (owner-only file, bounded, credentials redacted)."""
        try:
            self.history.parent.mkdir(parents=True, exist_ok=True)
            lines = self.history.read_text(encoding="utf-8").splitlines() if self.history.exists() else []
            lines.append(json.dumps(redact_sensitive(result.to_dict()), sort_keys=True))
            _atomic_write(self.history, "\n".join(lines[-HISTORY_LIMIT:]) + "\n")
        except OSError:
            pass  # history is a convenience; the answer itself must still be shown
        return result
