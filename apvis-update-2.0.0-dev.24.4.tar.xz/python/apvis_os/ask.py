"""Ask: answer the owner's questions with local Ollama models (LOCAL ONLY by default).

Routing is owner-configured by role: a fast default, a smarter general model
for harder questions, and a code model for PC/code help. Answers are text only;
Ask never runs commands or changes the system (actions arrive with Mission
Control and always need approval).
"""

from __future__ import annotations

import json
import os
import re
import tempfile
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable

from .common import redact_sensitive, utc_now
from .missions import CAPABILITIES as MISSION_CAPABILITIES
from .vault import Vault, notes_context
from .intelligence import CapabilityRequirement, DataSensitivity, DestinationPolicy, ProviderLocality, eligible_candidates
from .ollama import DEFAULT_URL, InstalledModel, OllamaAdapter, OllamaClient, OllamaError, local_url
from . import brain

ROLES = ("fast", "general", "code", "deep")
# Owner decision 2026-09-23: llama3.2:1b is the fast default and the coder model
# handles PC/code help; qwen3:4b was to step in for harder questions only if fast
# enough. Measured on the OptiPlex (2026-09-24, CPU only) it always reasons first
# and took 2-5 minutes per answer, so it is the opt-in "deep" role and is never
# chosen automatically. Later entries are fallbacks when a model is not installed.
DEFAULT_ROLES: dict[str, list[str]] = {
    "fast": ["llama3.2:1b", "llama3.2:3b"],
    "general": ["llama3.2:3b", "llama3.2:1b"],
    "code": ["qwen2.5-coder:1.5b", "llama3.2:1b", "llama3.2:3b"],
    "deep": ["qwen3:4b", "qwen2.5-coder:7b", "llama3.2:3b", "llama3.2:1b"],
}
SYSTEM_PROMPT = (
    "You are APVIS, the assistant built into the owner's computer (APVIS OS). "
    "Answer the question directly, confidently, clearly and briefly, like a knowledgeable friend. "
    "Do not apologise or describe your limitations unless the owner asks you to do something "
    "on the computer or look something up online; then say you cannot do that yet. "
    "Never invent specific numbers, names or dates you do not know."
)
MAX_QUESTION = 4000
HISTORY_LIMIT = 200

_CODE = re.compile(r"(?i)\b(code|script|bash|python|terminal|command|error|traceback|compile|function|regex|sql|git|linux|sudo|apt|install|debug|bug)\b|```")
_HARD = re.compile(r"(?i)\b(explain|why|compare|difference|plan|design|analy[sz]e|pros and cons|step[- ]by[- ]step|summari[sz]e|essay|reason|prove|calculate|how does|how do)\b")


_ACTION = re.compile(
    r"(?i)^\s*(?:(?:hey|ok|okay)?\s*apvis[,:]?\s*)?(?:please\s+|can you\s+|could you\s+|would you\s+)?"
    r"(open|launch|start|run|close|quit|kill|install|uninstall|update|upgrade|delete|remove|erase|format|"
    r"shut\s*down|restart|reboot|turn\s+(?:on|off)|switch\s+(?:on|off)|enable|disable|set|change|mute|unmute|"
    r"play|pause|download|create|make\s+a\s+(?:file|folder)|move|copy|rename|send|email|buy)\b"
)
ACTION_REPLY = (
    "I can't do that one yet. Right now I can " + MISSION_CAPABILITIES + ". "
    "Anything that changes something asks for your approval first."
)


def is_action_request(question: str) -> bool:
    """Requests to act are answered honestly by APVIS itself, never by a model that might claim it acted."""
    return bool(_ACTION.match(question))


def classify(question: str) -> str:
    """Pick a role from the question itself; short everyday questions stay fast."""
    if _CODE.search(question):
        return "code"
    if _HARD.search(question) or len(question) > 220 or question.count("?") > 1:
        return "general"
    return "fast"


ROUTER_PROMPT = (
    "You route questions for a computer assistant. Reply with exactly one word:\n"
    "chat - everyday questions, facts, advice, conversation\n"
    "code - programming, scripts, terminal commands, Linux or PC problems, errors\n"
    "deep - long multi-step reasoning, detailed plans, maths proofs, in-depth analysis\n"
    "Reply with only chat, code or deep."
)
ROUTE_ROLES = {"chat": "fast", "code": "code", "deep": "deep"}


def parse_route(reply: str) -> str | None:
    """The router's one-word answer -> a role; None if it said something else."""
    words = re.findall(r"[a-z]+", (reply or "").lower())
    for word in words[:3]:
        if word in ROUTE_ROLES:
            return ROUTE_ROLES[word]
    return None


def resolve_model(role: str, roles: dict[str, list[str]], installed: list[InstalledModel]) -> str | None:
    # "llama3.2" and "llama3.2:latest" are the same model to Ollama.
    actual = {m.name.removesuffix(":latest"): m.name for m in installed}
    for candidate_role in (role, *ROLES):
        for wanted in roles.get(candidate_role, []):
            if wanted.removesuffix(":latest") in actual:
                return actual[wanted.removesuffix(":latest")]
    return None


def _state_dir() -> Path:
    return Path(os.environ.get("APVIS_OS_STATE_DIR", "/var/lib/apvis-os")) / "ask"


@dataclass
class AskConfig:
    ollama_url: str = DEFAULT_URL
    roles: dict[str, list[str]] = field(default_factory=lambda: {k: list(v) for k, v in DEFAULT_ROLES.items()})
    destination_policy: str = DestinationPolicy.LOCAL_ONLY.value
    # The owner's gaming PC running Ollama on the home network (optional; LAN addresses only).
    boost_url: str = ""
    boost_enabled: bool = False
    boost_mac: str = ""              # for Wake-on-LAN, optional
    api_enabled: bool = True         # the local APVIS API at http://127.0.0.1:8765

    def validate(self) -> "AskConfig":
        self.ollama_url = local_url(self.ollama_url)
        self.boost_url = local_url(self.boost_url) if (self.boost_url or "").strip() else ""
        self.boost_enabled = bool(self.boost_enabled and self.boost_url)
        self.api_enabled = bool(self.api_enabled)
        mac = re.sub(r"[^0-9a-fA-F]", "", self.boost_mac or "")
        if self.boost_mac and len(mac) != 12:
            raise ValueError("a MAC address looks like 1C:1B:0D:12:34:56")
        self.boost_mac = ":".join(mac[i:i + 2] for i in range(0, 12, 2)).upper() if mac else ""
        DestinationPolicy(self.destination_policy)
        for role, models in self.roles.items():
            if role not in ROLES or not isinstance(models, list) or not all(isinstance(m, str) and m.strip() for m in models):
                raise ValueError(f"invalid model list for role {role!r}")
        for role in ROLES:
            self.roles.setdefault(role, list(DEFAULT_ROLES[role]))
        return self

    @classmethod
    def load(cls, path: Path | None = None) -> "AskConfig":
        path = path or _state_dir() / "config.json"
        config = cls()
        for source in (Path("/etc/apvis-os/ask.json"), path):
            try:
                data = json.loads(source.read_text(encoding="utf-8"))
            except FileNotFoundError:
                continue
            if not isinstance(data, dict):
                raise ValueError(f"{source} must contain an object")
            config.ollama_url = data.get("ollama_url", config.ollama_url)
            config.roles.update(data.get("roles", {}))
            config.destination_policy = data.get("destination_policy", config.destination_policy)
            for key in ("boost_url", "boost_enabled", "boost_mac", "api_enabled"):
                if key in data:
                    setattr(config, key, data[key])
        if os.environ.get("APVIS_OLLAMA_URL"):
            config.ollama_url = os.environ["APVIS_OLLAMA_URL"]
        return config.validate()

    def save(self, path: Path | None = None) -> Path:
        self.validate()
        path = path or _state_dir() / "config.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        _atomic_write(path, json.dumps(asdict(self), indent=2, sort_keys=True) + "\n")
        return path


def _atomic_write(path: Path, text: str) -> None:
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(text)
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


@dataclass
class AskResult:
    question: str
    status: str                       # completed | unavailable | failed | cancelled
    answer: str = ""
    role: str = ""
    model: str | None = None
    provider: str = "ollama"
    endpoint: str = ""
    locality: str = ProviderLocality.LOCAL.value
    error: str | None = None
    first_token_s: float | None = None
    notes_used: list[str] = field(default_factory=list)
    total_s: float | None = None
    routed_by: str | None = None       # the fast model that picked the role, when it did
    route_s: float | None = None
    source: str = "local"              # instant | remembered | local | gaming-pc
    observed_at: str = field(default_factory=utc_now)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class AskService:
    def __init__(self, config: AskConfig | None = None, client: OllamaClient | None = None,
                 history: Path | None = None, clock: Callable[[], float] = time.perf_counter,
                 vault: Vault | None = None, cache: brain.AnswerCache | None = None,
                 boost: brain.BoostState | None = None, name: str | None = None) -> None:
        self.config = config or AskConfig.load()
        self.client = client or OllamaClient(self.config.ollama_url)
        self.history = history or _state_dir() / "history.jsonl"
        self.vault = vault or Vault()
        self.cache = cache or brain.AnswerCache(self.history.parent / "answers.json")
        self.boost = boost or brain.BOOST
        self._name = name
        self._clock = clock

    def owner_name(self) -> str:
        if self._name is None:
            try:
                from .hostinfo import real_name
                self._name = real_name()
            except (ImportError, OSError, KeyError, ValueError):
                self._name = ""
            if self._name.lower() == "apvis":
                self._name = ""
        return self._name

    def boost_client(self, role: str) -> tuple[OllamaClient, str] | None:
        """The gaming PC and the model it would use for this role, if it is on right now."""
        if not (self.config.boost_enabled and self.config.boost_url):
            return None
        state = self.boost.get(self.config.boost_url)
        if not state.get("reachable"):
            return None
        chosen = brain.pick_boost_model(role, state.get("models", []))
        return (OllamaClient(self.config.boost_url, timeout=3), chosen) if chosen else None

    def warm(self, model: str | None = None) -> str | None:
        """Load the fast model with the real settings and run the system prompt once, so Ollama's
        prompt cache holds it and the next question only has to process its own words."""
        try:
            installed = self.client.models()
        except OllamaError:
            return None
        model = model or resolve_model("fast", self.config.roles, installed)
        if not model:
            return None
        messages = [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": "hi"}]
        try:
            for _ in self.client.chat_stream(model, messages, max_tokens=1, read_timeout=240.0,
                                             options=brain.load_options("local"), keep_alive=brain.keep_alive("fast")):
                pass
        except OllamaError:
            return None
        return model

    def status(self) -> dict[str, Any]:
        """What Ask would use right now; never claims a model that was not observed."""
        result: dict[str, Any] = {"endpoint": self.client.url, "destination_policy": self.config.destination_policy,
                                  "observed_at": utc_now()}
        try:
            result["ollama_version"] = self.client.version()
            installed = self.client.models()
        except OllamaError as exc:
            result.update({"status": "unavailable", "error": str(exc)})
            return result
        result["installed"] = [m.name for m in installed]
        result["roles"] = {role: resolve_model(role, self.config.roles, installed) for role in ROLES}
        result["status"] = "available" if any(result["roles"].values()) else "no-model"
        return result

    def ask(self, question: str, *, role: str | None = None, model: str | None = None,
            on_text: Callable[[str], None] | None = None, cancelled: Callable[[], bool] = lambda: False,
            history: list[dict[str, str]] | None = None) -> AskResult:
        question = (question or "").strip()
        if not question:
            raise ValueError("a question is required")
        if len(question) > MAX_QUESTION:
            raise ValueError(f"questions are limited to {MAX_QUESTION} characters")
        history = [m for m in (history or []) if m.get("role") in {"user", "assistant"} and isinstance(m.get("content"), str)][-6:]
        start = self._clock()

        def finish_now(answer: str, source: str, model_name: str, provider: str = "apvis") -> AskResult:
            result = AskResult(question, "completed", answer=answer, role=role or "fast", model=model_name,
                               provider=provider, endpoint=self.client.url, source=source)
            result.first_token_s = result.total_s = round(self._clock() - start, 3)
            if on_text:
                on_text(answer)
            return self._record(result)

        # 1. Instant answers and 2. remembered answers: no model, no waiting.
        if model is None and not history:
            instant = brain.instant_answer(question, self.owner_name())
            if instant:
                return finish_now(instant, "instant", "APVIS")
            if role is None:
                remembered = self.cache.get(question)
                if remembered:
                    return finish_now(remembered["answer"], "remembered", remembered.get("model", ""), "ollama")
        routed_by, route_s = None, None
        if role is None and model is None and not is_action_request(question):
            role, routed_by = self.route(question)
            route_s = round(self._clock() - start, 2) if routed_by else None
        role = role or classify(question)
        if role not in ROLES:
            raise ValueError(f"unknown role {role!r}")
        result = AskResult(question, "failed", role=role, endpoint=self.client.url, routed_by=routed_by, route_s=route_s)
        if model is None and is_action_request(question):
            result.status, result.answer, result.provider, result.model = "completed", ACTION_REPLY, "apvis", "APVIS"
            result.source = "instant"
            result.first_token_s = result.total_s = round(self._clock() - start, 2)
            if on_text:
                on_text(ACTION_REPLY)
            return self._record(result)
        system = SYSTEM_PROMPT
        try:
            context, result.notes_used = notes_context(self.vault, question)
        except OSError:
            context = ""
        if context:
            # The owner's own vault notes, used locally only; the model is told they may be irrelevant.
            system += ("\n\nThe owner's own notes that may be relevant (use them only if they answer the "
                       "question, and say which note you used):\n\n" + context)
        messages = [{"role": "system", "content": system}, *history, {"role": "user", "content": question}]
        parts: list[str] = []

        def stream(client: OllamaClient, chosen: str, where: str) -> None:
            # Hard privacy rule: only LOCAL candidates (this computer or the home network) under the configured policy.
            adapter = OllamaAdapter(client, chosen)
            requirement = CapabilityRequirement.CODE if role == "code" else CapabilityRequirement.GENERAL
            if not eligible_candidates(requirement, DestinationPolicy(self.config.destination_policy),
                                       DataSensitivity.PRIVATE, [adapter.candidate]):
                raise OllamaError("routing policy refused the local model")
            result.model, result.endpoint = chosen, client.url
            result.source = "gaming-pc" if where == "boost" else "local"
            tokens = (brain.BOOST_ANSWER_TOKENS if where == "boost" else brain.ANSWER_TOKENS).get(role, 640)
            for text in client.chat_stream(chosen, messages, cancelled=cancelled, max_tokens=tokens,
                                           options=brain.load_options(where), keep_alive=brain.keep_alive(role, where)):
                if result.first_token_s is None:
                    result.first_token_s = round(self._clock() - start, 2)
                parts.append(text)
                if on_text:
                    on_text("".join(parts))

        try:
            # 3. The gaming PC, when it is on (never for a specific local model the owner picked).
            boost = self.boost_client(role) if model is None else None
            if boost is not None:
                try:
                    stream(boost[0], boost[1], "boost")
                except OllamaError as exc:
                    self.boost.mark_down(self.config.boost_url, str(exc))
                    if parts:
                        raise OllamaError("the gaming PC stopped answering") from exc
                    boost = None       # it went away before answering: this computer answers instead
            if boost is None:
                # 4. This computer.
                installed = self.client.models()
                chosen = model if model and model in {m.name for m in installed} else resolve_model(role, self.config.roles, installed)
                if model and chosen != model:
                    raise OllamaError(f"model {model} is not installed")
                if chosen is None:
                    result.status = "unavailable"
                    result.error = "no Ollama model is installed for Ask"
                    return self._record(result)
                stream(self.client, chosen, "local")
            result.answer = "".join(parts).strip()
            result.status = "cancelled" if cancelled() else "completed"
            if result.status == "completed" and not result.notes_used and not history and model is None:
                self.cache.put(question, result.answer, result.model or "")
        except OllamaError as exc:
            result.status = "unavailable" if "not reachable" in str(exc) else "failed"
            result.error = str(exc)
        result.total_s = round(self._clock() - start, 2)
        return self._record(result)

    def route(self, question: str) -> tuple[str | None, str | None]:
        """The fast model decides which role answers (owner's design, 2026-09-25).

        Skipped when every role would land on the same model anyway. Anything
        unexpected (no fast model, a timeout, a reply that is not one of the
        three words) falls back to the keyword rules in classify().
        """
        try:
            installed = self.client.models()
        except OllamaError:
            return None, None
        if classify(question) == "fast":
            return None, None     # short everyday question: no extra model call before answering
        fast = resolve_model("fast", self.config.roles, installed)
        targets = {resolve_model(r, self.config.roles, installed) for r in ("fast", "code", "deep")}
        if fast is None or len(targets) < 2:
            return None, None
        messages = [{"role": "system", "content": ROUTER_PROMPT}, {"role": "user", "content": question[:1500]}]
        try:
            reply = "".join(self.client.chat_stream(fast, messages, max_tokens=4, read_timeout=20.0,
                                                    options=brain.load_options("local"), keep_alive=brain.keep_alive("fast")))
        except OllamaError:
            return None, None
        chosen = parse_route(reply)
        return (chosen, fast) if chosen else (None, None)

    def _record(self, result: AskResult) -> AskResult:
        """Keep a private local history (owner-only file, bounded, credentials redacted)."""
        try:
            self.history.parent.mkdir(parents=True, exist_ok=True)
            lines = self.history.read_text(encoding="utf-8").splitlines() if self.history.exists() else []
            lines.append(json.dumps(redact_sensitive(result.to_dict()), sort_keys=True))
            _atomic_write(self.history, "\n".join(lines[-HISTORY_LIMIT:]) + "\n")
        except OSError:
            pass  # history is a convenience; the answer itself must still be shown
        return result
