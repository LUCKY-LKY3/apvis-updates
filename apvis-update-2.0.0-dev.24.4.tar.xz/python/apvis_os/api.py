"""The APVIS API: one local AI endpoint for every app and script on this computer.

    http://127.0.0.1:8765        (this computer only; never the network)

Same brain as Home's Ask: instant answers, remembered answers, the gaming PC when it is
on, and the tuned local models otherwise.

    GET  /v1/health                    what would answer right now
    GET  /v1/models                    OpenAI-style model list ("apvis" = automatic)
    POST /v1/ask                       {"question": "...", "stream": false}
    POST /v1/chat/completions          OpenAI-compatible, "stream": true supported

Browser pages cannot use it: requests carrying an Origin header, a foreign Host header
or a non-JSON body are refused, so a web page cannot make this computer's AI work for it.
Run on its own with:  python3 -m apvis_os.api
"""

from __future__ import annotations

import argparse
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from uuid import uuid4

from .ask import AskConfig, AskService, resolve_model, ROLES
from .ollama import OllamaError
from . import brain

HOST = "127.0.0.1"
PORT = 8765
MAX_BODY = 256 * 1024


def health() -> dict[str, Any]:
    config = AskConfig.load()
    service = AskService(config)
    out: dict[str, Any] = {"api": f"http://{HOST}:{PORT}", "instant": True, "boost": {"configured": bool(config.boost_url),
                           "enabled": config.boost_enabled}}
    try:
        installed = service.client.models()
        out["local"] = {"reachable": True, "roles": {r: resolve_model(r, config.roles, installed) for r in ROLES}}
    except OllamaError as exc:
        out["local"] = {"reachable": False, "error": str(exc)}
    if config.boost_enabled and config.boost_url:
        state = brain.BOOST.get(config.boost_url)
        out["boost"].update({"reachable": bool(state.get("reachable")),
                             "roles": {r: brain.pick_boost_model(r, state.get("models", [])) for r in ROLES}})
    return out


class Handler(BaseHTTPRequestHandler):
    server_version = "APVIS-API/1"
    protocol_version = "HTTP/1.1"

    def log_message(self, format: str, *args: Any) -> None:     # noqa: A002 - keep questions out of logs
        pass

    # ---- plumbing
    def _allowed(self) -> bool:
        host = (self.headers.get("Host") or "").lower()
        port = self.server.server_address[1]
        if host not in {f"127.0.0.1:{port}", f"localhost:{port}"} or self.headers.get("Origin"):
            self._json(403, {"error": "the APVIS API only answers programs on this computer"})
            return False
        return True

    def _json(self, code: int, payload: dict[str, Any]) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _body(self) -> dict[str, Any] | None:
        if (self.headers.get("Content-Type") or "").split(";")[0].strip().lower() != "application/json":
            self._json(415, {"error": "send JSON (Content-Type: application/json)"})
            return None
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = -1
        if not 0 < length <= MAX_BODY:
            self._json(413 if length > MAX_BODY else 400, {"error": "missing or oversized body"})
            return None
        try:
            data = json.loads(self.rfile.read(length))
        except (ValueError, UnicodeDecodeError):
            self._json(400, {"error": "that is not valid JSON"})
            return None
        if not isinstance(data, dict):
            self._json(400, {"error": "send a JSON object"})
            return None
        return data

    def _start_stream(self, content_type: str) -> None:
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True

    # ---- routes
    def do_GET(self) -> None:  # noqa: N802
        if not self._allowed():
            return
        if self.path == "/v1/health":
            self._json(200, health())
        elif self.path == "/v1/models":
            names = ["apvis"]
            try:
                names += [m.name for m in AskService().client.models()]
            except (OllamaError, OSError, ValueError):
                pass
            self._json(200, {"object": "list", "data": [{"id": n, "object": "model", "owned_by": "apvis"} for n in names]})
        else:
            self._json(404, {"error": "unknown endpoint; see /v1/health"})

    def do_POST(self) -> None:  # noqa: N802
        if not self._allowed():
            return
        if self.path not in {"/v1/ask", "/v1/chat/completions"}:
            self._json(404, {"error": "unknown endpoint"})
            return
        data = self._body()
        if data is None:
            return
        openai = self.path == "/v1/chat/completions"
        history: list[dict[str, str]] = []
        if openai:
            messages = [m for m in data.get("messages") or [] if isinstance(m, dict) and isinstance(m.get("content"), str)]
            if not messages or messages[-1].get("role") != "user":
                self._json(400, {"error": "the last message must be from the user"})
                return
            question, history = messages[-1]["content"], [m for m in messages[:-1] if m.get("role") in {"user", "assistant"}]
        else:
            question = data.get("question")
            if not isinstance(question, str):
                self._json(400, {"error": "question is required"})
                return
        model = data.get("model")
        model = model if isinstance(model, str) and model not in {"", "apvis", "auto"} else None
        role = data.get("role") if data.get("role") in ROLES else None
        stream = data.get("stream") is True
        self._answer(question, history, model, role, stream, openai)

    def _answer(self, question: str, history: list[dict[str, str]], model: str | None, role: str | None,
                stream: bool, openai: bool) -> None:
        chat_id, created = "apvis-" + uuid4().hex[:12], int(time.time())
        gone = threading.Event()
        sent = [""]

        def write(chunk: bytes) -> None:
            try:
                self.wfile.write(chunk)
                self.wfile.flush()
            except OSError:
                gone.set()                      # the caller hung up: stop the model

        def emit(delta: str, finish: str | None = None, meta: dict[str, Any] | None = None) -> None:
            if openai:
                payload = {"id": chat_id, "object": "chat.completion.chunk", "created": created, "model": (meta or {}).get("model") or "apvis",
                           "choices": [{"index": 0, "delta": {"content": delta} if delta else {}, "finish_reason": finish}]}
                write(b"data: " + json.dumps(payload).encode("utf-8") + b"\n\n")
            else:
                write(json.dumps({"text": delta, **(meta or {})}).encode("utf-8") + b"\n")

        def on_text(text: str) -> None:
            if stream and text.startswith(sent[0]) and len(text) > len(sent[0]):
                emit(text[len(sent[0]):])
                sent[0] = text

        if stream:
            self._start_stream("text/event-stream" if openai else "application/x-ndjson")
        try:
            result = AskService().ask(question, role=role, model=model, history=history, on_text=on_text, cancelled=gone.is_set)
        except (ValueError, OSError) as exc:
            if stream:
                emit("", "error", {"error": str(exc), "done": True})
            else:
                self._json(400, {"error": str(exc)})
            return
        meta = {"model": result.model or "", "source": result.source, "role": result.role,
                "first_token_s": result.first_token_s, "total_s": result.total_s}
        if result.status != "completed":
            meta["error"] = result.error or result.status
        if stream:
            if result.status == "completed" and result.answer.startswith(sent[0]) and len(result.answer) > len(sent[0]):
                emit(result.answer[len(sent[0]):])
            if openai:
                emit("", "stop" if result.status == "completed" else "error", meta)
                write(b"data: [DONE]\n\n")
            else:
                write(json.dumps({"done": True, "answer": result.answer, **meta}).encode("utf-8") + b"\n")
            return
        if result.status != "completed":
            self._json(503 if result.status == "unavailable" else 500, {"error": meta["error"], **meta})
        elif openai:
            self._json(200, {"id": chat_id, "object": "chat.completion", "created": created, "model": result.model or "apvis",
                             "choices": [{"index": 0, "message": {"role": "assistant", "content": result.answer}, "finish_reason": "stop"}],
                             "apvis": meta})
        else:
            self._json(200, {"answer": result.answer, **meta})


def serve(host: str = HOST, port: int = PORT) -> ThreadingHTTPServer:
    if host not in {"127.0.0.1", "::1", "localhost"}:
        raise ValueError("the APVIS API only listens on this computer")
    server = ThreadingHTTPServer((host, port), Handler)
    server.daemon_threads = True
    return server


def start_background(port: int = PORT) -> ThreadingHTTPServer | None:
    """Home runs the API while it is open; None when something else already serves the port."""
    try:
        server = serve(HOST, port)
    except OSError:
        return None
    threading.Thread(target=server.serve_forever, name="apvis-api", daemon=True).start()
    return server


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="The APVIS API (local AI endpoint on 127.0.0.1)")
    parser.add_argument("--port", type=int, default=PORT)
    args = parser.parse_args(argv)
    server = serve(HOST, args.port)
    print(f"APVIS API on http://{HOST}:{args.port}  (Ctrl+C stops it)")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
